
# Customization Code Details

## Structure

`CustomizationCodeDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `value` | `str` | Optional | customization code |
| `short_description` | `str` | Optional | short description of the customization code |
| `long_description` | `str` | Optional | long description of the customization code |

## Example (as JSON)

```json
{
  "value": "H",
  "shortDescription": "Host Auto Close",
  "longDescription": "Host Auto Close"
}
```

