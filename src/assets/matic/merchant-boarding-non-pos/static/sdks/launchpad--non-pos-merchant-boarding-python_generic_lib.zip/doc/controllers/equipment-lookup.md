# Equipment Lookup

```python
equipment_lookup_controller = client.equipment_lookup
```

## Class Name

`EquipmentLookupController`

## Methods

* [Get Additional Configurations](../../doc/controllers/equipment-lookup.md#get-additional-configurations)
* [Get Equipment Supported](../../doc/controllers/equipment-lookup.md#get-equipment-supported)


# Get Additional Configurations

Fetches a list of valid terminal customizations and peripherals, such as electing to password protect a void.

```python
def get_additional_configurations(self,
                                 external_ref_id,
                                 v_correlation_id=None,
                                 logical_application_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `logical_application_id` | `str` | Header, Optional | Logical App ID of the terminal. |

## Response Type

[`AdditionalConfigurationsResponse`](../../doc/models/additional-configurations-response.md)

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

logical_application_id = '1073'

result = equipment_lookup_controller.get_additional_configurations(
    external_ref_id,
    v_correlation_id=v_correlation_id,
    logical_application_id=logical_application_id
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Equipment Supported

Retrieve applicable equipment for an existing application.

```python
def get_equipment_supported(self,
                           external_ref_id,
                           v_correlation_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`InlineResponse200`](../../doc/models/inline-response-200.md)

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

result = equipment_lookup_controller.get_equipment_supported(
    external_ref_id,
    v_correlation_id=v_correlation_id
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

