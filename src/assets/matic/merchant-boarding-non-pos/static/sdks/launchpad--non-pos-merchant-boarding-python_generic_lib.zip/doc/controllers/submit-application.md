# Submit Application

```python
submit_application_controller = client.submit_application
```

## Class Name

`SubmitApplicationController`

## Methods

* [Validate Board](../../doc/controllers/submit-application.md#validate-board)
* [Inititate Board](../../doc/controllers/submit-application.md#inititate-board)


# Validate Board

Begins the merchant validation process before boarding after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```python
def validate_board(self,
                  external_ref_id,
                  v_correlation_id=None,
                  content_type='application/json')
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

`void`

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum.ENUM_APPLICATIONJSON

result = submit_application_controller.validate_board(
    external_ref_id,
    v_correlation_id=v_correlation_id,
    content_type=content_type
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Inititate Board

Begins the merchant boarding process after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```python
def inititate_board(self,
                   external_ref_id,
                   v_correlation_id=None,
                   content_type='application/json',
                   threatmetrix_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `threatmetrix_id` | `str` | Header, Optional | A unique session id |

## Response Type

`void`

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum.ENUM_APPLICATIONJSON

result = submit_application_controller.inititate_board(
    external_ref_id,
    v_correlation_id=v_correlation_id,
    content_type=content_type
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

