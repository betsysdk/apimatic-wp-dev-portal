# Check Application Status

```python
check_application_status_controller = client.check_application_status
```

## Class Name

`CheckApplicationStatusController`

## Methods

* [Get Application Status](../../doc/controllers/check-application-status.md#get-application-status)
* [Fetch Signer Status](../../doc/controllers/check-application-status.md#fetch-signer-status)
* [Fetch Application Status History](../../doc/controllers/check-application-status.md#fetch-application-status-history)


# Get Application Status

Retrieves the status of a contract when passed with an externalRefID. Both the externalRefID and authorization header are required.

```python
def get_application_status(self,
                          external_ref_id,
                          v_correlation_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`ApplicationStatus`](../../doc/models/application-status.md)

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

result = check_application_status_controller.get_application_status(
    external_ref_id,
    v_correlation_id=v_correlation_id
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Signer Status

Use this endpoint to get signer status

```python
def fetch_signer_status(self,
                       external_ref_id,
                       v_correlation_id=None,
                       content_type='application/json')
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`SignerStatus`](../../doc/models/signer-status.md)

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum.ENUM_APPLICATIONJSON

result = check_application_status_controller.fetch_signer_status(
    external_ref_id,
    v_correlation_id=v_correlation_id,
    content_type=content_type
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Application Status History

Use this endpoint to get a application's status history.

```python
def fetch_application_status_history(self,
                                    external_ref_id,
                                    v_correlation_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`StatusHistoryResponse`](../../doc/models/status-history-response.md)

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

result = check_application_status_controller.fetch_application_status_history(
    external_ref_id,
    v_correlation_id=v_correlation_id
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

