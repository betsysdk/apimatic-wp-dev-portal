# Reviewand Sign Contract

```python
reviewand_sign_contract_controller = client.reviewand_sign_contract
```

## Class Name

`ReviewandSignContractController`

## Methods

* [Get Contract](../../doc/controllers/reviewand-sign-contract.md#get-contract)
* [Docusign Link](../../doc/controllers/reviewand-sign-contract.md#docusign-link)


# Get Contract

Returns a PDF contract to be signed.

```python
def get_contract(self,
                external_ref_id,
                v_correlation_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

`mixed`

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

result = review_and_sign_contract_controller.get_contract(
    external_ref_id,
    v_correlation_id=v_correlation_id
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Docusign Link

Retrieves a Docusign link to view the contract.

```python
def docusign_link(self,
                 body,
                 v_correlation_id=None,
                 content_type='application/json')
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`DocumentLink`](../../doc/models/document-link.md) | Body, Required | - |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`DocuSignLink`](../../doc/models/docu-sign-link.md)

## Example Usage

```python
body = DocumentLink(
    external_ref_id='df8a6d82-3bb4-4f3b-ba18-57a5981ede8e',
    return_url='https://docusign.com'
)

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum.ENUM_APPLICATIONJSON

result = review_and_sign_contract_controller.docusign_link(
    body,
    v_correlation_id=v_correlation_id,
    content_type=content_type
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

