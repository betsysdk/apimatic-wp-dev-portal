
# Authorized Signer

## Structure

`AuthorizedSigner`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `role_name` | [`RoleNameEnum`](../../doc/models/role-name-enum.md) | Required | The role of the signer. Please note the below.<br><br>1) Merchant role name is mandatory.<br>2) Required fields indicated in schema are those required for all role names other than "SalesRep"<br>3) The "SalesRep" role name only requires the following fields > roleName, signingExperience, signingOrder, firstName, lastName, email<br>4) The "Signer2" role name is for a Personal Guarantor. This signer must be included if a Personal Guarantor is on the application. Include the Guarnator's information in this object. |
| `signing_experience` | [`SigningExperienceEnum`](../../doc/models/signing-experience-enum.md) | Required | Signing ceremony type |
| `signing_order` | `str` | Required | Define the signing order for multiple signers |
| `title` | `str` | Optional | Required for AMEX acquired merchants otherwise optional.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `30`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `first_name` | `str` | Required | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `middle_initial` | `str` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `last_name` | `str` | Required | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `phone_number` | `str` | Required | 10-digit phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `phone_number_ext` | `str` | Optional | Phone number extension. Up to 8 digits of the format 12345678.<br>**Constraints**: *Maximum Length*: `8`, *Pattern*: `^[0-9]{1,8}$` |
| `phone_type` | [`PhoneTypeEnum`](../../doc/models/phone-type-enum.md) | Optional | Phone type. |
| `alternate_phone` | `str` | Optional | 10-digit alternate phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `alternate_phone_type` | [`AlternatePhoneTypeEnum`](../../doc/models/alternate-phone-type-enum.md) | Optional | Alternate phone type. |
| `fax_number` | `str` | Optional | 10-digit fax number of the format 5131234567<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `email` | `str` | Required | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` |
| `ssn` | `str` | Required | Social security number. Do not include dashes.<br>**Constraints**: *Pattern*: `^[0-9]{9}$` |
| `dob` | `date` | Required | Date of Birth (CCYY-MM-DD). Must be at least 18 years old. |
| `address_line_1` | `str` | Required | Address Line 1. Field for house number, street and direction.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `address_line_2` | `str` | Optional | Address Line 2. Field for apartment or suite numbers, etc.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `city` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `28`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `state` | [`StateEnum`](../../doc/models/state-enum.md) | Required | Valid US state, commonwealth, and territory codes are allowed. |
| `country` | `str` | Required, Constant | Only United States is allowed.<br>**Default**: `'United States'` |
| `postal_code` | `str` | Required | Postal code / zip code. The postal code must be valid for the address' country code.<br>**Constraints**: *Minimum Length*: `5`, *Maximum Length*: `5`, *Pattern*: `^[0-9]{5}$` |
| `postal_code_extension` | `str` | Optional | Postal code / zip code extension.  The postal code extension must be valid for the address' country code.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `4`, *Pattern*: `^[0-9]{4}$` |
| `identification` | [`List[Identification]`](../../doc/models/identification.md) | Optional | Optional. If any attribute in the identification object is populated then at least idNumber and idType are required. |

## Example (as JSON)

```json
{
  "roleName": "Merchant",
  "signingExperience": "email",
  "signingOrder": "2",
  "title": "President",
  "firstName": "Todd",
  "middleInitial": "M",
  "lastName": "Davis",
  "phoneNumber": "5131234567",
  "phoneNumberExt": "1234",
  "phoneType": "mobile",
  "alternatePhone": "5131234567",
  "alternatePhoneType": "home",
  "faxNumber": "5131234567",
  "email": "test@gmail.com",
  "ssn": "123456789",
  "dob": "2000-03-23",
  "addressLine1": "4355 N Coalwhipe St.",
  "addressLine2": "suite 104",
  "city": "Denver",
  "state": "CO",
  "country": "United States",
  "postalCode": "12345",
  "postalCodeExtension": "1234"
}
```

