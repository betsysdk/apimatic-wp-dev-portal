package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/testHelper"
    "launchpadnonposmerchantboarding/models"
    "testing"
)

// TestCheckApplicationStatusControllerTestGetApplicationStatus tests the behavior of the CheckApplicationStatusController's
func TestCheckApplicationStatusControllerTestGetApplicationStatus(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    vCorrelationId := nil
    apiResponse, err := checkApplicationStatusController.GetApplicationStatus(ctx, externalRefId, &vCorrelationId)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, apiResponse.Response.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
        testHelper.NewTestHeader(true,"Content-Type","application/json"),
    }
    testHelper.CheckResponseHeaders(t, apiResponse.Response.Header, expectedHeaders, true)
}

// TestCheckApplicationStatusControllerTestFetchSignerStatus tests the behavior of the CheckApplicationStatusController's
func TestCheckApplicationStatusControllerTestFetchSignerStatus(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    vCorrelationId := nil
    contentType := models.ContentTypeEnum("application/json")
    apiResponse, err := checkApplicationStatusController.FetchSignerStatus(ctx, externalRefId, &vCorrelationId, &contentType)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, apiResponse.Response.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
        testHelper.NewTestHeader(true,"Content-Type","application/json"),
    }
    testHelper.CheckResponseHeaders(t, apiResponse.Response.Header, expectedHeaders, true)
}

// TestCheckApplicationStatusControllerTestFetchApplicationStatusHistory tests the behavior of the CheckApplicationStatusController's
func TestCheckApplicationStatusControllerTestFetchApplicationStatusHistory(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    vCorrelationId := nil
    apiResponse, err := checkApplicationStatusController.FetchApplicationStatusHistory(ctx, externalRefId, &vCorrelationId)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, apiResponse.Response.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
        testHelper.NewTestHeader(true,"Content-Type","application/json"),
    }
    testHelper.CheckResponseHeaders(t, apiResponse.Response.Header, expectedHeaders, true)
}
