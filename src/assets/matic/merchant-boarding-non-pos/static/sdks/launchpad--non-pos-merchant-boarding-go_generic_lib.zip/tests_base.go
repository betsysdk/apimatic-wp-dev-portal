package launchpadnonposmerchantboarding

var equipmentLookupController EquipmentLookupController

var checkApplicationStatusController CheckApplicationStatusController

var initiateBoardingApplicationController InitiateBoardingApplicationController

var reviewAndSignContractController ReviewAndSignContractController

var submitApplicationController SubmitApplicationController

var chooseEquipmentController ChooseEquipmentController

var checkLaunchpadHealthController CheckLaunchpadHealthController

// init is an initialization function that sets up the controllers.
// It creates a configuration from the environment with a specified HTTP configuration and initializes the client.
// Then, it assigns the different controllers from the client to the corresponding variables for further use.
func init() {
    
    config := CreateConfigurationFromEnvironment(
        WithHttpConfiguration(
            CreateHttpConfiguration(
                WithTimeout(30),
            ),
        ),
    )
    
    client := NewClient(config)
    
    equipmentLookupController = *client.EquipmentLookupController()
    checkApplicationStatusController = *client.CheckApplicationStatusController()
    initiateBoardingApplicationController = *client.InitiateBoardingApplicationController()
    reviewAndSignContractController = *client.ReviewAndSignContractController()
    submitApplicationController = *client.SubmitApplicationController()
    chooseEquipmentController = *client.ChooseEquipmentController()
    checkLaunchpadHealthController = *client.CheckLaunchpadHealthController()
}
