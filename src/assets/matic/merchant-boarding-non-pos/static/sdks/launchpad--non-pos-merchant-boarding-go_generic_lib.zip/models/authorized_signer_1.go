package models

import (
    "encoding/json"
    "log"
    "time"
)

// AuthorizedSigner1 represents a AuthorizedSigner1 struct.
type AuthorizedSigner1 struct {
    // The role of the signer. Please note the below.
    //   1) Merchant role name is mandatory.
    //   2) Required fields indicated in schema are those required for all role names other than "SalesRep"
    //   3) The "SalesRep" role name only requires the following fields > roleName, signingExperience, signingOrder, firstName, lastName, email
    //   4) The "Signer2" role name is for a Personal Guarantor. This signer must be included if a Personal Guarantor is on the application. Include the Guarnator's information in this object.
    RoleName            RoleName1Enum           `json:"roleName"`
    // Signing ceremony type
    SigningExperience   SigningExperienceEnum   `json:"signingExperience"`
    // Define the signing order for multiple signers
    SigningOrder        string                  `json:"signingOrder"`
    // Required for AMEX acquired merchants otherwise optional.
    Title               *string                 `json:"title,omitempty"`
    // First name. Region based validations will be applied to this field.
    FirstName           string                  `json:"firstName"`
    // Middle initial.
    MiddleInitial       *string                 `json:"middleInitial,omitempty"`
    // Last name. Region based validations will be applied to this field.
    LastName            string                  `json:"lastName"`
    // 10-digit phone number of the format  5131234567.
    PhoneNumber         string                  `json:"phoneNumber"`
    // Phone number extension. Up to 8 digits of the format 12345678.
    PhoneNumberExt      *string                 `json:"phoneNumberExt,omitempty"`
    // Phone type.
    PhoneType           *PhoneTypeEnum          `json:"phoneType,omitempty"`
    // 10-digit alternate phone number of the format  5131234567.
    AlternatePhone      *string                 `json:"alternatePhone,omitempty"`
    // Alternate phone type.
    AlternatePhoneType  *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
    // 10-digit fax number of the format 5131234567
    FaxNumber           *string                 `json:"faxNumber,omitempty"`
    // Email address of the contact. Must have @ and a .
    Email               string                  `json:"email"`
    // Social security number. Do not include dashes.The full list of restricted SSN is- “000000001” “000000002” “000000003” “000000004” “000000005” “000000006” “000000007” “000000008” “000000009" "111111110" “111111111” "111111112" "111111113" "111111114" "111111115" "111111116" "111111117" "111111118" "111111119" "222222220" "222222221" “222222222” "222222223" "222222224" "222222225" "222222226" "222222227" "222222228" "222222229" "333333330" "333333331" "333333332" “333333333” "333333334" "333333335" "333333336" "333333337" "333333338" "333333339"  "444444440" "444444441" "444444442" "444444443" “444444444” "444444445" "444444446" "444444447" "444444448" "444444449" "555555550" "555555551" "555555552" "555555553" "555555554" “555555555” "555555556" "555555557" "555555558" "555555559"  "666666660" "666666661" "666666662" "666666663" "666666664" "666666665" “666666666" "666666667" "666666668" "666666669" "777777770" "777777771” "777777772" "777777773" "777777774" "777777775" "777777776" “777777777” "777777778" "777777779" "888888880" "888888881" "888888882" "888888883" "888888884" "888888885" "888888886" "888888887" “888888888” "888888889"  "999999990" "999999991" "999999992" "999999993" "999999994" "999999995" "99999996"   "999999997" "999999998" “999999999”  "123456780" to "123456789" "123123123"
    Ssn                 string                  `json:"ssn"`
    // Date of Birth (CCYY-MM-DD). Must be at least 18 years old.
    Dob                 time.Time               `json:"dob"`
    // Address Line 1. Field for house number, street and direction.
    AddressLine1        string                  `json:"addressLine1"`
    // Address Line 2. Field for apartment or suite numbers, etc.
    AddressLine2        *string                 `json:"addressLine2,omitempty"`
    City                string                  `json:"city"`
    // Valid US state, commonwealth, and territory codes are allowed.
    State               State1Enum              `json:"state"`
    // Only United States is allowed.
    Country             string                  `json:"country"`
    // Postal code / zip code. The postal code must be valid for the address' country code.
    PostalCode          string                  `json:"postalCode"`
    // Postal code / zip code extension.  The postal code extension must be valid for the address' country code.
    PostalCodeExtension *string                 `json:"postalCodeExtension,omitempty"`
    // Optional. If any attribute in the identification object is populated then at least idNumber and idType are required.
    Identification      []Identification        `json:"identification,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for AuthorizedSigner1.
// It customizes the JSON marshaling process for AuthorizedSigner1 objects.
func (a *AuthorizedSigner1) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the AuthorizedSigner1 object to a map representation for JSON marshaling.
func (a *AuthorizedSigner1) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["roleName"] = a.RoleName
    structMap["signingExperience"] = a.SigningExperience
    structMap["signingOrder"] = a.SigningOrder
    if a.Title != nil {
        structMap["title"] = a.Title
    }
    structMap["firstName"] = a.FirstName
    if a.MiddleInitial != nil {
        structMap["middleInitial"] = a.MiddleInitial
    }
    structMap["lastName"] = a.LastName
    structMap["phoneNumber"] = a.PhoneNumber
    if a.PhoneNumberExt != nil {
        structMap["phoneNumberExt"] = a.PhoneNumberExt
    }
    if a.PhoneType != nil {
        structMap["phoneType"] = a.PhoneType
    }
    if a.AlternatePhone != nil {
        structMap["alternatePhone"] = a.AlternatePhone
    }
    if a.AlternatePhoneType != nil {
        structMap["alternatePhoneType"] = a.AlternatePhoneType
    }
    if a.FaxNumber != nil {
        structMap["faxNumber"] = a.FaxNumber
    }
    structMap["email"] = a.Email
    structMap["ssn"] = a.Ssn
    structMap["dob"] = a.Dob.Format(DEFAULT_DATE)
    structMap["addressLine1"] = a.AddressLine1
    if a.AddressLine2 != nil {
        structMap["addressLine2"] = a.AddressLine2
    }
    structMap["city"] = a.City
    structMap["state"] = a.State
    structMap["country"] = a.Country
    structMap["postalCode"] = a.PostalCode
    if a.PostalCodeExtension != nil {
        structMap["postalCodeExtension"] = a.PostalCodeExtension
    }
    if a.Identification != nil {
        structMap["identification"] = a.Identification
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for AuthorizedSigner1.
// It customizes the JSON unmarshaling process for AuthorizedSigner1 objects.
func (a *AuthorizedSigner1) UnmarshalJSON(input []byte) error {
    temp := &struct {
        RoleName            RoleName1Enum           `json:"roleName"`
        SigningExperience   SigningExperienceEnum   `json:"signingExperience"`
        SigningOrder        string                  `json:"signingOrder"`
        Title               *string                 `json:"title,omitempty"`
        FirstName           string                  `json:"firstName"`
        MiddleInitial       *string                 `json:"middleInitial,omitempty"`
        LastName            string                  `json:"lastName"`
        PhoneNumber         string                  `json:"phoneNumber"`
        PhoneNumberExt      *string                 `json:"phoneNumberExt,omitempty"`
        PhoneType           *PhoneTypeEnum          `json:"phoneType,omitempty"`
        AlternatePhone      *string                 `json:"alternatePhone,omitempty"`
        AlternatePhoneType  *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
        FaxNumber           *string                 `json:"faxNumber,omitempty"`
        Email               string                  `json:"email"`
        Ssn                 string                  `json:"ssn"`
        Dob                 string                  `json:"dob"`
        AddressLine1        string                  `json:"addressLine1"`
        AddressLine2        *string                 `json:"addressLine2,omitempty"`
        City                string                  `json:"city"`
        State               State1Enum              `json:"state"`
        Country             string                  `json:"country"`
        PostalCode          string                  `json:"postalCode"`
        PostalCodeExtension *string                 `json:"postalCodeExtension,omitempty"`
        Identification      []Identification        `json:"identification,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    a.RoleName = temp.RoleName
    a.SigningExperience = temp.SigningExperience
    a.SigningOrder = temp.SigningOrder
    a.Title = temp.Title
    a.FirstName = temp.FirstName
    a.MiddleInitial = temp.MiddleInitial
    a.LastName = temp.LastName
    a.PhoneNumber = temp.PhoneNumber
    a.PhoneNumberExt = temp.PhoneNumberExt
    a.PhoneType = temp.PhoneType
    a.AlternatePhone = temp.AlternatePhone
    a.AlternatePhoneType = temp.AlternatePhoneType
    a.FaxNumber = temp.FaxNumber
    a.Email = temp.Email
    a.Ssn = temp.Ssn
    DobVal, err := time.Parse(DEFAULT_DATE, temp.Dob)
    if err != nil {
        log.Fatalf("Cannot Parse dob as % s format.", DEFAULT_DATE)
    }
    a.Dob = DobVal
    a.AddressLine1 = temp.AddressLine1
    a.AddressLine2 = temp.AddressLine2
    a.City = temp.City
    a.State = temp.State
    a.Country = temp.Country
    a.PostalCode = temp.PostalCode
    a.PostalCodeExtension = temp.PostalCodeExtension
    a.Identification = temp.Identification
    return nil
}
