package models

import (
    "encoding/json"
)

// TerminalSupply represents a TerminalSupply struct.
type TerminalSupply struct {
    SupplyType string  `json:"supplyType"`
    // Supply name
    Name       *string `json:"name,omitempty"`
    // Supply quantity
    Quantity   *int    `json:"quantity,omitempty"`
    // Total Supplies. Valid values are 0.00
    //   - 9999999999.99."
    Total      *string `json:"total,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for TerminalSupply.
// It customizes the JSON marshaling process for TerminalSupply objects.
func (t *TerminalSupply) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(t.toMap())
}

// toMap converts the TerminalSupply object to a map representation for JSON marshaling.
func (t *TerminalSupply) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["supplyType"] = t.SupplyType
    if t.Name != nil {
        structMap["name"] = t.Name
    }
    if t.Quantity != nil {
        structMap["quantity"] = t.Quantity
    }
    if t.Total != nil {
        structMap["total"] = t.Total
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for TerminalSupply.
// It customizes the JSON unmarshaling process for TerminalSupply objects.
func (t *TerminalSupply) UnmarshalJSON(input []byte) error {
    temp := &struct {
        SupplyType string  `json:"supplyType"`
        Name       *string `json:"name,omitempty"`
        Quantity   *int    `json:"quantity,omitempty"`
        Total      *string `json:"total,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    t.SupplyType = temp.SupplyType
    t.Name = temp.Name
    t.Quantity = temp.Quantity
    t.Total = temp.Total
    return nil
}
