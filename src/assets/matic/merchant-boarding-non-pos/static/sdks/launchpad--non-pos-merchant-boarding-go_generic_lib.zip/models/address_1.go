package models

import (
    "encoding/json"
)

// Address1 represents a Address1 struct.
type Address1 struct {
    // Address Type  
    //  1) Physical address is mandatory.
    //  2) If equipment needs to be sent to a different location than the physical address, then shipping address should be added.
    // 3) For any address type, addressLine1, city, state, postalCode and country are mandatory.
    Type                AddressTypeEnum `json:"type"`
    // Address Line 1. Field for house number, street and direction.
    AddressLine1        string          `json:"addressLine1"`
    // Address Line 2. Field for apartment or suite numbers, etc.
    AddressLine2        *string         `json:"addressLine2,omitempty"`
    City                string          `json:"city"`
    // Valid US state, commonwealth, and territory codes are allowed.
    State               State1Enum      `json:"state"`
    // Only United States is allowed.
    Country             string          `json:"country"`
    // Postal code / zip code. The postal code must be valid for the address' country code.
    PostalCode          string          `json:"postalCode"`
    // Postal code / zip code extension.  The postal code extension must be valid for the address' country code.
    PostalCodeExtension *string         `json:"postalCodeExtension,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Address1.
// It customizes the JSON marshaling process for Address1 objects.
func (a *Address1) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the Address1 object to a map representation for JSON marshaling.
func (a *Address1) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["type"] = a.Type
    structMap["addressLine1"] = a.AddressLine1
    if a.AddressLine2 != nil {
        structMap["addressLine2"] = a.AddressLine2
    }
    structMap["city"] = a.City
    structMap["state"] = a.State
    structMap["country"] = a.Country
    structMap["postalCode"] = a.PostalCode
    if a.PostalCodeExtension != nil {
        structMap["postalCodeExtension"] = a.PostalCodeExtension
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Address1.
// It customizes the JSON unmarshaling process for Address1 objects.
func (a *Address1) UnmarshalJSON(input []byte) error {
    temp := &struct {
        Type                AddressTypeEnum `json:"type"`
        AddressLine1        string          `json:"addressLine1"`
        AddressLine2        *string         `json:"addressLine2,omitempty"`
        City                string          `json:"city"`
        State               State1Enum      `json:"state"`
        Country             string          `json:"country"`
        PostalCode          string          `json:"postalCode"`
        PostalCodeExtension *string         `json:"postalCodeExtension,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    a.Type = temp.Type
    a.AddressLine1 = temp.AddressLine1
    a.AddressLine2 = temp.AddressLine2
    a.City = temp.City
    a.State = temp.State
    a.Country = temp.Country
    a.PostalCode = temp.PostalCode
    a.PostalCodeExtension = temp.PostalCodeExtension
    return nil
}
