package models

import (
    "encoding/json"
    "log"
    "time"
)

// StatusHistory represents a StatusHistory struct.
type StatusHistory struct {
    StatusSeqNumber *int       `json:"statusSeqNumber,omitempty"`
    DetailStatus    *string    `json:"detailStatus,omitempty"`
    SummaryStatus   *string    `json:"summaryStatus,omitempty"`
    StatusCategory  *string    `json:"statusCategory,omitempty"`
    StatusDateTime  *time.Time `json:"statusDateTime,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for StatusHistory.
// It customizes the JSON marshaling process for StatusHistory objects.
func (s *StatusHistory) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(s.toMap())
}

// toMap converts the StatusHistory object to a map representation for JSON marshaling.
func (s *StatusHistory) toMap() map[string]any {
    structMap := make(map[string]any)
    if s.StatusSeqNumber != nil {
        structMap["statusSeqNumber"] = s.StatusSeqNumber
    }
    if s.DetailStatus != nil {
        structMap["detailStatus"] = s.DetailStatus
    }
    if s.SummaryStatus != nil {
        structMap["summaryStatus"] = s.SummaryStatus
    }
    if s.StatusCategory != nil {
        structMap["statusCategory"] = s.StatusCategory
    }
    if s.StatusDateTime != nil {
        structMap["statusDateTime"] = s.StatusDateTime.Format(time.RFC3339)
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for StatusHistory.
// It customizes the JSON unmarshaling process for StatusHistory objects.
func (s *StatusHistory) UnmarshalJSON(input []byte) error {
    temp := &struct {
        StatusSeqNumber *int    `json:"statusSeqNumber,omitempty"`
        DetailStatus    *string `json:"detailStatus,omitempty"`
        SummaryStatus   *string `json:"summaryStatus,omitempty"`
        StatusCategory  *string `json:"statusCategory,omitempty"`
        StatusDateTime  *string `json:"statusDateTime,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    s.StatusSeqNumber = temp.StatusSeqNumber
    s.DetailStatus = temp.DetailStatus
    s.SummaryStatus = temp.SummaryStatus
    s.StatusCategory = temp.StatusCategory
    if temp.StatusDateTime != nil {
        StatusDateTimeVal, err := time.Parse(time.RFC3339, *temp.StatusDateTime)
        if err != nil {
            log.Fatalf("Cannot Parse statusDateTime as % s format.", time.RFC3339)
        }
        s.StatusDateTime = &StatusDateTimeVal
    }
    return nil
}
