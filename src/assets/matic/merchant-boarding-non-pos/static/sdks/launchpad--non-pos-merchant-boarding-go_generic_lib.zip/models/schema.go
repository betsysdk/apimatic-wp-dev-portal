package models

import (
    "encoding/json"
)

// Schema represents a Schema struct.
type Schema struct {
    Id *int64 `json:"id,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Schema.
// It customizes the JSON marshaling process for Schema objects.
func (s *Schema) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(s.toMap())
}

// toMap converts the Schema object to a map representation for JSON marshaling.
func (s *Schema) toMap() map[string]any {
    structMap := make(map[string]any)
    if s.Id != nil {
        structMap["id"] = s.Id
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Schema.
// It customizes the JSON unmarshaling process for Schema objects.
func (s *Schema) UnmarshalJSON(input []byte) error {
    temp := &struct {
        Id *int64 `json:"id,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    s.Id = temp.Id
    return nil
}
