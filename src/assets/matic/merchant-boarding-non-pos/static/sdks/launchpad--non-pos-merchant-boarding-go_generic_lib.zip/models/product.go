package models

import (
    "encoding/json"
)

// Product represents a Product struct.
type Product struct {
    // Product ID is populated internally.
    ProductId   *string `json:"productId,omitempty"`
    // Payment method associated with the internally-populated ID.
    ProductName *string `json:"productName,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Product.
// It customizes the JSON marshaling process for Product objects.
func (p *Product) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(p.toMap())
}

// toMap converts the Product object to a map representation for JSON marshaling.
func (p *Product) toMap() map[string]any {
    structMap := make(map[string]any)
    if p.ProductId != nil {
        structMap["productId"] = p.ProductId
    }
    if p.ProductName != nil {
        structMap["productName"] = p.ProductName
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Product.
// It customizes the JSON unmarshaling process for Product objects.
func (p *Product) UnmarshalJSON(input []byte) error {
    temp := &struct {
        ProductId   *string `json:"productId,omitempty"`
        ProductName *string `json:"productName,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    p.ProductId = temp.ProductId
    p.ProductName = temp.ProductName
    return nil
}
