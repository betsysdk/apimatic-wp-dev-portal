package models

import (
    "encoding/json"
)

// Peripheral represents a Peripheral struct.
type Peripheral struct {
    // Peripheral IDs are internally populated.
    PeripheralId              *string              `json:"peripheralId,omitempty"`
    // Peripheral type
    PeripheralType            *string              `json:"peripheralType,omitempty"`
    Model                     *string              `json:"model,omitempty"`
    // Lease ID for the peripheral
    LeaseId                   *string              `json:"leaseId,omitempty"`
    // Lease term for the peripheral
    LeaseTermLength           *LeaseTermLengthEnum `json:"leaseTermLength,omitempty"`
    // Payment method for the selected peripheral.
    PaymentMethod             *PaymentMethod1Enum  `json:"paymentMethod,omitempty"`
    // "Payment Amount for the peripheral. Valid values are 0.00
    //   - 9999999999.99."
    Amount                    *string              `json:"amount,omitempty"`
    // Payment confirmation number for the peripheral.
    PaymentConfirmationNumber *string              `json:"paymentConfirmationNumber,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Peripheral.
// It customizes the JSON marshaling process for Peripheral objects.
func (p *Peripheral) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(p.toMap())
}

// toMap converts the Peripheral object to a map representation for JSON marshaling.
func (p *Peripheral) toMap() map[string]any {
    structMap := make(map[string]any)
    if p.PeripheralId != nil {
        structMap["peripheralId"] = p.PeripheralId
    }
    if p.PeripheralType != nil {
        structMap["peripheralType"] = p.PeripheralType
    }
    if p.Model != nil {
        structMap["model"] = p.Model
    }
    if p.LeaseId != nil {
        structMap["leaseId"] = p.LeaseId
    }
    if p.LeaseTermLength != nil {
        structMap["leaseTermLength"] = p.LeaseTermLength
    }
    if p.PaymentMethod != nil {
        structMap["paymentMethod"] = p.PaymentMethod
    }
    if p.Amount != nil {
        structMap["amount"] = p.Amount
    }
    if p.PaymentConfirmationNumber != nil {
        structMap["paymentConfirmationNumber"] = p.PaymentConfirmationNumber
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Peripheral.
// It customizes the JSON unmarshaling process for Peripheral objects.
func (p *Peripheral) UnmarshalJSON(input []byte) error {
    temp := &struct {
        PeripheralId              *string              `json:"peripheralId,omitempty"`
        PeripheralType            *string              `json:"peripheralType,omitempty"`
        Model                     *string              `json:"model,omitempty"`
        LeaseId                   *string              `json:"leaseId,omitempty"`
        LeaseTermLength           *LeaseTermLengthEnum `json:"leaseTermLength,omitempty"`
        PaymentMethod             *PaymentMethod1Enum  `json:"paymentMethod,omitempty"`
        Amount                    *string              `json:"amount,omitempty"`
        PaymentConfirmationNumber *string              `json:"paymentConfirmationNumber,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    p.PeripheralId = temp.PeripheralId
    p.PeripheralType = temp.PeripheralType
    p.Model = temp.Model
    p.LeaseId = temp.LeaseId
    p.LeaseTermLength = temp.LeaseTermLength
    p.PaymentMethod = temp.PaymentMethod
    p.Amount = temp.Amount
    p.PaymentConfirmationNumber = temp.PaymentConfirmationNumber
    return nil
}
