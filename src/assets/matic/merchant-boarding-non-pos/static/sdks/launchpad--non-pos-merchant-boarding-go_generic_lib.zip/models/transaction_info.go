package models

import (
    "encoding/json"
)

// TransactionInfo represents a TransactionInfo struct.
type TransactionInfo struct {
    // Projected annual sales volume.
    AnnualSalesVolume               float64                `json:"annualSalesVolume"`
    // Projected Percentage of daily card-present transactions.
    PercentRetailSwipedTransactions int                    `json:"percentRetailSwipedTransactions"`
    // Average ticket dollar amount.
    AverageTicket                   *float64               `json:"averageTicket,omitempty"`
    // Highest ticket dollar amount.
    HighestTicket                   *float64               `json:"highestTicket,omitempty"`
    // the current processor
    CurrentProcessor                *string                `json:"currentProcessor,omitempty"`
    // Do you have more than 25 chargeback accepted in the last 12 months?
    AcceptChargebacks               *AcceptChargebacksEnum `json:"acceptChargebacks,omitempty"`
    // Projected chargeback percentage.
    // ```Required when acceptChargebacks is 'Yes'```
    // ```Optional when acceptChargebacks is null or 'No'.```
    ChargebackPercent               *int                   `json:"chargebackPercent,omitempty"`
    // Projected return percent of  goods sold
    ReturnPercent                   *int                   `json:"returnPercent,omitempty"`
    // Percent of card not present transactions.
    CardNotPresentPercent           *int                   `json:"cardNotPresentPercent,omitempty"`
    // Percent of business-to-business transactions.
    BusinessToBusinessPercent       *int                   `json:"businessToBusinessPercent,omitempty"`
    // Percent of internet transactions.
    InternetTransactionPercent      *int                   `json:"internetTransactionPercent,omitempty"`
    // Projected annual credit card sales volume.
    AnnualCreditSalesVolume         *float64               `json:"annualCreditSalesVolume,omitempty"`
    // Projected annual debit card sales volume.
    AnnualDebitSalesVolume          *float64               `json:"annualDebitSalesVolume,omitempty"`
    // Projected annual Amex volume. ``` This field is required when you opt-in for Amex ```
    AnnualAmexVolume                *float64               `json:"annualAmexVolume,omitempty"`
    // AverageTicket dollar amount for Amex.
    //   ```This field is required when you opt-in for Amex```
    AmexAverageTicket               *float64               `json:"amexAverageTicket,omitempty"`
    // Average number of days from when cardholder is charged & when products or services are received IN FULL by cardholder.
    AverageNumberofDays             *int                   `json:"averageNumberofDays,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for TransactionInfo.
// It customizes the JSON marshaling process for TransactionInfo objects.
func (t *TransactionInfo) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(t.toMap())
}

// toMap converts the TransactionInfo object to a map representation for JSON marshaling.
func (t *TransactionInfo) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["annualSalesVolume"] = t.AnnualSalesVolume
    structMap["percentRetailSwipedTransactions"] = t.PercentRetailSwipedTransactions
    if t.AverageTicket != nil {
        structMap["averageTicket"] = t.AverageTicket
    }
    if t.HighestTicket != nil {
        structMap["highestTicket"] = t.HighestTicket
    }
    if t.CurrentProcessor != nil {
        structMap["currentProcessor"] = t.CurrentProcessor
    }
    if t.AcceptChargebacks != nil {
        structMap["acceptChargebacks"] = t.AcceptChargebacks
    }
    if t.ChargebackPercent != nil {
        structMap["chargebackPercent"] = t.ChargebackPercent
    }
    if t.ReturnPercent != nil {
        structMap["returnPercent"] = t.ReturnPercent
    }
    if t.CardNotPresentPercent != nil {
        structMap["cardNotPresentPercent"] = t.CardNotPresentPercent
    }
    if t.BusinessToBusinessPercent != nil {
        structMap["businessToBusinessPercent"] = t.BusinessToBusinessPercent
    }
    if t.InternetTransactionPercent != nil {
        structMap["internetTransactionPercent"] = t.InternetTransactionPercent
    }
    if t.AnnualCreditSalesVolume != nil {
        structMap["annualCreditSalesVolume"] = t.AnnualCreditSalesVolume
    }
    if t.AnnualDebitSalesVolume != nil {
        structMap["annualDebitSalesVolume"] = t.AnnualDebitSalesVolume
    }
    if t.AnnualAmexVolume != nil {
        structMap["annualAmexVolume"] = t.AnnualAmexVolume
    }
    if t.AmexAverageTicket != nil {
        structMap["amexAverageTicket"] = t.AmexAverageTicket
    }
    if t.AverageNumberofDays != nil {
        structMap["averageNumberofDays"] = t.AverageNumberofDays
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for TransactionInfo.
// It customizes the JSON unmarshaling process for TransactionInfo objects.
func (t *TransactionInfo) UnmarshalJSON(input []byte) error {
    temp := &struct {
        AnnualSalesVolume               float64                `json:"annualSalesVolume"`
        PercentRetailSwipedTransactions int                    `json:"percentRetailSwipedTransactions"`
        AverageTicket                   *float64               `json:"averageTicket,omitempty"`
        HighestTicket                   *float64               `json:"highestTicket,omitempty"`
        CurrentProcessor                *string                `json:"currentProcessor,omitempty"`
        AcceptChargebacks               *AcceptChargebacksEnum `json:"acceptChargebacks,omitempty"`
        ChargebackPercent               *int                   `json:"chargebackPercent,omitempty"`
        ReturnPercent                   *int                   `json:"returnPercent,omitempty"`
        CardNotPresentPercent           *int                   `json:"cardNotPresentPercent,omitempty"`
        BusinessToBusinessPercent       *int                   `json:"businessToBusinessPercent,omitempty"`
        InternetTransactionPercent      *int                   `json:"internetTransactionPercent,omitempty"`
        AnnualCreditSalesVolume         *float64               `json:"annualCreditSalesVolume,omitempty"`
        AnnualDebitSalesVolume          *float64               `json:"annualDebitSalesVolume,omitempty"`
        AnnualAmexVolume                *float64               `json:"annualAmexVolume,omitempty"`
        AmexAverageTicket               *float64               `json:"amexAverageTicket,omitempty"`
        AverageNumberofDays             *int                   `json:"averageNumberofDays,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    t.AnnualSalesVolume = temp.AnnualSalesVolume
    t.PercentRetailSwipedTransactions = temp.PercentRetailSwipedTransactions
    t.AverageTicket = temp.AverageTicket
    t.HighestTicket = temp.HighestTicket
    t.CurrentProcessor = temp.CurrentProcessor
    t.AcceptChargebacks = temp.AcceptChargebacks
    t.ChargebackPercent = temp.ChargebackPercent
    t.ReturnPercent = temp.ReturnPercent
    t.CardNotPresentPercent = temp.CardNotPresentPercent
    t.BusinessToBusinessPercent = temp.BusinessToBusinessPercent
    t.InternetTransactionPercent = temp.InternetTransactionPercent
    t.AnnualCreditSalesVolume = temp.AnnualCreditSalesVolume
    t.AnnualDebitSalesVolume = temp.AnnualDebitSalesVolume
    t.AnnualAmexVolume = temp.AnnualAmexVolume
    t.AmexAverageTicket = temp.AmexAverageTicket
    t.AverageNumberofDays = temp.AverageNumberofDays
    return nil
}
