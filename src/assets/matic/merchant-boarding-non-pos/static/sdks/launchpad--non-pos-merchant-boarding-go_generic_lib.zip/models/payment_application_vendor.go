package models

import (
    "encoding/json"
    "log"
    "time"
)

// PaymentApplicationVendor represents a PaymentApplicationVendor struct.
// A payment application is installed software developed for processing various payments types: Credit, Debit, Gift, Checks, etc. and can be integrated with a POS system or used in a standalone manner.
type PaymentApplicationVendor struct {
    // Payment application ID
    PaymentApplicationId   *string    `json:"paymentApplicationId,omitempty"`
    PaymentApplicationName *string    `json:"paymentApplicationName,omitempty"`
    // Vendor ID for the payment application.
    VendorId               *string    `json:"vendorId,omitempty"`
    // Payment application version.
    Version                *string    `json:"version,omitempty"`
    // Reseller
    Reseller               *string    `json:"reseller,omitempty"`
    // Last date payment application was upgraded.
    LastUpgradeDate        *time.Time `json:"lastUpgradeDate,omitempty"`
    // Custom notes can go here.
    Notes                  *string    `json:"notes,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for PaymentApplicationVendor.
// It customizes the JSON marshaling process for PaymentApplicationVendor objects.
func (p *PaymentApplicationVendor) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(p.toMap())
}

// toMap converts the PaymentApplicationVendor object to a map representation for JSON marshaling.
func (p *PaymentApplicationVendor) toMap() map[string]any {
    structMap := make(map[string]any)
    if p.PaymentApplicationId != nil {
        structMap["paymentApplicationId"] = p.PaymentApplicationId
    }
    if p.PaymentApplicationName != nil {
        structMap["paymentApplicationName"] = p.PaymentApplicationName
    }
    if p.VendorId != nil {
        structMap["vendorId"] = p.VendorId
    }
    if p.Version != nil {
        structMap["version"] = p.Version
    }
    if p.Reseller != nil {
        structMap["reseller"] = p.Reseller
    }
    if p.LastUpgradeDate != nil {
        structMap["lastUpgradeDate"] = p.LastUpgradeDate.Format(time.RFC3339)
    }
    if p.Notes != nil {
        structMap["notes"] = p.Notes
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for PaymentApplicationVendor.
// It customizes the JSON unmarshaling process for PaymentApplicationVendor objects.
func (p *PaymentApplicationVendor) UnmarshalJSON(input []byte) error {
    temp := &struct {
        PaymentApplicationId   *string `json:"paymentApplicationId,omitempty"`
        PaymentApplicationName *string `json:"paymentApplicationName,omitempty"`
        VendorId               *string `json:"vendorId,omitempty"`
        Version                *string `json:"version,omitempty"`
        Reseller               *string `json:"reseller,omitempty"`
        LastUpgradeDate        *string `json:"lastUpgradeDate,omitempty"`
        Notes                  *string `json:"notes,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    p.PaymentApplicationId = temp.PaymentApplicationId
    p.PaymentApplicationName = temp.PaymentApplicationName
    p.VendorId = temp.VendorId
    p.Version = temp.Version
    p.Reseller = temp.Reseller
    if temp.LastUpgradeDate != nil {
        LastUpgradeDateVal, err := time.Parse(time.RFC3339, *temp.LastUpgradeDate)
        if err != nil {
            log.Fatalf("Cannot Parse lastUpgradeDate as % s format.", time.RFC3339)
        }
        p.LastUpgradeDate = &LastUpgradeDateVal
    }
    p.Notes = temp.Notes
    return nil
}
