package models

import (
    "encoding/json"
)

// SalesAgent represents a SalesAgent struct.
// The agent who is submitting the deal.
type SalesAgent struct {
    // Id for the Sales Contact.
    Id                *string `json:"id,omitempty"`
    // Sales agent's first name.
    FirstName         string  `json:"firstName"`
    // Sales agent's last name.
    LastName          string  `json:"lastName"`
    // Sales agent's 10-digit phone number of the format 5131234567.
    MobilePhoneNumber *string `json:"mobilePhoneNumber,omitempty"`
    // Sales agent's email address.  Must have @ and a .
    Email             string  `json:"email"`
}

// MarshalJSON implements the json.Marshaler interface for SalesAgent.
// It customizes the JSON marshaling process for SalesAgent objects.
func (s *SalesAgent) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(s.toMap())
}

// toMap converts the SalesAgent object to a map representation for JSON marshaling.
func (s *SalesAgent) toMap() map[string]any {
    structMap := make(map[string]any)
    if s.Id != nil {
        structMap["id"] = s.Id
    }
    structMap["firstName"] = s.FirstName
    structMap["lastName"] = s.LastName
    if s.MobilePhoneNumber != nil {
        structMap["mobilePhoneNumber"] = s.MobilePhoneNumber
    }
    structMap["email"] = s.Email
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for SalesAgent.
// It customizes the JSON unmarshaling process for SalesAgent objects.
func (s *SalesAgent) UnmarshalJSON(input []byte) error {
    temp := &struct {
        Id                *string `json:"id,omitempty"`
        FirstName         string  `json:"firstName"`
        LastName          string  `json:"lastName"`
        MobilePhoneNumber *string `json:"mobilePhoneNumber,omitempty"`
        Email             string  `json:"email"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    s.Id = temp.Id
    s.FirstName = temp.FirstName
    s.LastName = temp.LastName
    s.MobilePhoneNumber = temp.MobilePhoneNumber
    s.Email = temp.Email
    return nil
}
