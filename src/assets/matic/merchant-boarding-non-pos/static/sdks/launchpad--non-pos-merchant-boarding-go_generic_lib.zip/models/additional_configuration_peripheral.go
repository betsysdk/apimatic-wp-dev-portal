package models

import (
    "encoding/json"
)

// AdditionalConfigurationPeripheral represents a AdditionalConfigurationPeripheral struct.
type AdditionalConfigurationPeripheral struct {
    // Peripheral IDs are internally populated.
    PeripheralId         *string `json:"peripheralId,omitempty"`
    // Peripheral Name
    Model                *string `json:"model,omitempty"`
    // Description of the peripheral
    ShortDescription     *string `json:"shortDescription,omitempty"`
    // Verbose description of the peripheral
    LongDescription      *string `json:"longDescription,omitempty"`
    // Whether peripheral is EMV certified
    IsEMVCertified       *bool   `json:"isEMVCertified,omitempty"`
    // Whether peripheral is EMV Capable
    IsEMVCapable         *bool   `json:"isEMVCapable,omitempty"`
    ActivePeripheralFlag *string `json:"activePeripheralFlag,omitempty"`
    // purchase price of the peripheral
    PurchasePrice        *string `json:"purchasePrice,omitempty"`
    // lease price of the peripheral
    LeasePrice           *string `json:"leasePrice,omitempty"`
    // rental price of the peripheral
    RentalPrice          *string `json:"rentalPrice,omitempty"`
    // hardware cost of the terminal
    HardwareCost         *string `json:"hardwareCost,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for AdditionalConfigurationPeripheral.
// It customizes the JSON marshaling process for AdditionalConfigurationPeripheral objects.
func (a *AdditionalConfigurationPeripheral) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the AdditionalConfigurationPeripheral object to a map representation for JSON marshaling.
func (a *AdditionalConfigurationPeripheral) toMap() map[string]any {
    structMap := make(map[string]any)
    if a.PeripheralId != nil {
        structMap["peripheralId"] = a.PeripheralId
    }
    if a.Model != nil {
        structMap["model"] = a.Model
    }
    if a.ShortDescription != nil {
        structMap["shortDescription"] = a.ShortDescription
    }
    if a.LongDescription != nil {
        structMap["longDescription"] = a.LongDescription
    }
    if a.IsEMVCertified != nil {
        structMap["isEMVCertified"] = a.IsEMVCertified
    }
    if a.IsEMVCapable != nil {
        structMap["isEMVCapable"] = a.IsEMVCapable
    }
    if a.ActivePeripheralFlag != nil {
        structMap["activePeripheralFlag"] = a.ActivePeripheralFlag
    }
    if a.PurchasePrice != nil {
        structMap["purchasePrice"] = a.PurchasePrice
    }
    if a.LeasePrice != nil {
        structMap["leasePrice"] = a.LeasePrice
    }
    if a.RentalPrice != nil {
        structMap["rentalPrice"] = a.RentalPrice
    }
    if a.HardwareCost != nil {
        structMap["hardwareCost"] = a.HardwareCost
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for AdditionalConfigurationPeripheral.
// It customizes the JSON unmarshaling process for AdditionalConfigurationPeripheral objects.
func (a *AdditionalConfigurationPeripheral) UnmarshalJSON(input []byte) error {
    temp := &struct {
        PeripheralId         *string `json:"peripheralId,omitempty"`
        Model                *string `json:"model,omitempty"`
        ShortDescription     *string `json:"shortDescription,omitempty"`
        LongDescription      *string `json:"longDescription,omitempty"`
        IsEMVCertified       *bool   `json:"isEMVCertified,omitempty"`
        IsEMVCapable         *bool   `json:"isEMVCapable,omitempty"`
        ActivePeripheralFlag *string `json:"activePeripheralFlag,omitempty"`
        PurchasePrice        *string `json:"purchasePrice,omitempty"`
        LeasePrice           *string `json:"leasePrice,omitempty"`
        RentalPrice          *string `json:"rentalPrice,omitempty"`
        HardwareCost         *string `json:"hardwareCost,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    a.PeripheralId = temp.PeripheralId
    a.Model = temp.Model
    a.ShortDescription = temp.ShortDescription
    a.LongDescription = temp.LongDescription
    a.IsEMVCertified = temp.IsEMVCertified
    a.IsEMVCapable = temp.IsEMVCapable
    a.ActivePeripheralFlag = temp.ActivePeripheralFlag
    a.PurchasePrice = temp.PurchasePrice
    a.LeasePrice = temp.LeasePrice
    a.RentalPrice = temp.RentalPrice
    a.HardwareCost = temp.HardwareCost
    return nil
}
