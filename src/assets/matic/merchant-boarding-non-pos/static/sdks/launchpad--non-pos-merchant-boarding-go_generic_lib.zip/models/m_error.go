package models

import (
    "encoding/json"
)

// Error represents a Error struct.
type Error struct {
    ErrorCode    *string `json:"errorCode,omitempty"`
    ErrorMessage *string `json:"errorMessage,omitempty"`
    Target       *string `json:"target,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Error.
// It customizes the JSON marshaling process for Error objects.
func (e *Error) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(e.toMap())
}

// toMap converts the Error object to a map representation for JSON marshaling.
func (e *Error) toMap() map[string]any {
    structMap := make(map[string]any)
    if e.ErrorCode != nil {
        structMap["errorCode"] = e.ErrorCode
    }
    if e.ErrorMessage != nil {
        structMap["errorMessage"] = e.ErrorMessage
    }
    if e.Target != nil {
        structMap["target"] = e.Target
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Error.
// It customizes the JSON unmarshaling process for Error objects.
func (e *Error) UnmarshalJSON(input []byte) error {
    temp := &struct {
        ErrorCode    *string `json:"errorCode,omitempty"`
        ErrorMessage *string `json:"errorMessage,omitempty"`
        Target       *string `json:"target,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    e.ErrorCode = temp.ErrorCode
    e.ErrorMessage = temp.ErrorMessage
    e.Target = temp.Target
    return nil
}
