package models

import (
    "encoding/json"
)

// AdvancedSettlementInner represents a AdvancedSettlementInner struct.
// Advanced Settlement gives merchants options to settle their account according to their needs with different settlement categories.
type AdvancedSettlementInner struct {
    SettlementCategories []SettlementCategoryEnum `json:"settlementCategories,omitempty"`
    // Bank account collects bank account information from merchant. It is optional till the time of boarding where bank account becomes required along with ddaType, achType, accountNumber, routingNumber & bankName.
    BankAccount          *BankAccount1            `json:"bankAccount,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for AdvancedSettlementInner.
// It customizes the JSON marshaling process for AdvancedSettlementInner objects.
func (a *AdvancedSettlementInner) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the AdvancedSettlementInner object to a map representation for JSON marshaling.
func (a *AdvancedSettlementInner) toMap() map[string]any {
    structMap := make(map[string]any)
    if a.SettlementCategories != nil {
        structMap["settlementCategories"] = a.SettlementCategories
    }
    if a.BankAccount != nil {
        structMap["bankAccount"] = a.BankAccount.toMap()
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for AdvancedSettlementInner.
// It customizes the JSON unmarshaling process for AdvancedSettlementInner objects.
func (a *AdvancedSettlementInner) UnmarshalJSON(input []byte) error {
    temp := &struct {
        SettlementCategories []SettlementCategoryEnum `json:"settlementCategories,omitempty"`
        BankAccount          *BankAccount1            `json:"bankAccount,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    a.SettlementCategories = temp.SettlementCategories
    a.BankAccount = temp.BankAccount
    return nil
}
