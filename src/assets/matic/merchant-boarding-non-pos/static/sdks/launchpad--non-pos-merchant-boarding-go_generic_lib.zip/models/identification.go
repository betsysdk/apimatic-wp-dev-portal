package models

import (
    "encoding/json"
    "log"
    "time"
)

// Identification represents a Identification struct.
type Identification struct {
    // Type of ID provided by the owner.
    IdType        IdTypeEnum       `json:"idType"`
    // Owner's ID number.
    IdNumber      string           `json:"idNumber"`
    // City in which ID was issued.
    IssuedCity    *string          `json:"issuedCity,omitempty"`
    // Valid state code where ID was issued.
    IssuedState   *IssuedStateEnum `json:"issuedState,omitempty"`
    // Country where ID was issued.
    IssuedCountry *string          `json:"issuedCountry,omitempty"`
    // Date ID was issued (CCYY-MM-DD).
    DateIssued    *time.Time       `json:"dateIssued,omitempty"`
    // Date ID expires (CCYY-MM-DD).
    DateExpires   *time.Time       `json:"dateExpires,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Identification.
// It customizes the JSON marshaling process for Identification objects.
func (i *Identification) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(i.toMap())
}

// toMap converts the Identification object to a map representation for JSON marshaling.
func (i *Identification) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["idType"] = i.IdType
    structMap["idNumber"] = i.IdNumber
    if i.IssuedCity != nil {
        structMap["issuedCity"] = i.IssuedCity
    }
    if i.IssuedState != nil {
        structMap["issuedState"] = i.IssuedState
    }
    if i.IssuedCountry != nil {
        structMap["issuedCountry"] = i.IssuedCountry
    }
    if i.DateIssued != nil {
        structMap["dateIssued"] = i.DateIssued.Format(DEFAULT_DATE)
    }
    if i.DateExpires != nil {
        structMap["dateExpires"] = i.DateExpires.Format(DEFAULT_DATE)
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Identification.
// It customizes the JSON unmarshaling process for Identification objects.
func (i *Identification) UnmarshalJSON(input []byte) error {
    temp := &struct {
        IdType        IdTypeEnum       `json:"idType"`
        IdNumber      string           `json:"idNumber"`
        IssuedCity    *string          `json:"issuedCity,omitempty"`
        IssuedState   *IssuedStateEnum `json:"issuedState,omitempty"`
        IssuedCountry *string          `json:"issuedCountry,omitempty"`
        DateIssued    *string          `json:"dateIssued,omitempty"`
        DateExpires   *string          `json:"dateExpires,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    i.IdType = temp.IdType
    i.IdNumber = temp.IdNumber
    i.IssuedCity = temp.IssuedCity
    i.IssuedState = temp.IssuedState
    i.IssuedCountry = temp.IssuedCountry
    if temp.DateIssued != nil {
        DateIssuedVal, err := time.Parse(DEFAULT_DATE, *temp.DateIssued)
        if err != nil {
            log.Fatalf("Cannot Parse dateIssued as % s format.", DEFAULT_DATE)
        }
        i.DateIssued = &DateIssuedVal
    }
    if temp.DateExpires != nil {
        DateExpiresVal, err := time.Parse(DEFAULT_DATE, *temp.DateExpires)
        if err != nil {
            log.Fatalf("Cannot Parse dateExpires as % s format.", DEFAULT_DATE)
        }
        i.DateExpires = &DateExpiresVal
    }
    return nil
}
