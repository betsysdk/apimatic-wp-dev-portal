package models

import (
    "encoding/json"
)

// DocuSignLink represents a DocuSignLink struct.
type DocuSignLink struct {
    // UI embeded link of the Docusign contract for the externalRefId.
    EmbeddingUrl *string `json:"embeddingUrl,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for DocuSignLink.
// It customizes the JSON marshaling process for DocuSignLink objects.
func (d *DocuSignLink) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(d.toMap())
}

// toMap converts the DocuSignLink object to a map representation for JSON marshaling.
func (d *DocuSignLink) toMap() map[string]any {
    structMap := make(map[string]any)
    if d.EmbeddingUrl != nil {
        structMap["embeddingUrl"] = d.EmbeddingUrl
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for DocuSignLink.
// It customizes the JSON unmarshaling process for DocuSignLink objects.
func (d *DocuSignLink) UnmarshalJSON(input []byte) error {
    temp := &struct {
        EmbeddingUrl *string `json:"embeddingUrl,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    d.EmbeddingUrl = temp.EmbeddingUrl
    return nil
}
