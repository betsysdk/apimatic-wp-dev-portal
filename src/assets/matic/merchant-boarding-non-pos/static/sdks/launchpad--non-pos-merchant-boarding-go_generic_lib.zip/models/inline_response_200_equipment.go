package models

import (
    "encoding/json"
)

// InlineResponse200Equipment represents a InlineResponse200Equipment struct.
type InlineResponse200Equipment struct {
    Id                   *string `json:"id,omitempty"`
    Name                 *string `json:"name,omitempty"`
    LogicalApplicationId *string `json:"logicalApplicationId,omitempty"`
    Environment          *string `json:"environment,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for InlineResponse200Equipment.
// It customizes the JSON marshaling process for InlineResponse200Equipment objects.
func (i *InlineResponse200Equipment) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(i.toMap())
}

// toMap converts the InlineResponse200Equipment object to a map representation for JSON marshaling.
func (i *InlineResponse200Equipment) toMap() map[string]any {
    structMap := make(map[string]any)
    if i.Id != nil {
        structMap["id"] = i.Id
    }
    if i.Name != nil {
        structMap["name"] = i.Name
    }
    if i.LogicalApplicationId != nil {
        structMap["logicalApplicationId"] = i.LogicalApplicationId
    }
    if i.Environment != nil {
        structMap["environment"] = i.Environment
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for InlineResponse200Equipment.
// It customizes the JSON unmarshaling process for InlineResponse200Equipment objects.
func (i *InlineResponse200Equipment) UnmarshalJSON(input []byte) error {
    temp := &struct {
        Id                   *string `json:"id,omitempty"`
        Name                 *string `json:"name,omitempty"`
        LogicalApplicationId *string `json:"logicalApplicationId,omitempty"`
        Environment          *string `json:"environment,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    i.Id = temp.Id
    i.Name = temp.Name
    i.LogicalApplicationId = temp.LogicalApplicationId
    i.Environment = temp.Environment
    return nil
}
