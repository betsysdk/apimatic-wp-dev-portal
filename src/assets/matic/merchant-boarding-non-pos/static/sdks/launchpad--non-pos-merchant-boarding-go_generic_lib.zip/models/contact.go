package models

import (
    "encoding/json"
    "log"
    "time"
)

// Contact represents a Contact struct.
type Contact struct {
    // Type of merchant contact.   
    //  1) Only primary contact
    //       is mandatory. May be the same as any owner contact information. 
    //  2) For primary contact, firstName, lastName, phoneNumber and email are mandatory during POST.  
    //  3) For all other contact types, firstName and lastName are mandatory during POST.
    Type               Type1Enum               `json:"type"`
    // Required for AMEX acquired merchants otherwise optional.
    Title              *string                 `json:"title,omitempty"`
    // First name. Region based validations will be applied to this field.
    FirstName          string                  `json:"firstName"`
    // Middle initial.
    MiddleInitial      *string                 `json:"middleInitial,omitempty"`
    // Last name. Region based validations will be applied to this field.
    LastName           string                  `json:"lastName"`
    // Social security number. Do not include dashes.
    Ssn                *string                 `json:"ssn,omitempty"`
    // Date of Birth (CCYY-MM-DD). Must be at least 18 years old.
    BirthDate          *time.Time              `json:"birthDate,omitempty"`
    // 10-digit phone number of the format  5131234567.
    PhoneNumber        string                  `json:"phoneNumber"`
    // Phone number extension. Up to 8 digits of the format 12345678.
    PhoneNumberExt     *string                 `json:"phoneNumberExt,omitempty"`
    // Phone type.
    PhoneType          *PhoneTypeEnum          `json:"phoneType,omitempty"`
    // 10-digit alternate phone number of the format  5131234567.
    AlternatePhone     *string                 `json:"alternatePhone,omitempty"`
    // Alternate phone type.
    AlternatePhoneType *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
    // Email address of the contact. Must have @ and a .
    Email              string                  `json:"email"`
    // 10-digit fax number of the format 5131234567
    FaxNumber          *string                 `json:"faxNumber,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Contact.
// It customizes the JSON marshaling process for Contact objects.
func (c *Contact) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(c.toMap())
}

// toMap converts the Contact object to a map representation for JSON marshaling.
func (c *Contact) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["type"] = c.Type
    if c.Title != nil {
        structMap["title"] = c.Title
    }
    structMap["firstName"] = c.FirstName
    if c.MiddleInitial != nil {
        structMap["middleInitial"] = c.MiddleInitial
    }
    structMap["lastName"] = c.LastName
    if c.Ssn != nil {
        structMap["ssn"] = c.Ssn
    }
    if c.BirthDate != nil {
        structMap["birthDate"] = c.BirthDate.Format(DEFAULT_DATE)
    }
    structMap["phoneNumber"] = c.PhoneNumber
    if c.PhoneNumberExt != nil {
        structMap["phoneNumberExt"] = c.PhoneNumberExt
    }
    if c.PhoneType != nil {
        structMap["phoneType"] = c.PhoneType
    }
    if c.AlternatePhone != nil {
        structMap["alternatePhone"] = c.AlternatePhone
    }
    if c.AlternatePhoneType != nil {
        structMap["alternatePhoneType"] = c.AlternatePhoneType
    }
    structMap["email"] = c.Email
    if c.FaxNumber != nil {
        structMap["faxNumber"] = c.FaxNumber
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Contact.
// It customizes the JSON unmarshaling process for Contact objects.
func (c *Contact) UnmarshalJSON(input []byte) error {
    temp := &struct {
        Type               Type1Enum               `json:"type"`
        Title              *string                 `json:"title,omitempty"`
        FirstName          string                  `json:"firstName"`
        MiddleInitial      *string                 `json:"middleInitial,omitempty"`
        LastName           string                  `json:"lastName"`
        Ssn                *string                 `json:"ssn,omitempty"`
        BirthDate          *string                 `json:"birthDate,omitempty"`
        PhoneNumber        string                  `json:"phoneNumber"`
        PhoneNumberExt     *string                 `json:"phoneNumberExt,omitempty"`
        PhoneType          *PhoneTypeEnum          `json:"phoneType,omitempty"`
        AlternatePhone     *string                 `json:"alternatePhone,omitempty"`
        AlternatePhoneType *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
        Email              string                  `json:"email"`
        FaxNumber          *string                 `json:"faxNumber,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    c.Type = temp.Type
    c.Title = temp.Title
    c.FirstName = temp.FirstName
    c.MiddleInitial = temp.MiddleInitial
    c.LastName = temp.LastName
    c.Ssn = temp.Ssn
    if temp.BirthDate != nil {
        BirthDateVal, err := time.Parse(DEFAULT_DATE, *temp.BirthDate)
        if err != nil {
            log.Fatalf("Cannot Parse birthDate as % s format.", DEFAULT_DATE)
        }
        c.BirthDate = &BirthDateVal
    }
    c.PhoneNumber = temp.PhoneNumber
    c.PhoneNumberExt = temp.PhoneNumberExt
    c.PhoneType = temp.PhoneType
    c.AlternatePhone = temp.AlternatePhone
    c.AlternatePhoneType = temp.AlternatePhoneType
    c.Email = temp.Email
    c.FaxNumber = temp.FaxNumber
    return nil
}
