package models

import (
    "encoding/json"
)

// AdditionalInformationObject represents a AdditionalInformationObject struct.
// Required for some partners. Work with your Developer Integrations specialist for more information.
type AdditionalInformationObject struct {
    Key   *KeyEnum `json:"key,omitempty"`
    Value *string  `json:"value,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for AdditionalInformationObject.
// It customizes the JSON marshaling process for AdditionalInformationObject objects.
func (a *AdditionalInformationObject) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the AdditionalInformationObject object to a map representation for JSON marshaling.
func (a *AdditionalInformationObject) toMap() map[string]any {
    structMap := make(map[string]any)
    if a.Key != nil {
        structMap["key"] = a.Key
    }
    if a.Value != nil {
        structMap["value"] = a.Value
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for AdditionalInformationObject.
// It customizes the JSON unmarshaling process for AdditionalInformationObject objects.
func (a *AdditionalInformationObject) UnmarshalJSON(input []byte) error {
    temp := &struct {
        Key   *KeyEnum `json:"key,omitempty"`
        Value *string  `json:"value,omitempty"`
    }{}
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    
    a.Key = temp.Key
    a.Value = temp.Value
    return nil
}
