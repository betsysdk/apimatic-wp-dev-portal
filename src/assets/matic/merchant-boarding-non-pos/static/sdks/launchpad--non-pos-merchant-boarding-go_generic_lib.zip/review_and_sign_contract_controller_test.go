package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/testHelper"
    "testing"
)

// TestReviewAndSignContractControllerTestGetContract tests the behavior of the ReviewAndSignContractController's
func TestReviewAndSignContractControllerTestGetContract(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    vCorrelationId := nil
    apiResponse, err := reviewAndSignContractController.GetContract(ctx, externalRefId, &vCorrelationId)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, apiResponse.Response.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
        testHelper.NewTestHeader(true,"Content-Type","application/pdf"),
    }
    testHelper.CheckResponseHeaders(t, apiResponse.Response.Header, expectedHeaders, true)
}
