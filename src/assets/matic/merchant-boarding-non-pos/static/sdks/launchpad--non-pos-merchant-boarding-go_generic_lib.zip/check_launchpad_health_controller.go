package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/utilities"
    "github.com/google/uuid"
    "launchpadnonposmerchantboarding/models"
)

// CheckLaunchpadHealthController represents a controller struct.
type CheckLaunchpadHealthController struct {
    baseController
}

// NewCheckLaunchpadHealthController creates a new instance of CheckLaunchpadHealthController.
// It takes a baseController as a parameter and returns a pointer to the CheckLaunchpadHealthController.
func NewCheckLaunchpadHealthController(baseController baseController) *CheckLaunchpadHealthController {
    checkLaunchpadHealthController := CheckLaunchpadHealthController{baseController: baseController}
    return &checkLaunchpadHealthController
}

// Gethealth takes context, vCorrelationId as parameters and
// returns an models.ApiResponse with models.InlineResponse2001 data and
// an error if there was an issue with the request or response.
// Checks the the health of Launchpad and its dependent down streams systems like CPQ, Sales Force, XAA and Jigsaw at regular intervals to check the system is up or down.
func (c *CheckLaunchpadHealthController) Gethealth(
    ctx context.Context,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.InlineResponse2001],
    error) {
    req := c.prepareRequest(ctx, "GET", "/applications/health")
    req.Authenticate(NewAuth("api_key"))
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    var result models.InlineResponse2001
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.InlineResponse2001](decoder)
    return models.NewApiResponse(result, resp), err
}
