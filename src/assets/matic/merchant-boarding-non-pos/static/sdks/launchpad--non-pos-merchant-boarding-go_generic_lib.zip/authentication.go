package launchpadnonposmerchantboarding

import (
    "errors"
    "github.com/apimatic/go-core-runtime/https"
    "net/http"
)

// CustomHeaderAuthenticationCredentials represents the credentials required for `api_key` authentication.
type CustomHeaderAuthenticationCredentials struct {
    authorization string
}

// NewCustomHeaderAuthenticationCredentials creates a new instance of CustomHeaderAuthenticationCredentials with provided parameters.
func NewCustomHeaderAuthenticationCredentials(authorization string) CustomHeaderAuthenticationCredentials {
    return CustomHeaderAuthenticationCredentials {
        authorization: authorization,
    }
}

// WithAuthorization sets authorization in CustomHeaderAuthenticationCredentials.
func (c CustomHeaderAuthenticationCredentials) WithAuthorization(authorization string) CustomHeaderAuthenticationCredentials {
    c.authorization = authorization
    return c
}

// Authorization returns the authorization associated with the CustomHeaderAuthenticationCredentials.
func (c CustomHeaderAuthenticationCredentials) Authorization() string {
    return c.authorization
}

// Validate function returns validation error associated with the CustomHeaderAuthenticationCredentials.
func (c CustomHeaderAuthenticationCredentials) Validate() error {
    if c.authorization == "" {
        return errors.New("api_key : missing auth credentials -> Authorization.")
    }
    return nil
}

// Authenticator function returns HttpInterceptor function that provides authentication for API calls.
func (c CustomHeaderAuthenticationCredentials) Authenticator() https.HttpInterceptor {
    return func(req *http.Request,
        next https.HttpCallExecutor,
    ) https.HttpContext {
            req.Header.Set("Authorization", c.Authorization())
        return next(req)
    }
}
