package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/testHelper"
    "testing"
)

// TestEquipmentLookupControllerTestGetAdditionalConfigurations tests the behavior of the EquipmentLookupController's
func TestEquipmentLookupControllerTestGetAdditionalConfigurations(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    vCorrelationId := nil
    logicalApplicationId := "1073"
    apiResponse, err := equipmentLookupController.GetAdditionalConfigurations(ctx, externalRefId, &vCorrelationId, &logicalApplicationId)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, apiResponse.Response.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
        testHelper.NewTestHeader(true,"Content-Type","application/json"),
    }
    testHelper.CheckResponseHeaders(t, apiResponse.Response.Header, expectedHeaders, true)
}

// TestEquipmentLookupControllerTestGetEquipmentSupported tests the behavior of the EquipmentLookupController's
func TestEquipmentLookupControllerTestGetEquipmentSupported(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    vCorrelationId := nil
    apiResponse, err := equipmentLookupController.GetEquipmentSupported(ctx, externalRefId, &vCorrelationId)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, apiResponse.Response.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
        testHelper.NewTestHeader(true,"Content-Type","application/json"),
    }
    testHelper.CheckResponseHeaders(t, apiResponse.Response.Header, expectedHeaders, true)
}
