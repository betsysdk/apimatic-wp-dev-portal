package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/https"
    "github.com/apimatic/go-core-runtime/utilities"
    "github.com/google/uuid"
    "launchpadnonposmerchantboarding/errors"
    "launchpadnonposmerchantboarding/models"
    "net/http"
)

// InitiateBoardingApplicationController represents a controller struct.
type InitiateBoardingApplicationController struct {
    baseController
}

// NewInitiateBoardingApplicationController creates a new instance of InitiateBoardingApplicationController.
// It takes a baseController as a parameter and returns a pointer to the InitiateBoardingApplicationController.
func NewInitiateBoardingApplicationController(baseController baseController) *InitiateBoardingApplicationController {
    initiateBoardingApplicationController := InitiateBoardingApplicationController{baseController: baseController}
    return &initiateBoardingApplicationController
}

// ExisitingApplication takes context, body, vCorrelationId, contentType as parameters and
// returns an models.ApiResponse with  data and
// an error if there was an issue with the request or response.
// This endpoint allows merchants to update an existing application with new information.
func (i *InitiateBoardingApplicationController) ExisitingApplication(
    ctx context.Context,
    body *models.ExistingApplication1,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum) (
    *http.Response,
    error) {
    req := i.prepareRequest(ctx, "PUT", "/applications")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if contentType != nil {
        req.Header("Content-Type", *contentType)
    }
    req.Json(body)
    context, err := req.Call()
    if err != nil {
        return context.Response, err
    }
    return context.Response, err
}

// NewApplication takes context, body, vCorrelationId, contentType as parameters and
// returns an models.ApiResponse with models.ApplicationResponse data and
// an error if there was an issue with the request or response.
// Use this endpoint to collect the merchant information needed to initiate a new contract.
func (i *InitiateBoardingApplicationController) NewApplication(
    ctx context.Context,
    body *models.Application,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum) (
    models.ApiResponse[models.ApplicationResponse],
    error) {
    req := i.prepareRequest(ctx, "POST", "/applications")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if contentType != nil {
        req.Header("Content-Type", *contentType)
    }
    req.Json(body)
    var result models.ApplicationResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.ApplicationResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// FetchApplication takes context, externalRefId, vCorrelationId as parameters and
// returns an models.ApiResponse with models.ExistingApplication data and
// an error if there was an issue with the request or response.
// Retrieves existing application data.
func (i *InitiateBoardingApplicationController) FetchApplication(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.ExistingApplication],
    error) {
    req := i.prepareRequest(ctx, "GET", "/applications")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    var result models.ExistingApplication
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.ExistingApplication](decoder)
    return models.NewApiResponse(result, resp), err
}
