
# Transaction Info

## Structure

`TransactionInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AnnualSalesVolume` | `float64` | Required | Projected annual sales volume.<br>**Constraints**: `>= 0`, `<= 9999999999999.99` |
| `PercentRetailSwipedTransactions` | `int` | Required | Projected Percentage of daily card-present transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `AverageTicket` | `*float64` | Optional | Average ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` |
| `HighestTicket` | `*float64` | Optional | Highest ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` |
| `CurrentProcessor` | `*string` | Optional | the current processor |
| `AcceptChargebacks` | [`*models.AcceptChargebacksEnum`](../../doc/models/accept-chargebacks-enum.md) | Optional | Do you have more than 25 chargeback accepted in the last 12 months? |
| `ChargebackPercent` | `*int` | Optional | Projected chargeback percentage.<br><br>`Required when acceptChargebacks is 'Yes'`<br><br>`Optional when acceptChargebacks is null or 'No'.`<br>**Constraints**: `>= 0`, `<= 100` |
| `ReturnPercent` | `*int` | Optional | Projected return percent of  goods sold<br>**Constraints**: `>= 0`, `<= 100` |
| `CardNotPresentPercent` | `*int` | Optional | Percent of card not present transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `BusinessToBusinessPercent` | `*int` | Optional | Percent of business-to-business transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `InternetTransactionPercent` | `*int` | Optional | Percent of internet transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `AnnualCreditSalesVolume` | `*float64` | Optional | Projected annual credit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` |
| `AnnualDebitSalesVolume` | `*float64` | Optional | Projected annual debit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` |
| `AnnualAmexVolume` | `*float64` | Optional | Projected annual Amex volume. `This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 999999999.99` |
| `AmexAverageTicket` | `*float64` | Optional | AverageTicket dollar amount for Amex.<br>`This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 9999999.99` |
| `AverageNumberofDays` | `*int` | Optional | Average number of days from when cardholder is charged & when products or services are received IN FULL by cardholder.<br>**Constraints**: `>= 0` |

## Example (as JSON)

```json
{
  "annualSalesVolume": 20000.12,
  "percentRetailSwipedTransactions": 82,
  "averageTicket": 2.3,
  "highestTicket": 32.41,
  "currentProcessor": "Global Payments",
  "acceptChargebacks": "No",
  "chargebackPercent": 0,
  "returnPercent": 10,
  "cardNotPresentPercent": 20,
  "businessToBusinessPercent": 20,
  "internetTransactionPercent": 10,
  "annualCreditSalesVolume": 123.32,
  "annualDebitSalesVolume": 32.23,
  "annualAmexVolume": 10000,
  "amexAverageTicket": 2.3,
  "averageNumberofDays": 10
}
```

