
# Installation Contact

The Technical Agent who is going to do setup.

## Structure

`InstallationContact`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `*string` | Optional | Id for Technical Contact<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `FirstName` | `string` | Required | Contact's first name.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `LastName` | `string` | Required | Contact's last name.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `MobilePhoneNumber` | `*string` | Optional | Contact's 10-digit phone number of the format 5131234567.<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10`, *Pattern*: `([0-9]{10})$` |
| `Email` | `string` | Required | Contact's email address. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `(\\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\\.)+[A-Za-z0-9]{2,}\\b{0,64})` |

## Example (as JSON)

```json
{
  "id": "U15318",
  "firstName": "Sam",
  "lastName": "Doe",
  "mobilePhoneNumber": "1234567890",
  "email": "email0"
}
```

