
# Return Policy Enum

The business's return policy.

## Enumeration

`ReturnPolicyEnum`

## Fields

| Name |
|  --- |
| `ENUM3DAY` |
| `ENUM30DAY` |
| `ENUM60DAY` |
| `ENUM60DAY1` |
| `ENUMALLSALESFINAL` |
| `ENUMEXCHANGEONLYSTORECREDIT` |
| `ENUMNORETURNPOLICY` |

## Example

```
30 Day
```

