
# Terminal Supply

## Structure

`TerminalSupply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SupplyType` | `string` | Required | - |
| `Name` | `*string` | Optional | Supply name |
| `Quantity` | `*int` | Optional | Supply quantity |
| `Total` | `*string` | Optional | Total Supplies. Valid values are 0.00<br><br>- 9999999999.99."<br>**Constraints**: *Pattern*: `(^\d{1,10}([.]\d{1,2})?)$` |

## Example (as JSON)

```json
{
  "supplyType": "supplyType2",
  "quantity": 2,
  "total": "220.21",
  "name": "name6"
}
```

