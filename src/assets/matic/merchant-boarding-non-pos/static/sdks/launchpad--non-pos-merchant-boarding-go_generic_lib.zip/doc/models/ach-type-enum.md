
# Ach Type Enum

Check deposit type

## Enumeration

`AchTypeEnum`

## Fields

| Name |
|  --- |
| `ENUMCOMMERCIALCHECKING` |
| `ENUMPRIVATECHECKING` |

## Example

```
Commercial Checking
```

