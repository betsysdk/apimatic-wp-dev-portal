# Equipment Lookup

```go
equipmentLookupController := client.EquipmentLookupController()
```

## Class Name

`EquipmentLookupController`

## Methods

* [Get Additional Configurations](../../doc/controllers/equipment-lookup.md#get-additional-configurations)
* [Get Equipment Supported](../../doc/controllers/equipment-lookup.md#get-equipment-supported)


# Get Additional Configurations

Fetches a list of valid terminal customizations and peripherals, such as electing to password protect a void.

```go
GetAdditionalConfigurations(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID,
    logicalApplicationId *string) (
    models.ApiResponse[models.AdditionalConfigurationsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `logicalApplicationId` | `*string` | Header, Optional | Logical App ID of the terminal. |

## Response Type

[`models.AdditionalConfigurationsResponse`](../../doc/models/additional-configurations-response.md)

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
logicalApplicationId := "1073"

apiResponse, err := equipmentLookupController.GetAdditionalConfigurations(ctx, externalRefId, &vCorrelationId, &logicalApplicationId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Equipment Supported

Retrieve applicable equipment for an existing application.

```go
GetEquipmentSupported(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.InlineResponse200],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`models.InlineResponse200`](../../doc/models/inline-response-200.md)

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")

apiResponse, err := equipmentLookupController.GetEquipmentSupported(ctx, externalRefId, &vCorrelationId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

