
# Error

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ErrorCode` | `*string` | Optional | - |
| `ErrorMessage` | `*string` | Optional | - |
| `Target` | `*string` | Optional | - |

## Example (as JSON)

```json
{
  "errorCode": "ERROR_CODE",
  "errorMessage": "Error message here.",
  "target": "Target"
}
```

