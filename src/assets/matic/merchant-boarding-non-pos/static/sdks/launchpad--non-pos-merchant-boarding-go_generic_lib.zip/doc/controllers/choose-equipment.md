# Choose Equipment

```go
chooseEquipmentController := client.ChooseEquipmentController()
```

## Class Name

`ChooseEquipmentController`

## Methods

* [Get Terminal Info](../../doc/controllers/choose-equipment.md#get-terminal-info)
* [Update Terminal](../../doc/controllers/choose-equipment.md#update-terminal)
* [Config Standalone Terminal](../../doc/controllers/choose-equipment.md#config-standalone-terminal)


# Get Terminal Info

Gets the terminal configuration information for a specific partner.

```go
GetTerminalInfo(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum,
    locationId *string,
    merchantId *string) (
    models.ApiResponse[models.EquipmentSetup],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`*models.ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `*string` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `*string` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

[`models.EquipmentSetup`](../../doc/models/equipment-setup.md)

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
contentType := models.ContentTypeEnum("application/json")

apiResponse, err := chooseEquipmentController.GetTerminalInfo(ctx, externalRefId, &vCorrelationId, &contentType, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Update Terminal

Updates terminal configurations.

```go
UpdateTerminal(
    ctx context.Context,
    externalRefId uuid.UUID,
    body models.EquipmentSetup,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum,
    locationId *string,
    merchantId *string) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`models.EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`*models.ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `*string` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `*string` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

``

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")

bodyTerminals0TerminalConfigs := models.TerminalConfig{
    RequestId:              models.ToPointer("41231"),
    TerminalId:             "67",
    TerminalModel:          models.ToPointer("VAR - Xpient Solutions"),
    Price:                  float64(187.99),
    Quantity:               1,
    LogicalApplicationId:   "194",
    AccessMethod:           "SSL",
    PaymentMethod:          models.PaymentMethodEnum("PURCHASE / SALE"),
    EnvironmentName:        "Restaurant",
}

bodyTerminals0Products0 := models.Product{
    ProductId:   models.ToPointer("1"),
    ProductName: models.ToPointer("Credit"),
}

bodyTerminals0Products := []models.Product{bodyTerminals0Products0}
bodyTerminals0 := models.Terminal{
    TerminalConfigs: bodyTerminals0TerminalConfigs,
    Products:        bodyTerminals0Products,
}

bodyTerminals := []models.Terminal{bodyTerminals0}
body := models.EquipmentSetup{
    ShippingOption: models.ToPointer(models.ShippingOptionEnum("next day")),
    Terminals:      bodyTerminals,
}

resp, err := chooseEquipmentController.UpdateTerminal(ctx, externalRefId, &body, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Config Standalone Terminal

Sets up terminal configurations.

```go
ConfigStandaloneTerminal(
    ctx context.Context,
    externalRefId uuid.UUID,
    body models.EquipmentSetup,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum,
    locationId *string,
    merchantId *string) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`models.EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`*models.ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `*string` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `*string` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

``

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")

bodyTerminals0TerminalConfigs := models.TerminalConfig{
    RequestId:              models.ToPointer("41231"),
    TerminalId:             "67",
    TerminalModel:          models.ToPointer("VAR - Xpient Solutions"),
    Price:                  float64(187.99),
    Quantity:               1,
    LogicalApplicationId:   "194",
    AccessMethod:           "SSL",
    PaymentMethod:          models.PaymentMethodEnum("PURCHASE / SALE"),
    EnvironmentName:        "Restaurant",
}

bodyTerminals0Products0 := models.Product{
    ProductId:   models.ToPointer("1"),
    ProductName: models.ToPointer("Credit"),
}

bodyTerminals0Products := []models.Product{bodyTerminals0Products0}
bodyTerminals0 := models.Terminal{
    TerminalConfigs: bodyTerminals0TerminalConfigs,
    Products:        bodyTerminals0Products,
}

bodyTerminals := []models.Terminal{bodyTerminals0}
body := models.EquipmentSetup{
    ShippingOption: models.ToPointer(models.ShippingOptionEnum("next day")),
    Terminals:      bodyTerminals,
}

resp, err := chooseEquipmentController.ConfigStandaloneTerminal(ctx, externalRefId, &body, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

