
# Seasonal Enum

Does the business operate seasonally?

## Enumeration

`SeasonalEnum`

## Fields

| Name |
|  --- |
| `YES` |
| `NO` |

## Example

```
Yes
```

