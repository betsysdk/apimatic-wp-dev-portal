
# Terminal Customization

## Structure

`TerminalCustomization`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CustomizationId` | `*string` | Optional | Customization ID is internally populated from a master list. |
| `CustomizationName` | `*string` | Optional | - |
| `CustomizationFieldValue` | `*string` | Optional | - |

## Example (as JSON)

```json
{
  "customizationId": "10",
  "customizationName": "Auto-Close Time",
  "customizationFieldValue": "N"
}
```

