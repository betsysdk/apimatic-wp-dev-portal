
# Additional Configuration Peripheral

## Structure

`AdditionalConfigurationPeripheral`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PeripheralId` | `*string` | Optional | Peripheral IDs are internally populated. |
| `Model` | `*string` | Optional | Peripheral Name |
| `ShortDescription` | `*string` | Optional | Description of the peripheral |
| `LongDescription` | `*string` | Optional | Verbose description of the peripheral |
| `IsEMVCertified` | `*bool` | Optional | Whether peripheral is EMV certified |
| `IsEMVCapable` | `*bool` | Optional | Whether peripheral is EMV Capable |
| `ActivePeripheralFlag` | `*string` | Optional | - |
| `PurchasePrice` | `*string` | Optional | purchase price of the peripheral |
| `LeasePrice` | `*string` | Optional | lease price of the peripheral |
| `RentalPrice` | `*string` | Optional | rental price of the peripheral |
| `HardwareCost` | `*string` | Optional | hardware cost of the terminal |

## Example (as JSON)

```json
{
  "peripheralId": "35",
  "model": "Pin Pad 1000 SE",
  "shortDescription": "PP1S",
  "longDescription": "PPAD",
  "isEMVCertified": true,
  "isEMVCapable": true,
  "activePeripheralFlag": "Y",
  "purchasePrice": "168.12",
  "leasePrice": "100.12",
  "rentalPrice": "90",
  "hardwareCost": "50.75"
}
```

