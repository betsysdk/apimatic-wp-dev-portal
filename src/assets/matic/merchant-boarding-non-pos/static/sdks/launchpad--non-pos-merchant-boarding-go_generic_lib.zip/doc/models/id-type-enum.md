
# Id Type Enum

Type of ID provided by the owner.

## Enumeration

`IdTypeEnum`

## Fields

| Name |
|  --- |
| `ENUMALIENID` |
| `ENUMCREDITBUREAU` |
| `ENUMDRIVERSLICENSE` |
| `ENUMSTATEID` |
| `ENUMMEXICANCONSULATE` |
| `ENUMMILITARYID` |
| `OTHER` |
| `PASSPORT` |

## Example

```
PASSPORT
```

