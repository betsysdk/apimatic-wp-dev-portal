
# Peripheral

## Structure

`Peripheral`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PeripheralId` | `*string` | Optional | Peripheral IDs are internally populated. |
| `PeripheralType` | `*string` | Optional | Peripheral type |
| `Model` | `*string` | Optional | - |
| `LeaseId` | `*string` | Optional | Lease ID for the peripheral |
| `LeaseTermLength` | [`*models.LeaseTermLengthEnum`](../../doc/models/lease-term-length-enum.md) | Optional | Lease term for the peripheral |
| `PaymentMethod` | [`*models.PaymentMethod1Enum`](../../doc/models/payment-method-1-enum.md) | Optional | Payment method for the selected peripheral. |
| `Amount` | `*string` | Optional | "Payment Amount for the peripheral. Valid values are 0.00<br><br>- 9999999999.99."<br>**Constraints**: *Pattern*: `(^\d{1,10}([.]\d{1,2})?)$` |
| `PaymentConfirmationNumber` | `*string` | Optional | Payment confirmation number for the peripheral.<br>**Constraints**: *Pattern*: `[0-9a-zA-Z]{6}\|` |

## Example (as JSON)

```json
{
  "peripheralId": "231",
  "peripheralType": "PPAD",
  "model": "Magtek Check Reader",
  "leaseId": "18",
  "leaseTermLength": "24",
  "paymentMethod": "PURCHASE / SALE",
  "amount": "220.21",
  "paymentConfirmationNumber": "123456"
}
```

