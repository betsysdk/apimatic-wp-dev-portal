
# Dda Type Enum

Direct deposit account type.

## Enumeration

`DdaTypeEnum`

## Fields

| Name |
|  --- |
| `CHECKING` |
| `SAVINGS` |

## Example

```
Checking
```

