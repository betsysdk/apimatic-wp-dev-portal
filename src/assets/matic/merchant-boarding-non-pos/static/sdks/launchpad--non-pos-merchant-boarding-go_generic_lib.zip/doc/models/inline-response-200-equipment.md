
# Inline Response 200 Equipment

## Structure

`InlineResponse200Equipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `*string` | Optional | - |
| `Name` | `*string` | Optional | - |
| `LogicalApplicationId` | `*string` | Optional | - |
| `Environment` | `*string` | Optional | - |

## Example (as JSON)

```json
{
  "id": "1",
  "name": "Verifone LX570",
  "logicalApplicationId": "1073",
  "environment": "Retail"
}
```

