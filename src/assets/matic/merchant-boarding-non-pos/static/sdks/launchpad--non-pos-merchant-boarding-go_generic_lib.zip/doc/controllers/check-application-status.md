# Check Application Status

```go
checkApplicationStatusController := client.CheckApplicationStatusController()
```

## Class Name

`CheckApplicationStatusController`

## Methods

* [Get Application Status](../../doc/controllers/check-application-status.md#get-application-status)
* [Fetch Signer Status](../../doc/controllers/check-application-status.md#fetch-signer-status)
* [Fetch Application Status History](../../doc/controllers/check-application-status.md#fetch-application-status-history)


# Get Application Status

Retrieves the status of a contract when passed with an externalRefID. Both the externalRefID and authorization header are required.

```go
GetApplicationStatus(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.ApplicationStatus],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`models.ApplicationStatus`](../../doc/models/application-status.md)

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")

apiResponse, err := checkApplicationStatusController.GetApplicationStatus(ctx, externalRefId, &vCorrelationId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Signer Status

Use this endpoint to get signer status

```go
FetchSignerStatus(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum) (
    models.ApiResponse[models.SignerStatus],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`*models.ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`models.SignerStatus`](../../doc/models/signer-status.md)

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
contentType := models.ContentTypeEnum("application/json")

apiResponse, err := checkApplicationStatusController.FetchSignerStatus(ctx, externalRefId, &vCorrelationId, &contentType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Application Status History

Use this endpoint to get a application's status history.

```go
FetchApplicationStatusHistory(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.StatusHistoryResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`models.StatusHistoryResponse`](../../doc/models/status-history-response.md)

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")

apiResponse, err := checkApplicationStatusController.FetchApplicationStatusHistory(ctx, externalRefId, &vCorrelationId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

