
# Payment Method 1 Enum

Payment method for the selected peripheral.

## Enumeration

`PaymentMethod1Enum`

## Fields

| Name |
|  --- |
| `ENUMPURCHASESALE` |
| `ENUMREPROGRAMOWN` |
| `ENUMMONTHTOMONTHRENTAL` |
| `LEASE` |

## Example

```
PURCHASE / SALE
```

