# Reviewand Sign Contract

```go
reviewandSignContractController := client.ReviewandSignContractController()
```

## Class Name

`ReviewandSignContractController`

## Methods

* [Get Contract](../../doc/controllers/reviewand-sign-contract.md#get-contract)
* [Docusign Link](../../doc/controllers/reviewand-sign-contract.md#docusign-link)


# Get Contract

Returns a PDF contract to be signed.

```go
GetContract(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[interface{}],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

`interface{}`

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")

apiResponse, err := reviewAndSignContractController.GetContract(ctx, externalRefId, &vCorrelationId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Docusign Link

Retrieves a Docusign link to view the contract.

```go
DocusignLink(
    ctx context.Context,
    body models.DocumentLink,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum) (
    models.ApiResponse[models.DocuSignLink],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.DocumentLink`](../../doc/models/document-link.md) | Body, Required | - |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`*models.ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`models.DocuSignLink`](../../doc/models/docu-sign-link.md)

## Example Usage

```go
ctx := context.Background()

body := models.DocumentLink{
    ExternalRefId: "df8a6d82-3bb4-4f3b-ba18-57a5981ede8e",
    ReturnUrl:     models.ToPointer("https://docusign.com"),
}
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
contentType := models.ContentTypeEnum("application/json")

apiResponse, err := reviewAndSignContractController.DocusignLink(ctx, &body, &vCorrelationId, &contentType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

