
# Identification

## Structure

`Identification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IdType` | [`models.IdTypeEnum`](../../doc/models/id-type-enum.md) | Required | Type of ID provided by the owner. |
| `IdNumber` | `string` | Required | Owner's ID number.<br>**Constraints**: *Maximum Length*: `40` |
| `IssuedCity` | `*string` | Optional | City in which ID was issued.<br>**Constraints**: *Maximum Length*: `28` |
| `IssuedState` | [`*models.IssuedStateEnum`](../../doc/models/issued-state-enum.md) | Optional | Valid state code where ID was issued.<br>**Constraints**: *Maximum Length*: `2` |
| `IssuedCountry` | `*string` | Optional | Country where ID was issued.<br>**Constraints**: *Maximum Length*: `2` |
| `DateIssued` | `*time.Time` | Optional | Date ID was issued (CCYY-MM-DD). |
| `DateExpires` | `*time.Time` | Optional | Date ID expires (CCYY-MM-DD). |

## Example (as JSON)

```json
{
  "idType": "PASSPORT",
  "idNumber": "312312341",
  "issuedCity": "City Town",
  "issuedState": "CO",
  "issuedCountry": "US",
  "dateIssued": "1999-01-30",
  "dateExpires": "2020-02-11"
}
```

