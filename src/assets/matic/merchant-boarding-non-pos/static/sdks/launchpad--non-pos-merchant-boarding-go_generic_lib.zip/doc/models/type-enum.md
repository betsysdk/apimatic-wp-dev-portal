
# Type Enum

The Owner Type. Please note the above Ownership Types where a Control Owner is required.

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `ENUMCONTROLOWNERCONTACT` |
| `ENUMOWNER1CONTACT` |
| `ENUMOWNER2CONTACT` |
| `ENUMOWNER3CONTACT` |
| `ENUMOWNER4CONTACT` |

