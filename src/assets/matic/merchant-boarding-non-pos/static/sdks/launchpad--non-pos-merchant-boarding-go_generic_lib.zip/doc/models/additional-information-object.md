
# Additional Information Object

Required for some partners. Work with your Developer Integrations specialist for more information.

## Structure

`AdditionalInformationObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Key` | [`*models.KeyEnum`](../../doc/models/key-enum.md) | Optional | - |
| `Value` | `*string` | Optional | - |

## Example (as JSON)

```json
{
  "key": "partnerEmployeeId",
  "value": "4656"
}
```

