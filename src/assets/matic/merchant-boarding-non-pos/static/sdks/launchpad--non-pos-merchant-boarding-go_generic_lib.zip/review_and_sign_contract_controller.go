package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/https"
    "github.com/apimatic/go-core-runtime/utilities"
    "github.com/google/uuid"
    "launchpadnonposmerchantboarding/errors"
    "launchpadnonposmerchantboarding/models"
)

// ReviewAndSignContractController represents a controller struct.
type ReviewAndSignContractController struct {
    baseController
}

// NewReviewAndSignContractController creates a new instance of ReviewAndSignContractController.
// It takes a baseController as a parameter and returns a pointer to the ReviewAndSignContractController.
func NewReviewAndSignContractController(baseController baseController) *ReviewAndSignContractController {
    reviewAndSignContractController := ReviewAndSignContractController{baseController: baseController}
    return &reviewAndSignContractController
}

// GetContract takes context, externalRefId, vCorrelationId as parameters and
// returns an models.ApiResponse with interface{} data and
// an error if there was an issue with the request or response.
// Returns a PDF contract to be signed.
func (r *ReviewAndSignContractController) GetContract(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[interface{}],
    error) {
    req := r.prepareRequest(ctx, "GET", "/contracts")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    var result interface{}
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[interface{}](decoder)
    return models.NewApiResponse(result, resp), err
}

// DocusignLink takes context, body, vCorrelationId, contentType as parameters and
// returns an models.ApiResponse with models.DocuSignLink data and
// an error if there was an issue with the request or response.
// Retrieves a Docusign link to view the contract.
func (r *ReviewAndSignContractController) DocusignLink(
    ctx context.Context,
    body *models.DocumentLink,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum) (
    models.ApiResponse[models.DocuSignLink],
    error) {
    req := r.prepareRequest(ctx, "POST", "/applications/documentlink")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if contentType != nil {
        req.Header("Content-Type", *contentType)
    }
    req.Json(body)
    var result models.DocuSignLink
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.DocuSignLink](decoder)
    return models.NewApiResponse(result, resp), err
}
