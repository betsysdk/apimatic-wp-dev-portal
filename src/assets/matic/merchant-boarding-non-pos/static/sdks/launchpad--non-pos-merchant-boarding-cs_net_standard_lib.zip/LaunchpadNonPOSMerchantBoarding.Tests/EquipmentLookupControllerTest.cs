// <copyright file="EquipmentLookupControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Controllers;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Response;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// EquipmentLookupControllerTest.
    /// </summary>
    [TestFixture]
    public class EquipmentLookupControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private EquipmentLookupController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.EquipmentLookupController;
        }

        /// <summary>
        /// Fetches a list of valid terminal customizations and peripherals, such as electing to password protect a void..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetAdditionalConfigurations()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            string logicalApplicationId = "1073";

            // Perform API call
            Standard.Models.AdditionalConfigurationsResponse result = null;
            try
            {
                result = await this.controller.GetAdditionalConfigurationsAsync(externalRefId, vCorrelationId, logicalApplicationId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve applicable equipment for an existing application..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetEquipmentSupported()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");

            // Perform API call
            Standard.Models.InlineResponse200 result = null;
            try
            {
                result = await this.controller.GetEquipmentSupportedAsync(externalRefId, vCorrelationId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }
    }
}