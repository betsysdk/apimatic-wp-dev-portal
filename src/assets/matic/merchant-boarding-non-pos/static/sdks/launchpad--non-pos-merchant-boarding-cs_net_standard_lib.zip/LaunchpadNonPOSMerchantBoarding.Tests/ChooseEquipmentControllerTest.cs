// <copyright file="ChooseEquipmentControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Controllers;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Response;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// ChooseEquipmentControllerTest.
    /// </summary>
    [TestFixture]
    public class ChooseEquipmentControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private ChooseEquipmentController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.ChooseEquipmentController;
        }

        /// <summary>
        /// Gets the terminal configuration information for a specific partner..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetTerminalInfo()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Standard.Models.ContentTypeEnum contentType = ApiHelper.JsonDeserialize<Standard.Models.ContentTypeEnum>("\"application/json\"");
            string locationId = null;
            string merchantId = null;

            // Perform API call
            Standard.Models.EquipmentSetup result = null;
            try
            {
                result = await this.controller.GetTerminalInfoAsync(externalRefId, vCorrelationId, contentType, locationId, merchantId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Updates terminal configurations..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestUpdateTerminal()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Standard.Models.EquipmentSetup body = ApiHelper.JsonDeserialize<Standard.Models.EquipmentSetup>("{\"shippingOption\":\"next day\",\"terminals\":[{\"terminalConfigs\":{\"requestId\":\"41231\",\"terminalId\":\"67\",\"terminalModel\":\"VAR - Xpient Solutions\",\"price\":187.99,\"quantity\":1,\"logicalApplicationId\":\"194\",\"accessMethod\":\"SSL\",\"paymentMethod\":\"PURCHASE / SALE\",\"environmentName\":\"Restaurant\"},\"products\":[{\"productId\":\"1\",\"productName\":\"Credit\"}]}]}");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Standard.Models.ContentTypeEnum contentType = ApiHelper.JsonDeserialize<Standard.Models.ContentTypeEnum>("\"application/json\"");
            string locationId = null;
            string merchantId = null;

            // Perform API call
            try
            {
                await this.controller.UpdateTerminalAsync(externalRefId, body, vCorrelationId, contentType, locationId, merchantId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Sets up terminal configurations..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestConfigStandaloneTerminal()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Standard.Models.EquipmentSetup body = ApiHelper.JsonDeserialize<Standard.Models.EquipmentSetup>("{\"shippingOption\":\"next day\",\"terminals\":[{\"terminalConfigs\":{\"requestId\":\"41231\",\"terminalId\":\"67\",\"terminalModel\":\"VAR - Xpient Solutions\",\"price\":187.99,\"quantity\":1,\"logicalApplicationId\":\"194\",\"accessMethod\":\"SSL\",\"paymentMethod\":\"PURCHASE / SALE\",\"environmentName\":\"Restaurant\"},\"products\":[{\"productId\":\"1\",\"productName\":\"Credit\"}]}]}");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Standard.Models.ContentTypeEnum contentType = ApiHelper.JsonDeserialize<Standard.Models.ContentTypeEnum>("\"application/json\"");
            string locationId = null;
            string merchantId = null;

            // Perform API call
            try
            {
                await this.controller.ConfigStandaloneTerminalAsync(externalRefId, body, vCorrelationId, contentType, locationId, merchantId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }
    }
}