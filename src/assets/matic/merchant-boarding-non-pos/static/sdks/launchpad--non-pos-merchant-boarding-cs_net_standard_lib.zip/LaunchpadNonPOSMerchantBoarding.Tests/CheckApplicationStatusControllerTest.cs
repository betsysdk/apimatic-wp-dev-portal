// <copyright file="CheckApplicationStatusControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Controllers;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Response;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// CheckApplicationStatusControllerTest.
    /// </summary>
    [TestFixture]
    public class CheckApplicationStatusControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private CheckApplicationStatusController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.CheckApplicationStatusController;
        }

        /// <summary>
        /// Retrieves the status of a contract when passed with an externalRefID. Both the externalRefID and authorization header are required..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetApplicationStatus()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");

            // Perform API call
            Standard.Models.ApplicationStatus result = null;
            try
            {
                result = await this.controller.GetApplicationStatusAsync(externalRefId, vCorrelationId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Use this endpoint to get signer status.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestFetchSignerStatus()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Standard.Models.ContentTypeEnum contentType = ApiHelper.JsonDeserialize<Standard.Models.ContentTypeEnum>("\"application/json\"");

            // Perform API call
            Standard.Models.SignerStatus result = null;
            try
            {
                result = await this.controller.FetchSignerStatusAsync(externalRefId, vCorrelationId, contentType);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Use this endpoint to get a application's status history..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestFetchApplicationStatusHistory()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");

            // Perform API call
            Standard.Models.StatusHistoryResponse result = null;
            try
            {
                result = await this.controller.FetchApplicationStatusHistoryAsync(externalRefId, vCorrelationId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }
    }
}