// <copyright file="InitiateBoardingApplicationControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Controllers;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Response;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// InitiateBoardingApplicationControllerTest.
    /// </summary>
    [TestFixture]
    public class InitiateBoardingApplicationControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private InitiateBoardingApplicationController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.InitiateBoardingApplicationController;
        }

        /// <summary>
        /// Retrieves existing application data..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestFetchApplication()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");

            // Perform API call
            Standard.Models.ExistingApplication result = null;
            try
            {
                result = await this.controller.FetchApplicationAsync(externalRefId, vCorrelationId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }
    }
}