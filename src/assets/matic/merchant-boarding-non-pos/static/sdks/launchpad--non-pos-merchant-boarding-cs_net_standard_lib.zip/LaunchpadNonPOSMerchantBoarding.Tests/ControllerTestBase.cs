// <copyright file="ControllerTestBase.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Types;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Authentication;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Models;
    using NUnit.Framework;

    /// <summary>
    /// ControllerTestBase Class.
    /// </summary>
    [TestFixture]
    public class ControllerTestBase
    {
        /// <summary>
        /// Assert precision.
        /// </summary>
        protected const double AssertPrecision = 0.1;

        /// <summary>
        /// Gets HttpCallBackHandler.
        /// </summary>
        internal HttpCallBack HttpCallBack { get; private set; } = new HttpCallBack();

        /// <summary>
        /// Gets LaunchpadNonPOSMerchantBoardingClient Client.
        /// </summary>
        protected LaunchpadNonPOSMerchantBoardingClient Client { get; private set; }

        /// <summary>
        /// Set up the client.
        /// </summary>
        [OneTimeSetUp]
        public void SetUp()
        {
            LaunchpadNonPOSMerchantBoardingClient config = LaunchpadNonPOSMerchantBoardingClient.CreateFromEnvironment();
            this.Client = config.ToBuilder()
                .HttpCallBack(HttpCallBack)
                .Build();
        }
    }
}