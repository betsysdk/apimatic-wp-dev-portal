
# Schema

## Structure

`Schema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | - |

## Example (as JSON)

```json
{
  "id": 82
}
```

