
# Contact

## Structure

`Contact`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Type1Enum`](../../doc/models/type-1-enum.md) | Required | Type of merchant contact.<br><br>1) Only primary contact<br>   is mandatory. May be the same as any owner contact information.<br>2) For primary contact, firstName, lastName, phoneNumber and email are mandatory during POST.<br>3) For all other contact types, firstName and lastName are mandatory during POST. |
| `Title` | `string` | Optional | Required for AMEX acquired merchants otherwise optional.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `30`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `FirstName` | `string` | Required | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `MiddleInitial` | `string` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `LastName` | `string` | Required | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `Ssn` | `string` | Optional | Social security number. Do not include dashes.<br>**Constraints**: *Pattern*: `^[0-9]{9}$` |
| `BirthDate` | `DateTime?` | Optional | Date of Birth (CCYY-MM-DD). Must be at least 18 years old. |
| `PhoneNumber` | `string` | Required | 10-digit phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `PhoneNumberExt` | `string` | Optional | Phone number extension. Up to 8 digits of the format 12345678.<br>**Constraints**: *Maximum Length*: `8`, *Pattern*: `^[0-9]{1,8}$` |
| `PhoneType` | [`PhoneTypeEnum?`](../../doc/models/phone-type-enum.md) | Optional | Phone type. |
| `AlternatePhone` | `string` | Optional | 10-digit alternate phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `AlternatePhoneType` | [`AlternatePhoneTypeEnum?`](../../doc/models/alternate-phone-type-enum.md) | Optional | Alternate phone type. |
| `Email` | `string` | Required | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` |
| `FaxNumber` | `string` | Optional | 10-digit fax number of the format 5131234567<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |

## Example (as JSON)

```json
{
  "type": "Primary Contact",
  "title": "President",
  "firstName": "Todd",
  "middleInitial": "M",
  "lastName": "Davis",
  "ssn": "123456789",
  "birthDate": "2000-03-23",
  "phoneNumber": "5131234567",
  "phoneNumberExt": "1234",
  "phoneType": "mobile",
  "alternatePhone": "5131234567",
  "alternatePhoneType": "home",
  "email": "test@gmail.com",
  "faxNumber": "5131234567"
}
```

