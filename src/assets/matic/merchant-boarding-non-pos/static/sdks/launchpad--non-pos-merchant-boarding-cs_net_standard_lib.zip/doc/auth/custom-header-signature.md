
# Custom Header Signature



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| Authorization | `string` | `License format is WORLDPAY license='xxxx'` | `Authorization` | `Authorization` |



**Note:** Auth credentials can be set using `CustomHeaderAuthenticationCredentials` in the client builder and accessed through `CustomHeaderAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```csharp
LaunchpadNonPOSMerchantBoarding.Standard.LaunchpadNonPOSMerchantBoardingClient client = new LaunchpadNonPOSMerchantBoarding.Standard.LaunchpadNonPOSMerchantBoardingClient.Builder()
    .CustomHeaderAuthenticationCredentials(
        new CustomHeaderAuthenticationModel.Builder(
            "Authorization"
        )
        .Build())
    .Build();
```


