
# Seasonal Enum

Does the business operate seasonally?

## Enumeration

`SeasonalEnum`

## Fields

| Name |
|  --- |
| `Yes` |
| `No` |

## Example

```
Yes
```

