
# Warranty Enum

Does the business offer warranties, dues, subscriptions, memberships, or other extended services?

## Enumeration

`WarrantyEnum`

## Fields

| Name |
|  --- |
| `Enum1YEAR` |
| `Enum30DAY` |
| `Enum60DAY` |
| `Enum90DAY` |
| `LIFETIME` |
| `NO` |

## Example

```
1 YEAR
```

