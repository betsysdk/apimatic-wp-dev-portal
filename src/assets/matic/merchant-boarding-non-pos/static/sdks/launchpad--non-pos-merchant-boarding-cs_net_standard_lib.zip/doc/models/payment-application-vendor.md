
# Payment Application Vendor

A payment application is installed software developed for processing various payments types: Credit, Debit, Gift, Checks, etc. and can be integrated with a POS system or used in a standalone manner.

## Structure

`PaymentApplicationVendor`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentApplicationId` | `string` | Optional | Payment application ID |
| `PaymentApplicationName` | `string` | Optional | - |
| `VendorId` | `string` | Optional | Vendor ID for the payment application. |
| `Version` | `string` | Optional | Payment application version. |
| `Reseller` | `string` | Optional | Reseller |
| `LastUpgradeDate` | `DateTime?` | Optional | Last date payment application was upgraded. |
| `Notes` | `string` | Optional | Custom notes can go here. |

## Example (as JSON)

```json
{
  "paymentApplicationId": "9",
  "paymentApplicationName": "PurchaseExpress",
  "vendorId": "4",
  "version": "1",
  "reseller": "Agilysys Inc",
  "lastUpgradeDate": "02/18/2012 00:00:00",
  "notes": "Paymetric Gateway v3"
}
```

