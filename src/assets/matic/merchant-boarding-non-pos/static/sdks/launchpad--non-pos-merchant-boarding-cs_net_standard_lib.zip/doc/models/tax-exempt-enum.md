
# Tax Exempt Enum

## Enumeration

`TaxExemptEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

