
# Ach Type Enum

Check deposit type

## Enumeration

`AchTypeEnum`

## Fields

| Name |
|  --- |
| `EnumCommercialChecking` |
| `EnumPrivateChecking` |

## Example

```
Commercial Checking
```

