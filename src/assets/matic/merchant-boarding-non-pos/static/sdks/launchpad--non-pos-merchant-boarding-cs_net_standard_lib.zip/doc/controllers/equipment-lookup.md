# Equipment Lookup

```csharp
EquipmentLookupController equipmentLookupController = client.EquipmentLookupController;
```

## Class Name

`EquipmentLookupController`

## Methods

* [Get Additional Configurations](../../doc/controllers/equipment-lookup.md#get-additional-configurations)
* [Get Equipment Supported](../../doc/controllers/equipment-lookup.md#get-equipment-supported)


# Get Additional Configurations

Fetches a list of valid terminal customizations and peripherals, such as electing to password protect a void.

```csharp
GetAdditionalConfigurationsAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null,
    string logicalApplicationId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `logicalApplicationId` | `string` | Header, Optional | Logical App ID of the terminal. |

## Response Type

[`Task<Models.AdditionalConfigurationsResponse>`](../../doc/models/additional-configurations-response.md)

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
string logicalApplicationId = "1073";
try
{
    AdditionalConfigurationsResponse result = await equipmentLookupController.GetAdditionalConfigurationsAsync(
        externalRefId,
        vCorrelationId,
        logicalApplicationId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Equipment Supported

Retrieve applicable equipment for an existing application.

```csharp
GetEquipmentSupportedAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`Task<Models.InlineResponse200>`](../../doc/models/inline-response-200.md)

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
try
{
    InlineResponse200 result = await equipmentLookupController.GetEquipmentSupportedAsync(
        externalRefId,
        vCorrelationId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

