
# Inline Response 200

## Structure

`InlineResponse200`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Equipment` | [`List<InlineResponse200Equipment>`](../../doc/models/inline-response-200-equipment.md) | Optional | - |

## Example (as JSON)

```json
{
  "equipment": [
    {
      "id": "id6",
      "name": "name6",
      "logicalApplicationId": "logicalApplicationId0",
      "environment": "environment2"
    },
    {
      "id": "id6",
      "name": "name6",
      "logicalApplicationId": "logicalApplicationId0",
      "environment": "environment2"
    }
  ]
}
```

