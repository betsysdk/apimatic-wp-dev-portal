
# Payment Method Enum

Payment method for the selected terminal.

## Enumeration

`PaymentMethodEnum`

## Fields

| Name |
|  --- |
| `EnumPURCHASESALE` |
| `EnumREPROGRAMOWN` |
| `EnumMONTHTOMONTHRENTAL` |
| `LEASE` |

## Example

```
PURCHASE / SALE
```

