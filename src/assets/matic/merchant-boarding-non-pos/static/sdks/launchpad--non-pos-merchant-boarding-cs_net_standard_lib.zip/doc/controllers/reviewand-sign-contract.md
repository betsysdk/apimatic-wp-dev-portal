# Reviewand Sign Contract

```csharp
ReviewandSignContractController reviewandSignContractController = client.ReviewandSignContractController;
```

## Class Name

`ReviewandSignContractController`

## Methods

* [Get Contract](../../doc/controllers/reviewand-sign-contract.md#get-contract)
* [Docusign Link](../../doc/controllers/reviewand-sign-contract.md#docusign-link)


# Get Contract

Returns a PDF contract to be signed.

```csharp
GetContractAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

`Task<dynamic>`

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
try
{
    dynamic result = await reviewAndSignContractController.GetContractAsync(
        externalRefId,
        vCorrelationId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Docusign Link

Retrieves a Docusign link to view the contract.

```csharp
DocusignLinkAsync(
    Models.DocumentLink body,
    Guid? vCorrelationId = null,
    Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`DocumentLink`](../../doc/models/document-link.md) | Body, Required | - |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum?`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`Task<Models.DocuSignLink>`](../../doc/models/docu-sign-link.md)

## Example Usage

```csharp
DocumentLink body = new DocumentLink
{
    ExternalRefId = "df8a6d82-3bb4-4f3b-ba18-57a5981ede8e",
    ReturnUrl = "https://docusign.com",
};

Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum? contentType = ContentTypeEnum.EnumApplicationjson;
try
{
    DocuSignLink result = await reviewAndSignContractController.DocusignLinkAsync(
        body,
        vCorrelationId,
        contentType
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

