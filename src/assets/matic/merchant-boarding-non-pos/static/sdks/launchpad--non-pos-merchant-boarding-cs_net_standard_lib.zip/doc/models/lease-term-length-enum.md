
# Lease Term Length Enum

Lease term for the peripheral

## Enumeration

`LeaseTermLengthEnum`

## Fields

| Name |
|  --- |
| `Enum24` |
| `Enum36` |
| `Enum48` |
| `Enum60` |

## Example

```
24
```

