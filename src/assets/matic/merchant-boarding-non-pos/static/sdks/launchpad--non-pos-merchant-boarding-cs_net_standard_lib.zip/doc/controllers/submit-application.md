# Submit Application

```csharp
SubmitApplicationController submitApplicationController = client.SubmitApplicationController;
```

## Class Name

`SubmitApplicationController`

## Methods

* [Validate Board](../../doc/controllers/submit-application.md#validate-board)
* [Inititate Board](../../doc/controllers/submit-application.md#inititate-board)


# Validate Board

Begins the merchant validation process before boarding after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```csharp
ValidateBoardAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null,
    Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum?`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

`Task`

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum? contentType = ContentTypeEnum.EnumApplicationjson;
try
{
    await submitApplicationController.ValidateBoardAsync(
        externalRefId,
        vCorrelationId,
        contentType
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Inititate Board

Begins the merchant boarding process after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```csharp
InititateBoardAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null,
    Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
    string threatmetrixId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum?`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `threatmetrixId` | `string` | Header, Optional | A unique session id |

## Response Type

`Task`

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum? contentType = ContentTypeEnum.EnumApplicationjson;
try
{
    await submitApplicationController.InititateBoardAsync(
        externalRefId,
        vCorrelationId,
        contentType
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

