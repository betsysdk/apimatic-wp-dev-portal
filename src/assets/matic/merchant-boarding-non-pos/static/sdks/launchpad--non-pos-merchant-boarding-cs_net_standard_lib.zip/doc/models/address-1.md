
# Address 1

## Structure

`Address1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`AddressTypeEnum`](../../doc/models/address-type-enum.md) | Required | Address Type<br><br>1) Physical address is mandatory.<br>2) If equipment needs to be sent to a different location than the physical address, then shipping address should be added.<br>3) For any address type, addressLine1, city, state, postalCode and country are mandatory. |
| `AddressLine1` | `string` | Required | Address Line 1. Field for house number, street and direction.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `AddressLine2` | `string` | Optional | Address Line 2. Field for apartment or suite numbers, etc.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `City` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `28`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `State` | [`State1Enum`](../../doc/models/state-1-enum.md) | Required | Valid US state, commonwealth, and territory codes are allowed. |
| `Country` | `string` | Required, Constant | Only United States is allowed.<br>**Default**: `"United States"` |
| `PostalCode` | `string` | Required | Postal code / zip code. The postal code must be valid for the address' country code.<br>**Constraints**: *Minimum Length*: `5`, *Maximum Length*: `5`, *Pattern*: `^[0-9]{5}$` |
| `PostalCodeExtension` | `string` | Optional | Postal code / zip code extension.  The postal code extension must be valid for the address' country code.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `4`, *Pattern*: `^[0-9]{4}$` |

## Example (as JSON)

```json
{
  "type": "Physical Address",
  "addressLine1": "4355 N Coalwhipe St.",
  "addressLine2": "suite 104",
  "city": "Denver",
  "state": "CO",
  "country": "United States",
  "postalCode": "12345",
  "postalCodeExtension": "1234"
}
```

