
# Terminal

## Structure

`Terminal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TerminalConfigs` | [`TerminalConfig`](../../doc/models/terminal-config.md) | Required | - |
| `Customizations` | [`List<TerminalCustomization>`](../../doc/models/terminal-customization.md) | Optional | - |
| `Products` | [`List<Product>`](../../doc/models/product.md) | Required | - |
| `Peripherals` | [`List<Peripheral>`](../../doc/models/peripheral.md) | Optional | - |
| `Vendors` | [`List<PaymentApplicationVendor>`](../../doc/models/payment-application-vendor.md) | Optional | - |
| `Gateways` | [`List<Gateway>`](../../doc/models/gateway.md) | Optional | - |
| `Supply` | [`List<TerminalSupply>`](../../doc/models/terminal-supply.md) | Optional | - |
| `Deployment` | [`TerminalDeployment`](../../doc/models/terminal-deployment.md) | Optional | - |

## Example (as JSON)

```json
{
  "terminalConfigs": {
    "requestId": "41231",
    "terminalId": "iCT220",
    "terminalModel": "Ingenico iCT220 CTLS 3.X Dial",
    "price": 187.99,
    "quantity": 1,
    "logicalApplicationId": "MONE510",
    "accessMethod": "SSL",
    "paymentMethod": "PURCHASE / SALE",
    "environmentName": "Retail",
    "isVar": false,
    "emvCapable": true,
    "leaseId": "12",
    "leaseTermLength": "24",
    "terminalSequenceNumber": "14",
    "specialCustomizations": "Mulitple merchant setup is Yes"
  },
  "products": [
    {
      "productId": "1",
      "productName": "Debit"
    }
  ],
  "customizations": [
    {
      "customizationId": "customizationId0",
      "customizationName": "customizationName6",
      "customizationFieldValue": "customizationFieldValue8"
    },
    {
      "customizationId": "customizationId0",
      "customizationName": "customizationName6",
      "customizationFieldValue": "customizationFieldValue8"
    }
  ],
  "peripherals": [
    {
      "peripheralId": "peripheralId2",
      "peripheralType": "peripheralType6",
      "model": "model4",
      "leaseId": "leaseId2",
      "leaseTermLength": "48"
    }
  ],
  "vendors": [
    {
      "paymentApplicationId": "paymentApplicationId2",
      "paymentApplicationName": "paymentApplicationName6",
      "vendorId": "vendorId0",
      "version": "version4",
      "reseller": "reseller6"
    },
    {
      "paymentApplicationId": "paymentApplicationId2",
      "paymentApplicationName": "paymentApplicationName6",
      "vendorId": "vendorId0",
      "version": "version4",
      "reseller": "reseller6"
    },
    {
      "paymentApplicationId": "paymentApplicationId2",
      "paymentApplicationName": "paymentApplicationName6",
      "vendorId": "vendorId0",
      "version": "version4",
      "reseller": "reseller6"
    }
  ],
  "gateways": [
    {
      "gatewayId": "gatewayId8",
      "gatewayName": "gatewayName0",
      "notes": "notes4"
    },
    {
      "gatewayId": "gatewayId8",
      "gatewayName": "gatewayName0",
      "notes": "notes4"
    }
  ],
  "supply": [
    {
      "supplyType": "supplyType0",
      "name": "name4",
      "quantity": 240,
      "total": "total6"
    }
  ]
}
```

