// <copyright file="RoleName1Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// RoleName1Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum RoleName1Enum
    {
        /// <summary>
        /// SalesRep.
        /// </summary>
        [EnumMember(Value = "SalesRep")]
        SalesRep,

        /// <summary>
        /// Merchant.
        /// </summary>
        [EnumMember(Value = "Merchant")]
        Merchant,

        /// <summary>
        /// Signer2.
        /// </summary>
        [EnumMember(Value = "Signer2")]
        Signer2,

        /// <summary>
        /// Signer3.
        /// </summary>
        [EnumMember(Value = "Signer3")]
        Signer3,

        /// <summary>
        /// Signer4.
        /// </summary>
        [EnumMember(Value = "Signer4")]
        Signer4,

        /// <summary>
        /// Signer5.
        /// </summary>
        [EnumMember(Value = "Signer5")]
        Signer5,

        /// <summary>
        /// Signer6.
        /// </summary>
        [EnumMember(Value = "Signer6")]
        Signer6,

        /// <summary>
        /// Signer7.
        /// </summary>
        [EnumMember(Value = "Signer7")]
        Signer7,

        /// <summary>
        /// Signer8.
        /// </summary>
        [EnumMember(Value = "Signer8")]
        Signer8,

        /// <summary>
        /// Guarantor2.
        /// </summary>
        [EnumMember(Value = "Guarantor2")]
        Guarantor2,

        /// <summary>
        /// Guarantor3.
        /// </summary>
        [EnumMember(Value = "Guarantor3")]
        Guarantor3,

        /// <summary>
        /// Guarantor4.
        /// </summary>
        [EnumMember(Value = "Guarantor4")]
        Guarantor4
    }
}