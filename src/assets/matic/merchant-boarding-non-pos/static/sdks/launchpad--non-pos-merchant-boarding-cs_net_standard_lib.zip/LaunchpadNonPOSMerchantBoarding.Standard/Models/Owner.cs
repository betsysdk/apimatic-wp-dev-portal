// <copyright file="Owner.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Owner.
    /// </summary>
    public class Owner
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Owner"/> class.
        /// </summary>
        public Owner()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Owner"/> class.
        /// </summary>
        /// <param name="type">type.</param>
        /// <param name="firstName">firstName.</param>
        /// <param name="lastName">lastName.</param>
        /// <param name="phoneNumber">phoneNumber.</param>
        /// <param name="email">email.</param>
        /// <param name="addressLine1">addressLine1.</param>
        /// <param name="city">city.</param>
        /// <param name="state">state.</param>
        /// <param name="country">country.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="title">title.</param>
        /// <param name="middleInitial">middleInitial.</param>
        /// <param name="phoneNumberExt">phoneNumberExt.</param>
        /// <param name="phoneType">phoneType.</param>
        /// <param name="alternatePhone">alternatePhone.</param>
        /// <param name="alternatePhoneType">alternatePhoneType.</param>
        /// <param name="faxNumber">faxNumber.</param>
        /// <param name="ownershipPercentage">ownershipPercentage.</param>
        /// <param name="ssn">ssn.</param>
        /// <param name="dob">dob.</param>
        /// <param name="addressLine2">addressLine2.</param>
        /// <param name="postalCodeExtension">postalCodeExtension.</param>
        /// <param name="identification">identification.</param>
        public Owner(
            Models.TypeEnum type,
            string firstName,
            string lastName,
            string phoneNumber,
            string email,
            string addressLine1,
            string city,
            Models.StateEnum state,
            string country,
            string postalCode,
            string title = null,
            string middleInitial = null,
            string phoneNumberExt = null,
            Models.PhoneTypeEnum? phoneType = null,
            string alternatePhone = null,
            Models.AlternatePhoneTypeEnum? alternatePhoneType = null,
            string faxNumber = null,
            int? ownershipPercentage = null,
            string ssn = null,
            DateTime? dob = null,
            string addressLine2 = null,
            string postalCodeExtension = null,
            List<Models.Identification> identification = null)
        {
            this.Type = type;
            this.Title = title;
            this.FirstName = firstName;
            this.MiddleInitial = middleInitial;
            this.LastName = lastName;
            this.PhoneNumber = phoneNumber;
            this.PhoneNumberExt = phoneNumberExt;
            this.PhoneType = phoneType;
            this.AlternatePhone = alternatePhone;
            this.AlternatePhoneType = alternatePhoneType;
            this.FaxNumber = faxNumber;
            this.Email = email;
            this.OwnershipPercentage = ownershipPercentage;
            this.Ssn = ssn;
            this.Dob = dob;
            this.AddressLine1 = addressLine1;
            this.AddressLine2 = addressLine2;
            this.City = city;
            this.State = state;
            this.Country = country;
            this.PostalCode = postalCode;
            this.PostalCodeExtension = postalCodeExtension;
            this.Identification = identification;
        }

        /// <summary>
        /// The Owner Type. Please note the above Ownership Types where a Control Owner is required.
        /// </summary>
        [JsonProperty("type")]
        public Models.TypeEnum Type { get; set; }

        /// <summary>
        /// Required for AMEX acquired merchants otherwise optional.
        /// </summary>
        [JsonProperty("title", NullValueHandling = NullValueHandling.Ignore)]
        public string Title { get; set; }

        /// <summary>
        /// First name. Region based validations will be applied to this field.
        /// </summary>
        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        /// <summary>
        /// Middle initial.
        /// </summary>
        [JsonProperty("middleInitial", NullValueHandling = NullValueHandling.Ignore)]
        public string MiddleInitial { get; set; }

        /// <summary>
        /// Last name. Region based validations will be applied to this field.
        /// </summary>
        [JsonProperty("lastName")]
        public string LastName { get; set; }

        /// <summary>
        /// 10-digit phone number of the format  5131234567.
        /// </summary>
        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Phone number extension. Up to 8 digits of the format 12345678.
        /// </summary>
        [JsonProperty("phoneNumberExt", NullValueHandling = NullValueHandling.Ignore)]
        public string PhoneNumberExt { get; set; }

        /// <summary>
        /// Phone type.
        /// </summary>
        [JsonProperty("phoneType", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PhoneTypeEnum? PhoneType { get; set; }

        /// <summary>
        /// 10-digit alternate phone number of the format  5131234567.
        /// </summary>
        [JsonProperty("alternatePhone", NullValueHandling = NullValueHandling.Ignore)]
        public string AlternatePhone { get; set; }

        /// <summary>
        /// Alternate phone type.
        /// </summary>
        [JsonProperty("alternatePhoneType", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AlternatePhoneTypeEnum? AlternatePhoneType { get; set; }

        /// <summary>
        /// 10-digit fax number of the format 5131234567
        /// </summary>
        [JsonProperty("faxNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Email address of the contact. Must have @ and a .
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// Ownership stake percentage.
        /// </summary>
        [JsonProperty("ownershipPercentage", NullValueHandling = NullValueHandling.Ignore)]
        public int? OwnershipPercentage { get; set; }

        /// <summary>
        /// Social security number. Do not include dashes.
        /// </summary>
        [JsonProperty("ssn", NullValueHandling = NullValueHandling.Ignore)]
        public string Ssn { get; set; }

        /// <summary>
        /// Date of Birth (CCYY-MM-DD). Must be at least 18 years old.
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("dob", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? Dob { get; set; }

        /// <summary>
        /// Address Line 1. Field for house number, street and direction.
        /// </summary>
        [JsonProperty("addressLine1")]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Address Line 2. Field for apartment or suite numbers, etc.
        /// </summary>
        [JsonProperty("addressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets City.
        /// </summary>
        [JsonProperty("city")]
        public string City { get; set; }

        /// <summary>
        /// Valid US state, commonwealth, and territory codes are allowed.
        /// </summary>
        [JsonProperty("state")]
        public Models.StateEnum State { get; set; }

        /// <summary>
        /// Only United States is allowed.
        /// </summary>
        [JsonProperty("country")]
        public string Country { get; set; }

        /// <summary>
        /// Postal code / zip code. The postal code must be valid for the address' country code.
        /// </summary>
        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }

        /// <summary>
        /// Postal code / zip code extension.  The postal code extension must be valid for the address' country code.
        /// </summary>
        [JsonProperty("postalCodeExtension", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCodeExtension { get; set; }

        /// <summary>
        /// Optional. If any attribute in the identification object is populated then at least idNumber and idType are required.
        /// </summary>
        [JsonProperty("identification", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Identification> Identification { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Owner : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is Owner other &&                this.Type.Equals(other.Type) &&
                ((this.Title == null && other.Title == null) || (this.Title?.Equals(other.Title) == true)) &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.MiddleInitial == null && other.MiddleInitial == null) || (this.MiddleInitial?.Equals(other.MiddleInitial) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.PhoneNumber == null && other.PhoneNumber == null) || (this.PhoneNumber?.Equals(other.PhoneNumber) == true)) &&
                ((this.PhoneNumberExt == null && other.PhoneNumberExt == null) || (this.PhoneNumberExt?.Equals(other.PhoneNumberExt) == true)) &&
                ((this.PhoneType == null && other.PhoneType == null) || (this.PhoneType?.Equals(other.PhoneType) == true)) &&
                ((this.AlternatePhone == null && other.AlternatePhone == null) || (this.AlternatePhone?.Equals(other.AlternatePhone) == true)) &&
                ((this.AlternatePhoneType == null && other.AlternatePhoneType == null) || (this.AlternatePhoneType?.Equals(other.AlternatePhoneType) == true)) &&
                ((this.FaxNumber == null && other.FaxNumber == null) || (this.FaxNumber?.Equals(other.FaxNumber) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.OwnershipPercentage == null && other.OwnershipPercentage == null) || (this.OwnershipPercentage?.Equals(other.OwnershipPercentage) == true)) &&
                ((this.Ssn == null && other.Ssn == null) || (this.Ssn?.Equals(other.Ssn) == true)) &&
                ((this.Dob == null && other.Dob == null) || (this.Dob?.Equals(other.Dob) == true)) &&
                ((this.AddressLine1 == null && other.AddressLine1 == null) || (this.AddressLine1?.Equals(other.AddressLine1) == true)) &&
                ((this.AddressLine2 == null && other.AddressLine2 == null) || (this.AddressLine2?.Equals(other.AddressLine2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                this.State.Equals(other.State) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.PostalCodeExtension == null && other.PostalCodeExtension == null) || (this.PostalCodeExtension?.Equals(other.PostalCodeExtension) == true)) &&
                ((this.Identification == null && other.Identification == null) || (this.Identification?.Equals(other.Identification) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {this.Type}");
            toStringOutput.Add($"this.Title = {(this.Title == null ? "null" : this.Title)}");
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName)}");
            toStringOutput.Add($"this.MiddleInitial = {(this.MiddleInitial == null ? "null" : this.MiddleInitial)}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName)}");
            toStringOutput.Add($"this.PhoneNumber = {(this.PhoneNumber == null ? "null" : this.PhoneNumber)}");
            toStringOutput.Add($"this.PhoneNumberExt = {(this.PhoneNumberExt == null ? "null" : this.PhoneNumberExt)}");
            toStringOutput.Add($"this.PhoneType = {(this.PhoneType == null ? "null" : this.PhoneType.ToString())}");
            toStringOutput.Add($"this.AlternatePhone = {(this.AlternatePhone == null ? "null" : this.AlternatePhone)}");
            toStringOutput.Add($"this.AlternatePhoneType = {(this.AlternatePhoneType == null ? "null" : this.AlternatePhoneType.ToString())}");
            toStringOutput.Add($"this.FaxNumber = {(this.FaxNumber == null ? "null" : this.FaxNumber)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email)}");
            toStringOutput.Add($"this.OwnershipPercentage = {(this.OwnershipPercentage == null ? "null" : this.OwnershipPercentage.ToString())}");
            toStringOutput.Add($"this.Ssn = {(this.Ssn == null ? "null" : this.Ssn)}");
            toStringOutput.Add($"this.Dob = {(this.Dob == null ? "null" : this.Dob.ToString())}");
            toStringOutput.Add($"this.AddressLine1 = {(this.AddressLine1 == null ? "null" : this.AddressLine1)}");
            toStringOutput.Add($"this.AddressLine2 = {(this.AddressLine2 == null ? "null" : this.AddressLine2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City)}");
            toStringOutput.Add($"this.State = {this.State}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode)}");
            toStringOutput.Add($"this.PostalCodeExtension = {(this.PostalCodeExtension == null ? "null" : this.PostalCodeExtension)}");
            toStringOutput.Add($"this.Identification = {(this.Identification == null ? "null" : $"[{string.Join(", ", this.Identification)} ]")}");
        }
    }
}