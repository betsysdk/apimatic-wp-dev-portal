// <copyright file="Gateway.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Gateway.
    /// </summary>
    public class Gateway
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Gateway"/> class.
        /// </summary>
        public Gateway()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Gateway"/> class.
        /// </summary>
        /// <param name="gatewayId">gatewayId.</param>
        /// <param name="gatewayName">gatewayName.</param>
        /// <param name="notes">notes.</param>
        public Gateway(
            string gatewayId = null,
            string gatewayName = null,
            string notes = null)
        {
            this.GatewayId = gatewayId;
            this.GatewayName = gatewayName;
            this.Notes = notes;
        }

        /// <summary>
        /// Internally-generated gateway ID.
        /// </summary>
        [JsonProperty("gatewayId", NullValueHandling = NullValueHandling.Ignore)]
        public string GatewayId { get; set; }

        /// <summary>
        /// Gets or sets GatewayName.
        /// </summary>
        [JsonProperty("gatewayName", NullValueHandling = NullValueHandling.Ignore)]
        public string GatewayName { get; set; }

        /// <summary>
        /// Add any custom notes here.
        /// </summary>
        [JsonProperty("notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Gateway : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is Gateway other &&                ((this.GatewayId == null && other.GatewayId == null) || (this.GatewayId?.Equals(other.GatewayId) == true)) &&
                ((this.GatewayName == null && other.GatewayName == null) || (this.GatewayName?.Equals(other.GatewayName) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.GatewayId = {(this.GatewayId == null ? "null" : this.GatewayId)}");
            toStringOutput.Add($"this.GatewayName = {(this.GatewayName == null ? "null" : this.GatewayName)}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes)}");
        }
    }
}