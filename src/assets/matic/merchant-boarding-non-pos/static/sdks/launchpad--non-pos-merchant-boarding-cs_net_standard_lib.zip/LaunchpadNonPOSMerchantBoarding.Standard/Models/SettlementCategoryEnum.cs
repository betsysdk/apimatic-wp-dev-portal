// <copyright file="SettlementCategoryEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// SettlementCategoryEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum SettlementCategoryEnum
    {
        /// <summary>
        /// Deposits.
        /// </summary>
        [EnumMember(Value = "Deposits")]
        Deposits,

        /// <summary>
        /// Fees.
        /// </summary>
        [EnumMember(Value = "Fees")]
        Fees,

        /// <summary>
        /// Exceptions.
        /// </summary>
        [EnumMember(Value = "Exceptions")]
        Exceptions
    }
}