// <copyright file="KeyEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// KeyEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum KeyEnum
    {
        /// <summary>
        /// PartnerEmployeeId.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeId")]
        PartnerEmployeeId,

        /// <summary>
        /// PartnerEmployeeName.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeName")]
        PartnerEmployeeName,

        /// <summary>
        /// PartnerEmployeePhoneNumber.
        /// </summary>
        [EnumMember(Value = "partnerEmployeePhoneNumber")]
        PartnerEmployeePhoneNumber,

        /// <summary>
        /// PartnerEmployeeEmail.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeEmail")]
        PartnerEmployeeEmail,

        /// <summary>
        /// PartnerEmployeeType.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeType")]
        PartnerEmployeeType,

        /// <summary>
        /// PartnerEmployeeBranch.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeBranch")]
        PartnerEmployeeBranch,

        /// <summary>
        /// PartnerEmployeeCostCentre.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeCostCentre")]
        PartnerEmployeeCostCentre,

        /// <summary>
        /// PartnerEmployeeRegion.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeRegion")]
        PartnerEmployeeRegion,

        /// <summary>
        /// PartnerEmployeeOfficerCode.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeOfficerCode")]
        PartnerEmployeeOfficerCode,

        /// <summary>
        /// PartnerEmployeeCompany.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeCompany")]
        PartnerEmployeeCompany,

        /// <summary>
        /// PartnerEmployeeId2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeId2")]
        PartnerEmployeeId2,

        /// <summary>
        /// PartnerEmployeeName2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeName2")]
        PartnerEmployeeName2,

        /// <summary>
        /// PartnerEmployeePhoneNumber2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeePhoneNumber2")]
        PartnerEmployeePhoneNumber2,

        /// <summary>
        /// PartnerEmployeeEmail2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeEmail2")]
        PartnerEmployeeEmail2,

        /// <summary>
        /// PartnerEmployeeType2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeType2")]
        PartnerEmployeeType2,

        /// <summary>
        /// PartnerEmployeeBranch2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeBranch2")]
        PartnerEmployeeBranch2,

        /// <summary>
        /// PartnerEmployeeCostCentre2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeCostCentre2")]
        PartnerEmployeeCostCentre2,

        /// <summary>
        /// PartnerEmployeeRegion2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeRegion2")]
        PartnerEmployeeRegion2,

        /// <summary>
        /// PartnerEmployeeOfficerCode2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeOfficerCode2")]
        PartnerEmployeeOfficerCode2,

        /// <summary>
        /// PartnerEmployeeCompany2.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeCompany2")]
        PartnerEmployeeCompany2,

        /// <summary>
        /// PartnerEmployeeIndustry.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeIndustry")]
        PartnerEmployeeIndustry,

        /// <summary>
        /// PartnerLeadSource.
        /// </summary>
        [EnumMember(Value = "partnerLeadSource")]
        PartnerLeadSource,

        /// <summary>
        /// PartnerEmployeeRef.
        /// </summary>
        [EnumMember(Value = "partnerEmployeeRef")]
        PartnerEmployeeRef,

        /// <summary>
        /// PartnerMethod.
        /// </summary>
        [EnumMember(Value = "partnerMethod")]
        PartnerMethod,

        /// <summary>
        /// PartnerVipIndicator.
        /// </summary>
        [EnumMember(Value = "partnerVipIndicator")]
        PartnerVipIndicator,

        /// <summary>
        /// PartnerMarketRegion.
        /// </summary>
        [EnumMember(Value = "partnerMarketRegion")]
        PartnerMarketRegion,

        /// <summary>
        /// PartnerPromotionCampaign.
        /// </summary>
        [EnumMember(Value = "partnerPromotionCampaign")]
        PartnerPromotionCampaign,

        /// <summary>
        /// PartnerLeadType.
        /// </summary>
        [EnumMember(Value = "partnerLeadType")]
        PartnerLeadType,

        /// <summary>
        /// PartnerCustom1.
        /// </summary>
        [EnumMember(Value = "partnerCustom1")]
        PartnerCustom1,

        /// <summary>
        /// PartnerCustom2.
        /// </summary>
        [EnumMember(Value = "partnerCustom2")]
        PartnerCustom2,

        /// <summary>
        /// PartnerCustom3.
        /// </summary>
        [EnumMember(Value = "partnerCustom3")]
        PartnerCustom3,

        /// <summary>
        /// PartnerCustom4.
        /// </summary>
        [EnumMember(Value = "partnerCustom4")]
        PartnerCustom4,

        /// <summary>
        /// PartnerCustom5.
        /// </summary>
        [EnumMember(Value = "partnerCustom5")]
        PartnerCustom5,

        /// <summary>
        /// LeadInitiatedBy.
        /// </summary>
        [EnumMember(Value = "leadInitiatedBy")]
        LeadInitiatedBy
    }
}