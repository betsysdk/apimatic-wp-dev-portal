// <copyright file="BankAccount1.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BankAccount1.
    /// </summary>
    public class BankAccount1
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccount1"/> class.
        /// </summary>
        public BankAccount1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccount1"/> class.
        /// </summary>
        /// <param name="ddaType">ddaType.</param>
        /// <param name="achType">achType.</param>
        /// <param name="accountNumber">accountNumber.</param>
        /// <param name="routingNumber">routingNumber.</param>
        /// <param name="bankName">bankName.</param>
        public BankAccount1(
            Models.DdaTypeEnum? ddaType = null,
            Models.AchTypeEnum? achType = null,
            string accountNumber = null,
            string routingNumber = null,
            string bankName = null)
        {
            this.DdaType = ddaType;
            this.AchType = achType;
            this.AccountNumber = accountNumber;
            this.RoutingNumber = routingNumber;
            this.BankName = bankName;
        }

        /// <summary>
        /// Direct deposit account type.
        /// </summary>
        [JsonProperty("ddaType", NullValueHandling = NullValueHandling.Ignore)]
        public Models.DdaTypeEnum? DdaType { get; set; }

        /// <summary>
        /// Check deposit type
        /// </summary>
        [JsonProperty("achType", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AchTypeEnum? AchType { get; set; }

        /// <summary>
        /// Direct deposit account number.  Maximum 17 characters.
        /// </summary>
        [JsonProperty("accountNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Bank routing number. Must be 9 characters and pass ACH Mod-10 validation.
        /// </summary>
        [JsonProperty("routingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string RoutingNumber { get; set; }

        /// <summary>
        /// Bank name used for credit card processing services.
        /// </summary>
        [JsonProperty("bankName", NullValueHandling = NullValueHandling.Ignore)]
        public string BankName { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BankAccount1 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is BankAccount1 other &&                ((this.DdaType == null && other.DdaType == null) || (this.DdaType?.Equals(other.DdaType) == true)) &&
                ((this.AchType == null && other.AchType == null) || (this.AchType?.Equals(other.AchType) == true)) &&
                ((this.AccountNumber == null && other.AccountNumber == null) || (this.AccountNumber?.Equals(other.AccountNumber) == true)) &&
                ((this.RoutingNumber == null && other.RoutingNumber == null) || (this.RoutingNumber?.Equals(other.RoutingNumber) == true)) &&
                ((this.BankName == null && other.BankName == null) || (this.BankName?.Equals(other.BankName) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DdaType = {(this.DdaType == null ? "null" : this.DdaType.ToString())}");
            toStringOutput.Add($"this.AchType = {(this.AchType == null ? "null" : this.AchType.ToString())}");
            toStringOutput.Add($"this.AccountNumber = {(this.AccountNumber == null ? "null" : this.AccountNumber)}");
            toStringOutput.Add($"this.RoutingNumber = {(this.RoutingNumber == null ? "null" : this.RoutingNumber)}");
            toStringOutput.Add($"this.BankName = {(this.BankName == null ? "null" : this.BankName)}");
        }
    }
}