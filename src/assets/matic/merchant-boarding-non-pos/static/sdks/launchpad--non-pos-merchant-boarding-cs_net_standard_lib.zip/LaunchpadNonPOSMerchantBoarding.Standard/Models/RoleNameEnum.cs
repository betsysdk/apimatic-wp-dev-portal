// <copyright file="RoleNameEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// RoleNameEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum RoleNameEnum
    {
        /// <summary>
        /// SalesRep.
        /// </summary>
        [EnumMember(Value = "SalesRep")]
        SalesRep,

        /// <summary>
        /// Merchant.
        /// </summary>
        [EnumMember(Value = "Merchant")]
        Merchant,

        /// <summary>
        /// Reviewer.
        /// </summary>
        [EnumMember(Value = "Reviewer")]
        Reviewer,

        /// <summary>
        /// Signer2.
        /// </summary>
        [EnumMember(Value = "Signer2")]
        Signer2,

        /// <summary>
        /// Signer3.
        /// </summary>
        [EnumMember(Value = "Signer3")]
        Signer3,

        /// <summary>
        /// Signer4.
        /// </summary>
        [EnumMember(Value = "Signer4")]
        Signer4,

        /// <summary>
        /// Signer5.
        /// </summary>
        [EnumMember(Value = "Signer5")]
        Signer5,

        /// <summary>
        /// Signer6.
        /// </summary>
        [EnumMember(Value = "Signer6")]
        Signer6,

        /// <summary>
        /// Signer7.
        /// </summary>
        [EnumMember(Value = "Signer7")]
        Signer7,

        /// <summary>
        /// Signer8.
        /// </summary>
        [EnumMember(Value = "Signer8")]
        Signer8
    }
}