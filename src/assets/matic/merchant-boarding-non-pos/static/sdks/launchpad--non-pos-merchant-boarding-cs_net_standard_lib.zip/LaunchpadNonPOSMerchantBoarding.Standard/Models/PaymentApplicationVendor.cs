// <copyright file="PaymentApplicationVendor.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PaymentApplicationVendor.
    /// </summary>
    public class PaymentApplicationVendor
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentApplicationVendor"/> class.
        /// </summary>
        public PaymentApplicationVendor()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentApplicationVendor"/> class.
        /// </summary>
        /// <param name="paymentApplicationId">paymentApplicationId.</param>
        /// <param name="paymentApplicationName">paymentApplicationName.</param>
        /// <param name="vendorId">vendorId.</param>
        /// <param name="version">version.</param>
        /// <param name="reseller">reseller.</param>
        /// <param name="lastUpgradeDate">lastUpgradeDate.</param>
        /// <param name="notes">notes.</param>
        public PaymentApplicationVendor(
            string paymentApplicationId = null,
            string paymentApplicationName = null,
            string vendorId = null,
            string version = null,
            string reseller = null,
            DateTime? lastUpgradeDate = null,
            string notes = null)
        {
            this.PaymentApplicationId = paymentApplicationId;
            this.PaymentApplicationName = paymentApplicationName;
            this.VendorId = vendorId;
            this.Version = version;
            this.Reseller = reseller;
            this.LastUpgradeDate = lastUpgradeDate;
            this.Notes = notes;
        }

        /// <summary>
        /// Payment application ID
        /// </summary>
        [JsonProperty("paymentApplicationId", NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentApplicationId { get; set; }

        /// <summary>
        /// Gets or sets PaymentApplicationName.
        /// </summary>
        [JsonProperty("paymentApplicationName", NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentApplicationName { get; set; }

        /// <summary>
        /// Vendor ID for the payment application.
        /// </summary>
        [JsonProperty("vendorId", NullValueHandling = NullValueHandling.Ignore)]
        public string VendorId { get; set; }

        /// <summary>
        /// Payment application version.
        /// </summary>
        [JsonProperty("version", NullValueHandling = NullValueHandling.Ignore)]
        public string Version { get; set; }

        /// <summary>
        /// Reseller
        /// </summary>
        [JsonProperty("reseller", NullValueHandling = NullValueHandling.Ignore)]
        public string Reseller { get; set; }

        /// <summary>
        /// Last date payment application was upgraded.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("lastUpgradeDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LastUpgradeDate { get; set; }

        /// <summary>
        /// Custom notes can go here.
        /// </summary>
        [JsonProperty("notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PaymentApplicationVendor : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is PaymentApplicationVendor other &&                ((this.PaymentApplicationId == null && other.PaymentApplicationId == null) || (this.PaymentApplicationId?.Equals(other.PaymentApplicationId) == true)) &&
                ((this.PaymentApplicationName == null && other.PaymentApplicationName == null) || (this.PaymentApplicationName?.Equals(other.PaymentApplicationName) == true)) &&
                ((this.VendorId == null && other.VendorId == null) || (this.VendorId?.Equals(other.VendorId) == true)) &&
                ((this.Version == null && other.Version == null) || (this.Version?.Equals(other.Version) == true)) &&
                ((this.Reseller == null && other.Reseller == null) || (this.Reseller?.Equals(other.Reseller) == true)) &&
                ((this.LastUpgradeDate == null && other.LastUpgradeDate == null) || (this.LastUpgradeDate?.Equals(other.LastUpgradeDate) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaymentApplicationId = {(this.PaymentApplicationId == null ? "null" : this.PaymentApplicationId)}");
            toStringOutput.Add($"this.PaymentApplicationName = {(this.PaymentApplicationName == null ? "null" : this.PaymentApplicationName)}");
            toStringOutput.Add($"this.VendorId = {(this.VendorId == null ? "null" : this.VendorId)}");
            toStringOutput.Add($"this.Version = {(this.Version == null ? "null" : this.Version)}");
            toStringOutput.Add($"this.Reseller = {(this.Reseller == null ? "null" : this.Reseller)}");
            toStringOutput.Add($"this.LastUpgradeDate = {(this.LastUpgradeDate == null ? "null" : this.LastUpgradeDate.ToString())}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes)}");
        }
    }
}