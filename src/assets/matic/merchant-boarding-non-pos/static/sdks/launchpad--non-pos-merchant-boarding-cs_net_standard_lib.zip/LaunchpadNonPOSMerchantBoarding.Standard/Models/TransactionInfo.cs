// <copyright file="TransactionInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// TransactionInfo.
    /// </summary>
    public class TransactionInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransactionInfo"/> class.
        /// </summary>
        public TransactionInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TransactionInfo"/> class.
        /// </summary>
        /// <param name="annualSalesVolume">annualSalesVolume.</param>
        /// <param name="percentRetailSwipedTransactions">percentRetailSwipedTransactions.</param>
        /// <param name="averageTicket">averageTicket.</param>
        /// <param name="highestTicket">highestTicket.</param>
        /// <param name="currentProcessor">currentProcessor.</param>
        /// <param name="acceptChargebacks">acceptChargebacks.</param>
        /// <param name="chargebackPercent">chargebackPercent.</param>
        /// <param name="returnPercent">returnPercent.</param>
        /// <param name="cardNotPresentPercent">cardNotPresentPercent.</param>
        /// <param name="businessToBusinessPercent">businessToBusinessPercent.</param>
        /// <param name="internetTransactionPercent">internetTransactionPercent.</param>
        /// <param name="annualCreditSalesVolume">annualCreditSalesVolume.</param>
        /// <param name="annualDebitSalesVolume">annualDebitSalesVolume.</param>
        /// <param name="annualAmexVolume">annualAmexVolume.</param>
        /// <param name="amexAverageTicket">amexAverageTicket.</param>
        /// <param name="averageNumberofDays">averageNumberofDays.</param>
        public TransactionInfo(
            double annualSalesVolume,
            int percentRetailSwipedTransactions,
            double? averageTicket = null,
            double? highestTicket = null,
            string currentProcessor = null,
            Models.AcceptChargebacksEnum? acceptChargebacks = null,
            int? chargebackPercent = null,
            int? returnPercent = null,
            int? cardNotPresentPercent = null,
            int? businessToBusinessPercent = null,
            int? internetTransactionPercent = null,
            double? annualCreditSalesVolume = null,
            double? annualDebitSalesVolume = null,
            double? annualAmexVolume = null,
            double? amexAverageTicket = null,
            int? averageNumberofDays = null)
        {
            this.AnnualSalesVolume = annualSalesVolume;
            this.PercentRetailSwipedTransactions = percentRetailSwipedTransactions;
            this.AverageTicket = averageTicket;
            this.HighestTicket = highestTicket;
            this.CurrentProcessor = currentProcessor;
            this.AcceptChargebacks = acceptChargebacks;
            this.ChargebackPercent = chargebackPercent;
            this.ReturnPercent = returnPercent;
            this.CardNotPresentPercent = cardNotPresentPercent;
            this.BusinessToBusinessPercent = businessToBusinessPercent;
            this.InternetTransactionPercent = internetTransactionPercent;
            this.AnnualCreditSalesVolume = annualCreditSalesVolume;
            this.AnnualDebitSalesVolume = annualDebitSalesVolume;
            this.AnnualAmexVolume = annualAmexVolume;
            this.AmexAverageTicket = amexAverageTicket;
            this.AverageNumberofDays = averageNumberofDays;
        }

        /// <summary>
        /// Projected annual sales volume.
        /// </summary>
        [JsonProperty("annualSalesVolume")]
        public double AnnualSalesVolume { get; set; }

        /// <summary>
        /// Projected Percentage of daily card-present transactions.
        /// </summary>
        [JsonProperty("percentRetailSwipedTransactions")]
        public int PercentRetailSwipedTransactions { get; set; }

        /// <summary>
        /// Average ticket dollar amount.
        /// </summary>
        [JsonProperty("averageTicket", NullValueHandling = NullValueHandling.Ignore)]
        public double? AverageTicket { get; set; }

        /// <summary>
        /// Highest ticket dollar amount.
        /// </summary>
        [JsonProperty("highestTicket", NullValueHandling = NullValueHandling.Ignore)]
        public double? HighestTicket { get; set; }

        /// <summary>
        /// the current processor
        /// </summary>
        [JsonProperty("currentProcessor", NullValueHandling = NullValueHandling.Ignore)]
        public string CurrentProcessor { get; set; }

        /// <summary>
        /// Do you have more than 25 chargeback accepted in the last 12 months?
        /// </summary>
        [JsonProperty("acceptChargebacks", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AcceptChargebacksEnum? AcceptChargebacks { get; set; }

        /// <summary>
        /// Projected chargeback percentage.
        /// ```Required when acceptChargebacks is 'Yes'```
        /// ```Optional when acceptChargebacks is null or 'No'.```
        /// </summary>
        [JsonProperty("chargebackPercent", NullValueHandling = NullValueHandling.Ignore)]
        public int? ChargebackPercent { get; set; }

        /// <summary>
        /// Projected return percent of  goods sold
        /// </summary>
        [JsonProperty("returnPercent", NullValueHandling = NullValueHandling.Ignore)]
        public int? ReturnPercent { get; set; }

        /// <summary>
        /// Percent of card not present transactions.
        /// </summary>
        [JsonProperty("cardNotPresentPercent", NullValueHandling = NullValueHandling.Ignore)]
        public int? CardNotPresentPercent { get; set; }

        /// <summary>
        /// Percent of business-to-business transactions.
        /// </summary>
        [JsonProperty("businessToBusinessPercent", NullValueHandling = NullValueHandling.Ignore)]
        public int? BusinessToBusinessPercent { get; set; }

        /// <summary>
        /// Percent of internet transactions.
        /// </summary>
        [JsonProperty("internetTransactionPercent", NullValueHandling = NullValueHandling.Ignore)]
        public int? InternetTransactionPercent { get; set; }

        /// <summary>
        /// Projected annual credit card sales volume.
        /// </summary>
        [JsonProperty("annualCreditSalesVolume", NullValueHandling = NullValueHandling.Ignore)]
        public double? AnnualCreditSalesVolume { get; set; }

        /// <summary>
        /// Projected annual debit card sales volume.
        /// </summary>
        [JsonProperty("annualDebitSalesVolume", NullValueHandling = NullValueHandling.Ignore)]
        public double? AnnualDebitSalesVolume { get; set; }

        /// <summary>
        /// Projected annual Amex volume. ``` This field is required when you opt-in for Amex ```
        /// </summary>
        [JsonProperty("annualAmexVolume", NullValueHandling = NullValueHandling.Ignore)]
        public double? AnnualAmexVolume { get; set; }

        /// <summary>
        /// AverageTicket dollar amount for Amex.
        ///   ```This field is required when you opt-in for Amex```
        /// </summary>
        [JsonProperty("amexAverageTicket", NullValueHandling = NullValueHandling.Ignore)]
        public double? AmexAverageTicket { get; set; }

        /// <summary>
        /// <![CDATA[
        /// Average number of days from when cardholder is charged & when products or services are received IN FULL by cardholder.
        /// ]]>
        /// </summary>
        [JsonProperty("averageNumberofDays", NullValueHandling = NullValueHandling.Ignore)]
        public int? AverageNumberofDays { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TransactionInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is TransactionInfo other &&                this.AnnualSalesVolume.Equals(other.AnnualSalesVolume) &&
                this.PercentRetailSwipedTransactions.Equals(other.PercentRetailSwipedTransactions) &&
                ((this.AverageTicket == null && other.AverageTicket == null) || (this.AverageTicket?.Equals(other.AverageTicket) == true)) &&
                ((this.HighestTicket == null && other.HighestTicket == null) || (this.HighestTicket?.Equals(other.HighestTicket) == true)) &&
                ((this.CurrentProcessor == null && other.CurrentProcessor == null) || (this.CurrentProcessor?.Equals(other.CurrentProcessor) == true)) &&
                ((this.AcceptChargebacks == null && other.AcceptChargebacks == null) || (this.AcceptChargebacks?.Equals(other.AcceptChargebacks) == true)) &&
                ((this.ChargebackPercent == null && other.ChargebackPercent == null) || (this.ChargebackPercent?.Equals(other.ChargebackPercent) == true)) &&
                ((this.ReturnPercent == null && other.ReturnPercent == null) || (this.ReturnPercent?.Equals(other.ReturnPercent) == true)) &&
                ((this.CardNotPresentPercent == null && other.CardNotPresentPercent == null) || (this.CardNotPresentPercent?.Equals(other.CardNotPresentPercent) == true)) &&
                ((this.BusinessToBusinessPercent == null && other.BusinessToBusinessPercent == null) || (this.BusinessToBusinessPercent?.Equals(other.BusinessToBusinessPercent) == true)) &&
                ((this.InternetTransactionPercent == null && other.InternetTransactionPercent == null) || (this.InternetTransactionPercent?.Equals(other.InternetTransactionPercent) == true)) &&
                ((this.AnnualCreditSalesVolume == null && other.AnnualCreditSalesVolume == null) || (this.AnnualCreditSalesVolume?.Equals(other.AnnualCreditSalesVolume) == true)) &&
                ((this.AnnualDebitSalesVolume == null && other.AnnualDebitSalesVolume == null) || (this.AnnualDebitSalesVolume?.Equals(other.AnnualDebitSalesVolume) == true)) &&
                ((this.AnnualAmexVolume == null && other.AnnualAmexVolume == null) || (this.AnnualAmexVolume?.Equals(other.AnnualAmexVolume) == true)) &&
                ((this.AmexAverageTicket == null && other.AmexAverageTicket == null) || (this.AmexAverageTicket?.Equals(other.AmexAverageTicket) == true)) &&
                ((this.AverageNumberofDays == null && other.AverageNumberofDays == null) || (this.AverageNumberofDays?.Equals(other.AverageNumberofDays) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AnnualSalesVolume = {this.AnnualSalesVolume}");
            toStringOutput.Add($"this.PercentRetailSwipedTransactions = {this.PercentRetailSwipedTransactions}");
            toStringOutput.Add($"this.AverageTicket = {(this.AverageTicket == null ? "null" : this.AverageTicket.ToString())}");
            toStringOutput.Add($"this.HighestTicket = {(this.HighestTicket == null ? "null" : this.HighestTicket.ToString())}");
            toStringOutput.Add($"this.CurrentProcessor = {(this.CurrentProcessor == null ? "null" : this.CurrentProcessor)}");
            toStringOutput.Add($"this.AcceptChargebacks = {(this.AcceptChargebacks == null ? "null" : this.AcceptChargebacks.ToString())}");
            toStringOutput.Add($"this.ChargebackPercent = {(this.ChargebackPercent == null ? "null" : this.ChargebackPercent.ToString())}");
            toStringOutput.Add($"this.ReturnPercent = {(this.ReturnPercent == null ? "null" : this.ReturnPercent.ToString())}");
            toStringOutput.Add($"this.CardNotPresentPercent = {(this.CardNotPresentPercent == null ? "null" : this.CardNotPresentPercent.ToString())}");
            toStringOutput.Add($"this.BusinessToBusinessPercent = {(this.BusinessToBusinessPercent == null ? "null" : this.BusinessToBusinessPercent.ToString())}");
            toStringOutput.Add($"this.InternetTransactionPercent = {(this.InternetTransactionPercent == null ? "null" : this.InternetTransactionPercent.ToString())}");
            toStringOutput.Add($"this.AnnualCreditSalesVolume = {(this.AnnualCreditSalesVolume == null ? "null" : this.AnnualCreditSalesVolume.ToString())}");
            toStringOutput.Add($"this.AnnualDebitSalesVolume = {(this.AnnualDebitSalesVolume == null ? "null" : this.AnnualDebitSalesVolume.ToString())}");
            toStringOutput.Add($"this.AnnualAmexVolume = {(this.AnnualAmexVolume == null ? "null" : this.AnnualAmexVolume.ToString())}");
            toStringOutput.Add($"this.AmexAverageTicket = {(this.AmexAverageTicket == null ? "null" : this.AmexAverageTicket.ToString())}");
            toStringOutput.Add($"this.AverageNumberofDays = {(this.AverageNumberofDays == null ? "null" : this.AverageNumberofDays.ToString())}");
        }
    }
}