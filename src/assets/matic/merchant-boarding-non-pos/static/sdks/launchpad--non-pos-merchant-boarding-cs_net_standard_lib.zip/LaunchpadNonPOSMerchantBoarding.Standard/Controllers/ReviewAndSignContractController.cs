// <copyright file="ReviewAndSignContractController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// ReviewAndSignContractController.
    /// </summary>
    public class ReviewAndSignContractController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReviewAndSignContractController"/> class.
        /// </summary>
        internal ReviewAndSignContractController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Returns a PDF contract to be signed.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <returns>Returns the dynamic response from the API call.</returns>
        public dynamic GetContract(
                Guid externalRefId,
                Guid? vCorrelationId = null)
            => CoreHelper.RunTask(GetContractAsync(externalRefId, vCorrelationId));

        /// <summary>
        /// Returns a PDF contract to be signed.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the dynamic response from the API call.</returns>
        public async Task<dynamic> GetContractAsync(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<dynamic>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/contracts")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Header(_header => _header.Setup("externalRefId", externalRefId))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Retrieves a Docusign link to view the contract.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <returns>Returns the Models.DocuSignLink response from the API call.</returns>
        public Models.DocuSignLink DocusignLink(
                Models.DocumentLink body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson)
            => CoreHelper.RunTask(DocusignLinkAsync(body, vCorrelationId, contentType));

        /// <summary>
        /// Retrieves a Docusign link to view the contract.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.DocuSignLink response from the API call.</returns>
        public async Task<Models.DocuSignLink> DocusignLinkAsync(
                Models.DocumentLink body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.DocuSignLink>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/applications/documentlink")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))
                      .Header(_header => _header.Setup("Content-Type", (contentType.HasValue) ? ApiHelper.JsonSerialize(contentType.Value).Trim('\"') : "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}