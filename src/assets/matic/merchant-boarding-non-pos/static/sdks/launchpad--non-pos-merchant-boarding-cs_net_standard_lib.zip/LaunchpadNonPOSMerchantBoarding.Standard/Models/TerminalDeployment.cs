// <copyright file="TerminalDeployment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// TerminalDeployment.
    /// </summary>
    public class TerminalDeployment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalDeployment"/> class.
        /// </summary>
        public TerminalDeployment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalDeployment"/> class.
        /// </summary>
        /// <param name="equipmentUpdateDeploy">equipmentUpdateDeploy.</param>
        /// <param name="terminalBuildFlag">terminalBuildFlag.</param>
        /// <param name="frontEndBuildFlag">frontEndBuildFlag.</param>
        /// <param name="sicMerchantFlag">sicMerchantFlag.</param>
        /// <param name="specialInstructions">specialInstructions.</param>
        public TerminalDeployment(
            Models.EquipmentUpdateDeployEnum equipmentUpdateDeploy,
            bool? terminalBuildFlag = null,
            bool? frontEndBuildFlag = null,
            bool? sicMerchantFlag = null,
            string specialInstructions = null)
        {
            this.EquipmentUpdateDeploy = equipmentUpdateDeploy;
            this.TerminalBuildFlag = terminalBuildFlag;
            this.FrontEndBuildFlag = frontEndBuildFlag;
            this.SicMerchantFlag = sicMerchantFlag;
            this.SpecialInstructions = specialInstructions;
        }

        /// <summary>
        /// Gets or sets EquipmentUpdateDeploy.
        /// </summary>
        [JsonProperty("equipmentUpdateDeploy")]
        public Models.EquipmentUpdateDeployEnum EquipmentUpdateDeploy { get; set; }

        /// <summary>
        /// Gets or sets TerminalBuildFlag.
        /// </summary>
        [JsonProperty("terminalBuildFlag", NullValueHandling = NullValueHandling.Ignore)]
        public bool? TerminalBuildFlag { get; set; }

        /// <summary>
        /// Gets or sets FrontEndBuildFlag.
        /// </summary>
        [JsonProperty("frontEndBuildFlag", NullValueHandling = NullValueHandling.Ignore)]
        public bool? FrontEndBuildFlag { get; set; }

        /// <summary>
        /// Gets or sets SicMerchantFlag.
        /// </summary>
        [JsonProperty("sicMerchantFlag", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SicMerchantFlag { get; set; }

        /// <summary>
        /// Special instructions for terminal deployment.
        /// </summary>
        [JsonProperty("specialInstructions", NullValueHandling = NullValueHandling.Ignore)]
        public string SpecialInstructions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TerminalDeployment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is TerminalDeployment other &&                this.EquipmentUpdateDeploy.Equals(other.EquipmentUpdateDeploy) &&
                ((this.TerminalBuildFlag == null && other.TerminalBuildFlag == null) || (this.TerminalBuildFlag?.Equals(other.TerminalBuildFlag) == true)) &&
                ((this.FrontEndBuildFlag == null && other.FrontEndBuildFlag == null) || (this.FrontEndBuildFlag?.Equals(other.FrontEndBuildFlag) == true)) &&
                ((this.SicMerchantFlag == null && other.SicMerchantFlag == null) || (this.SicMerchantFlag?.Equals(other.SicMerchantFlag) == true)) &&
                ((this.SpecialInstructions == null && other.SpecialInstructions == null) || (this.SpecialInstructions?.Equals(other.SpecialInstructions) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.EquipmentUpdateDeploy = {this.EquipmentUpdateDeploy}");
            toStringOutput.Add($"this.TerminalBuildFlag = {(this.TerminalBuildFlag == null ? "null" : this.TerminalBuildFlag.ToString())}");
            toStringOutput.Add($"this.FrontEndBuildFlag = {(this.FrontEndBuildFlag == null ? "null" : this.FrontEndBuildFlag.ToString())}");
            toStringOutput.Add($"this.SicMerchantFlag = {(this.SicMerchantFlag == null ? "null" : this.SicMerchantFlag.ToString())}");
            toStringOutput.Add($"this.SpecialInstructions = {(this.SpecialInstructions == null ? "null" : this.SpecialInstructions)}");
        }
    }
}