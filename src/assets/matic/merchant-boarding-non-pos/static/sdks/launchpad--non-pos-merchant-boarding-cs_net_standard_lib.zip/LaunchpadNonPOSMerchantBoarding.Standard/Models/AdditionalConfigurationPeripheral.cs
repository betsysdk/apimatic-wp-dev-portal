// <copyright file="AdditionalConfigurationPeripheral.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AdditionalConfigurationPeripheral.
    /// </summary>
    public class AdditionalConfigurationPeripheral
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AdditionalConfigurationPeripheral"/> class.
        /// </summary>
        public AdditionalConfigurationPeripheral()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AdditionalConfigurationPeripheral"/> class.
        /// </summary>
        /// <param name="peripheralId">peripheralId.</param>
        /// <param name="model">model.</param>
        /// <param name="shortDescription">shortDescription.</param>
        /// <param name="longDescription">longDescription.</param>
        /// <param name="isEMVCertified">isEMVCertified.</param>
        /// <param name="isEMVCapable">isEMVCapable.</param>
        /// <param name="activePeripheralFlag">activePeripheralFlag.</param>
        /// <param name="purchasePrice">purchasePrice.</param>
        /// <param name="leasePrice">leasePrice.</param>
        /// <param name="rentalPrice">rentalPrice.</param>
        /// <param name="hardwareCost">hardwareCost.</param>
        public AdditionalConfigurationPeripheral(
            string peripheralId = null,
            string model = null,
            string shortDescription = null,
            string longDescription = null,
            bool? isEMVCertified = null,
            bool? isEMVCapable = null,
            string activePeripheralFlag = null,
            string purchasePrice = null,
            string leasePrice = null,
            string rentalPrice = null,
            string hardwareCost = null)
        {
            this.PeripheralId = peripheralId;
            this.Model = model;
            this.ShortDescription = shortDescription;
            this.LongDescription = longDescription;
            this.IsEMVCertified = isEMVCertified;
            this.IsEMVCapable = isEMVCapable;
            this.ActivePeripheralFlag = activePeripheralFlag;
            this.PurchasePrice = purchasePrice;
            this.LeasePrice = leasePrice;
            this.RentalPrice = rentalPrice;
            this.HardwareCost = hardwareCost;
        }

        /// <summary>
        /// Peripheral IDs are internally populated.
        /// </summary>
        [JsonProperty("peripheralId", NullValueHandling = NullValueHandling.Ignore)]
        public string PeripheralId { get; set; }

        /// <summary>
        /// Peripheral Name
        /// </summary>
        [JsonProperty("model", NullValueHandling = NullValueHandling.Ignore)]
        public string Model { get; set; }

        /// <summary>
        /// Description of the peripheral
        /// </summary>
        [JsonProperty("shortDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string ShortDescription { get; set; }

        /// <summary>
        /// Verbose description of the peripheral
        /// </summary>
        [JsonProperty("longDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string LongDescription { get; set; }

        /// <summary>
        /// Whether peripheral is EMV certified
        /// </summary>
        [JsonProperty("isEMVCertified", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsEMVCertified { get; set; }

        /// <summary>
        /// Whether peripheral is EMV Capable
        /// </summary>
        [JsonProperty("isEMVCapable", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsEMVCapable { get; set; }

        /// <summary>
        /// Gets or sets ActivePeripheralFlag.
        /// </summary>
        [JsonProperty("activePeripheralFlag", NullValueHandling = NullValueHandling.Ignore)]
        public string ActivePeripheralFlag { get; set; }

        /// <summary>
        /// purchase price of the peripheral
        /// </summary>
        [JsonProperty("purchasePrice", NullValueHandling = NullValueHandling.Ignore)]
        public string PurchasePrice { get; set; }

        /// <summary>
        /// lease price of the peripheral
        /// </summary>
        [JsonProperty("leasePrice", NullValueHandling = NullValueHandling.Ignore)]
        public string LeasePrice { get; set; }

        /// <summary>
        /// rental price of the peripheral
        /// </summary>
        [JsonProperty("rentalPrice", NullValueHandling = NullValueHandling.Ignore)]
        public string RentalPrice { get; set; }

        /// <summary>
        /// hardware cost of the terminal
        /// </summary>
        [JsonProperty("hardwareCost", NullValueHandling = NullValueHandling.Ignore)]
        public string HardwareCost { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AdditionalConfigurationPeripheral : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AdditionalConfigurationPeripheral other &&                ((this.PeripheralId == null && other.PeripheralId == null) || (this.PeripheralId?.Equals(other.PeripheralId) == true)) &&
                ((this.Model == null && other.Model == null) || (this.Model?.Equals(other.Model) == true)) &&
                ((this.ShortDescription == null && other.ShortDescription == null) || (this.ShortDescription?.Equals(other.ShortDescription) == true)) &&
                ((this.LongDescription == null && other.LongDescription == null) || (this.LongDescription?.Equals(other.LongDescription) == true)) &&
                ((this.IsEMVCertified == null && other.IsEMVCertified == null) || (this.IsEMVCertified?.Equals(other.IsEMVCertified) == true)) &&
                ((this.IsEMVCapable == null && other.IsEMVCapable == null) || (this.IsEMVCapable?.Equals(other.IsEMVCapable) == true)) &&
                ((this.ActivePeripheralFlag == null && other.ActivePeripheralFlag == null) || (this.ActivePeripheralFlag?.Equals(other.ActivePeripheralFlag) == true)) &&
                ((this.PurchasePrice == null && other.PurchasePrice == null) || (this.PurchasePrice?.Equals(other.PurchasePrice) == true)) &&
                ((this.LeasePrice == null && other.LeasePrice == null) || (this.LeasePrice?.Equals(other.LeasePrice) == true)) &&
                ((this.RentalPrice == null && other.RentalPrice == null) || (this.RentalPrice?.Equals(other.RentalPrice) == true)) &&
                ((this.HardwareCost == null && other.HardwareCost == null) || (this.HardwareCost?.Equals(other.HardwareCost) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PeripheralId = {(this.PeripheralId == null ? "null" : this.PeripheralId)}");
            toStringOutput.Add($"this.Model = {(this.Model == null ? "null" : this.Model)}");
            toStringOutput.Add($"this.ShortDescription = {(this.ShortDescription == null ? "null" : this.ShortDescription)}");
            toStringOutput.Add($"this.LongDescription = {(this.LongDescription == null ? "null" : this.LongDescription)}");
            toStringOutput.Add($"this.IsEMVCertified = {(this.IsEMVCertified == null ? "null" : this.IsEMVCertified.ToString())}");
            toStringOutput.Add($"this.IsEMVCapable = {(this.IsEMVCapable == null ? "null" : this.IsEMVCapable.ToString())}");
            toStringOutput.Add($"this.ActivePeripheralFlag = {(this.ActivePeripheralFlag == null ? "null" : this.ActivePeripheralFlag)}");
            toStringOutput.Add($"this.PurchasePrice = {(this.PurchasePrice == null ? "null" : this.PurchasePrice)}");
            toStringOutput.Add($"this.LeasePrice = {(this.LeasePrice == null ? "null" : this.LeasePrice)}");
            toStringOutput.Add($"this.RentalPrice = {(this.RentalPrice == null ? "null" : this.RentalPrice)}");
            toStringOutput.Add($"this.HardwareCost = {(this.HardwareCost == null ? "null" : this.HardwareCost)}");
        }
    }
}