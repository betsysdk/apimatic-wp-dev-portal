// <copyright file="AdvancedSettlementInner.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AdvancedSettlementInner.
    /// </summary>
    public class AdvancedSettlementInner
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AdvancedSettlementInner"/> class.
        /// </summary>
        public AdvancedSettlementInner()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AdvancedSettlementInner"/> class.
        /// </summary>
        /// <param name="settlementCategories">settlementCategories.</param>
        /// <param name="bankAccount">bankAccount.</param>
        public AdvancedSettlementInner(
            List<Models.SettlementCategoryEnum> settlementCategories = null,
            Models.BankAccount1 bankAccount = null)
        {
            this.SettlementCategories = settlementCategories;
            this.BankAccount = bankAccount;
        }

        /// <summary>
        /// Gets or sets SettlementCategories.
        /// </summary>
        [JsonProperty("settlementCategories", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.SettlementCategoryEnum> SettlementCategories { get; set; }

        /// <summary>
        /// <![CDATA[
        /// Bank account collects bank account information from merchant. It is optional till the time of boarding where bank account becomes required along with ddaType, achType, accountNumber, routingNumber & bankName.
        /// ]]>
        /// </summary>
        [JsonProperty("bankAccount", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BankAccount1 BankAccount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AdvancedSettlementInner : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AdvancedSettlementInner other &&                ((this.SettlementCategories == null && other.SettlementCategories == null) || (this.SettlementCategories?.Equals(other.SettlementCategories) == true)) &&
                ((this.BankAccount == null && other.BankAccount == null) || (this.BankAccount?.Equals(other.BankAccount) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SettlementCategories = {(this.SettlementCategories == null ? "null" : $"[{string.Join(", ", this.SettlementCategories)} ]")}");
            toStringOutput.Add($"this.BankAccount = {(this.BankAccount == null ? "null" : this.BankAccount.ToString())}");
        }
    }
}