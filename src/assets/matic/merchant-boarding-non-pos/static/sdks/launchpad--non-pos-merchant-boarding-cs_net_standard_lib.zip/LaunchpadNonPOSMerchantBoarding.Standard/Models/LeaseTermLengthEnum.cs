// <copyright file="LeaseTermLengthEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// LeaseTermLengthEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum LeaseTermLengthEnum
    {
        /// <summary>
        /// Enum24.
        /// </summary>
        [EnumMember(Value = "24")]
        Enum24,

        /// <summary>
        /// Enum36.
        /// </summary>
        [EnumMember(Value = "36")]
        Enum36,

        /// <summary>
        /// Enum48.
        /// </summary>
        [EnumMember(Value = "48")]
        Enum48,

        /// <summary>
        /// Enum60.
        /// </summary>
        [EnumMember(Value = "60")]
        Enum60
    }
}