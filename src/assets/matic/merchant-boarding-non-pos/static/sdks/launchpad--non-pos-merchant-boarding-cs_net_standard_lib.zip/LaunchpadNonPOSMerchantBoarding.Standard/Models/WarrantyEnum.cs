// <copyright file="WarrantyEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// WarrantyEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum WarrantyEnum
    {
        /// <summary>
        /// Enum1YEAR.
        /// </summary>
        [EnumMember(Value = "1 YEAR")]
        Enum1YEAR,

        /// <summary>
        /// Enum30DAY.
        /// </summary>
        [EnumMember(Value = "30 DAY")]
        Enum30DAY,

        /// <summary>
        /// Enum60DAY.
        /// </summary>
        [EnumMember(Value = "60 DAY")]
        Enum60DAY,

        /// <summary>
        /// Enum90DAY.
        /// </summary>
        [EnumMember(Value = "90 DAY")]
        Enum90DAY,

        /// <summary>
        /// LIFETIME.
        /// </summary>
        [EnumMember(Value = "LIFETIME")]
        LIFETIME,

        /// <summary>
        /// NO.
        /// </summary>
        [EnumMember(Value = "NO")]
        NO
    }
}