// <copyright file="AdditionalConfigurationsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AdditionalConfigurationsResponse.
    /// </summary>
    public class AdditionalConfigurationsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AdditionalConfigurationsResponse"/> class.
        /// </summary>
        public AdditionalConfigurationsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AdditionalConfigurationsResponse"/> class.
        /// </summary>
        /// <param name="customizations">customizations.</param>
        /// <param name="peripherals">peripherals.</param>
        public AdditionalConfigurationsResponse(
            List<Models.AdditionalConfigurationCustomization> customizations = null,
            List<Models.AdditionalConfigurationPeripheral> peripherals = null)
        {
            this.Customizations = customizations;
            this.Peripherals = peripherals;
        }

        /// <summary>
        /// Gets or sets Customizations.
        /// </summary>
        [JsonProperty("customizations", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AdditionalConfigurationCustomization> Customizations { get; set; }

        /// <summary>
        /// Gets or sets Peripherals.
        /// </summary>
        [JsonProperty("peripherals", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AdditionalConfigurationPeripheral> Peripherals { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AdditionalConfigurationsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AdditionalConfigurationsResponse other &&                ((this.Customizations == null && other.Customizations == null) || (this.Customizations?.Equals(other.Customizations) == true)) &&
                ((this.Peripherals == null && other.Peripherals == null) || (this.Peripherals?.Equals(other.Peripherals) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Customizations = {(this.Customizations == null ? "null" : $"[{string.Join(", ", this.Customizations)} ]")}");
            toStringOutput.Add($"this.Peripherals = {(this.Peripherals == null ? "null" : $"[{string.Join(", ", this.Peripherals)} ]")}");
        }
    }
}