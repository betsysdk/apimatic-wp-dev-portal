// <copyright file="AddressTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// AddressTypeEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum AddressTypeEnum
    {
        /// <summary>
        /// EnumMailingAddress.
        /// </summary>
        [EnumMember(Value = "Mailing Address")]
        EnumMailingAddress,

        /// <summary>
        /// EnumPhysicalAddress.
        /// </summary>
        [EnumMember(Value = "Physical Address")]
        EnumPhysicalAddress,

        /// <summary>
        /// EnumShippingAddress.
        /// </summary>
        [EnumMember(Value = "Shipping Address")]
        EnumShippingAddress
    }
}