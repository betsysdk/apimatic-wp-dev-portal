// <copyright file="InlineResponse200.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InlineResponse200.
    /// </summary>
    public class InlineResponse200
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InlineResponse200"/> class.
        /// </summary>
        public InlineResponse200()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InlineResponse200"/> class.
        /// </summary>
        /// <param name="equipment">equipment.</param>
        public InlineResponse200(
            List<Models.InlineResponse200Equipment> equipment = null)
        {
            this.Equipment = equipment;
        }

        /// <summary>
        /// Gets or sets Equipment.
        /// </summary>
        [JsonProperty("equipment", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.InlineResponse200Equipment> Equipment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"InlineResponse200 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is InlineResponse200 other &&                ((this.Equipment == null && other.Equipment == null) || (this.Equipment?.Equals(other.Equipment) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Equipment = {(this.Equipment == null ? "null" : $"[{string.Join(", ", this.Equipment)} ]")}");
        }
    }
}