// <copyright file="SubmitApplicationController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// SubmitApplicationController.
    /// </summary>
    public class SubmitApplicationController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SubmitApplicationController"/> class.
        /// </summary>
        internal SubmitApplicationController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Begins the merchant validation process before boarding after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        public void ValidateBoard(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson)
            => CoreHelper.RunVoidTask(ValidateBoardAsync(externalRefId, vCorrelationId, contentType));

        /// <summary>
        /// Begins the merchant validation process before boarding after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ValidateBoardAsync(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/applications/validate")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Header(_header => _header.Setup("externalRefId", externalRefId))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))
                      .Header(_header => _header.Setup("Content-Type", (contentType.HasValue) ? ApiHelper.JsonSerialize(contentType.Value).Trim('\"') : "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Begins the merchant boarding process after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="threatmetrixId">Optional parameter: A unique session id.</param>
        public void InititateBoard(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                string threatmetrixId = null)
            => CoreHelper.RunVoidTask(InititateBoardAsync(externalRefId, vCorrelationId, contentType, threatmetrixId));

        /// <summary>
        /// Begins the merchant boarding process after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="threatmetrixId">Optional parameter: A unique session id.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task InititateBoardAsync(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                string threatmetrixId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/applications/board")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Header(_header => _header.Setup("externalRefId", externalRefId))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))
                      .Header(_header => _header.Setup("Content-Type", (contentType.HasValue) ? ApiHelper.JsonSerialize(contentType.Value).Trim('\"') : "application/json"))
                      .Header(_header => _header.Setup("threatmetrixId", threatmetrixId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}