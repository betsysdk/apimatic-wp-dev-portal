// <copyright file="CheckLaunchpadHealthController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// CheckLaunchpadHealthController.
    /// </summary>
    public class CheckLaunchpadHealthController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckLaunchpadHealthController"/> class.
        /// </summary>
        internal CheckLaunchpadHealthController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Checks the the health of Launchpad and its dependent down streams systems like CPQ, Sales Force, XAA and Jigsaw at regular intervals to check the system is up or down.
        /// </summary>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <returns>Returns the Models.InlineResponse2001 response from the API call.</returns>
        public Models.InlineResponse2001 Gethealth(
                Guid? vCorrelationId = null)
            => CoreHelper.RunTask(GethealthAsync(vCorrelationId));

        /// <summary>
        /// Checks the the health of Launchpad and its dependent down streams systems like CPQ, Sales Force, XAA and Jigsaw at regular intervals to check the system is up or down.
        /// </summary>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.InlineResponse2001 response from the API call.</returns>
        public async Task<Models.InlineResponse2001> GethealthAsync(
                Guid? vCorrelationId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.InlineResponse2001>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/applications/health")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}