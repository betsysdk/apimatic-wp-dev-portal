// <copyright file="InitiateBoardingApplicationController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// InitiateBoardingApplicationController.
    /// </summary>
    public class InitiateBoardingApplicationController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InitiateBoardingApplicationController"/> class.
        /// </summary>
        internal InitiateBoardingApplicationController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// This endpoint allows merchants to update an existing application with new information.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        public void ExisitingApplication(
                Models.ExistingApplication1 body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson)
            => CoreHelper.RunVoidTask(ExisitingApplicationAsync(body, vCorrelationId, contentType));

        /// <summary>
        /// This endpoint allows merchants to update an existing application with new information.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ExisitingApplicationAsync(
                Models.ExistingApplication1 body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/applications")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))
                      .Header(_header => _header.Setup("Content-Type", (contentType.HasValue) ? ApiHelper.JsonSerialize(contentType.Value).Trim('\"') : "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Use this endpoint to collect the merchant information needed to initiate a new contract. .
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <returns>Returns the Models.ApplicationResponse response from the API call.</returns>
        public Models.ApplicationResponse NewApplication(
                Models.Application body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson)
            => CoreHelper.RunTask(NewApplicationAsync(body, vCorrelationId, contentType));

        /// <summary>
        /// Use this endpoint to collect the merchant information needed to initiate a new contract. .
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ApplicationResponse response from the API call.</returns>
        public async Task<Models.ApplicationResponse> NewApplicationAsync(
                Models.Application body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ApplicationResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/applications")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))
                      .Header(_header => _header.Setup("Content-Type", (contentType.HasValue) ? ApiHelper.JsonSerialize(contentType.Value).Trim('\"') : "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Retrieves existing application data.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <returns>Returns the Models.ExistingApplication response from the API call.</returns>
        public Models.ExistingApplication FetchApplication(
                Guid externalRefId,
                Guid? vCorrelationId = null)
            => CoreHelper.RunTask(FetchApplicationAsync(externalRefId, vCorrelationId));

        /// <summary>
        /// Retrieves existing application data.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ExistingApplication response from the API call.</returns>
        public async Task<Models.ExistingApplication> FetchApplicationAsync(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ExistingApplication>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/applications")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Header(_header => _header.Setup("externalRefId", externalRefId))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}