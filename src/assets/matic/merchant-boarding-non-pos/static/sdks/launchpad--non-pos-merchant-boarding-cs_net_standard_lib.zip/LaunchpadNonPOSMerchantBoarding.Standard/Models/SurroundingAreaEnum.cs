// <copyright file="SurroundingAreaEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// SurroundingAreaEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum SurroundingAreaEnum
    {
        /// <summary>
        /// Commercial.
        /// </summary>
        [EnumMember(Value = "Commercial")]
        Commercial,

        /// <summary>
        /// Industrial.
        /// </summary>
        [EnumMember(Value = "Industrial")]
        Industrial,

        /// <summary>
        /// Residential.
        /// </summary>
        [EnumMember(Value = "Residential")]
        Residential
    }
}