// <copyright file="DocuSignLink.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// DocuSignLink.
    /// </summary>
    public class DocuSignLink
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DocuSignLink"/> class.
        /// </summary>
        public DocuSignLink()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DocuSignLink"/> class.
        /// </summary>
        /// <param name="embeddingUrl">embeddingUrl.</param>
        public DocuSignLink(
            string embeddingUrl = null)
        {
            this.EmbeddingUrl = embeddingUrl;
        }

        /// <summary>
        /// UI embeded link of the Docusign contract for the externalRefId.
        /// </summary>
        [JsonProperty("embeddingUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string EmbeddingUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DocuSignLink : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is DocuSignLink other &&                ((this.EmbeddingUrl == null && other.EmbeddingUrl == null) || (this.EmbeddingUrl?.Equals(other.EmbeddingUrl) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.EmbeddingUrl = {(this.EmbeddingUrl == null ? "null" : this.EmbeddingUrl)}");
        }
    }
}