// <copyright file="TerminalCustomization.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// TerminalCustomization.
    /// </summary>
    public class TerminalCustomization
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalCustomization"/> class.
        /// </summary>
        public TerminalCustomization()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalCustomization"/> class.
        /// </summary>
        /// <param name="customizationId">customizationId.</param>
        /// <param name="customizationName">customizationName.</param>
        /// <param name="customizationFieldValue">customizationFieldValue.</param>
        public TerminalCustomization(
            string customizationId = null,
            string customizationName = null,
            string customizationFieldValue = null)
        {
            this.CustomizationId = customizationId;
            this.CustomizationName = customizationName;
            this.CustomizationFieldValue = customizationFieldValue;
        }

        /// <summary>
        /// Customization ID is internally populated from a master list.
        /// </summary>
        [JsonProperty("customizationId", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationId { get; set; }

        /// <summary>
        /// Gets or sets CustomizationName.
        /// </summary>
        [JsonProperty("customizationName", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationName { get; set; }

        /// <summary>
        /// Gets or sets CustomizationFieldValue.
        /// </summary>
        [JsonProperty("customizationFieldValue", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationFieldValue { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TerminalCustomization : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is TerminalCustomization other &&                ((this.CustomizationId == null && other.CustomizationId == null) || (this.CustomizationId?.Equals(other.CustomizationId) == true)) &&
                ((this.CustomizationName == null && other.CustomizationName == null) || (this.CustomizationName?.Equals(other.CustomizationName) == true)) &&
                ((this.CustomizationFieldValue == null && other.CustomizationFieldValue == null) || (this.CustomizationFieldValue?.Equals(other.CustomizationFieldValue) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CustomizationId = {(this.CustomizationId == null ? "null" : this.CustomizationId)}");
            toStringOutput.Add($"this.CustomizationName = {(this.CustomizationName == null ? "null" : this.CustomizationName)}");
            toStringOutput.Add($"this.CustomizationFieldValue = {(this.CustomizationFieldValue == null ? "null" : this.CustomizationFieldValue)}");
        }
    }
}