// <copyright file="ChooseEquipmentController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// ChooseEquipmentController.
    /// </summary>
    public class ChooseEquipmentController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ChooseEquipmentController"/> class.
        /// </summary>
        internal ChooseEquipmentController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Gets the terminal configuration information for a specific partner.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="locationId">Optional parameter: The locationId returned from POST /locations call..</param>
        /// <param name="merchantId">Optional parameter: The merchantId returned from POST /merchants call..</param>
        /// <returns>Returns the Models.EquipmentSetup response from the API call.</returns>
        public Models.EquipmentSetup GetTerminalInfo(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                string locationId = null,
                string merchantId = null)
            => CoreHelper.RunTask(GetTerminalInfoAsync(externalRefId, vCorrelationId, contentType, locationId, merchantId));

        /// <summary>
        /// Gets the terminal configuration information for a specific partner.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="locationId">Optional parameter: The locationId returned from POST /locations call..</param>
        /// <param name="merchantId">Optional parameter: The merchantId returned from POST /merchants call..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.EquipmentSetup response from the API call.</returns>
        public async Task<Models.EquipmentSetup> GetTerminalInfoAsync(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                string locationId = null,
                string merchantId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.EquipmentSetup>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/equipment/terminal-var")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Header(_header => _header.Setup("externalRefId", externalRefId))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))
                      .Header(_header => _header.Setup("Content-Type", (contentType.HasValue) ? ApiHelper.JsonSerialize(contentType.Value).Trim('\"') : "application/json"))
                      .Header(_header => _header.Setup("locationId", locationId))
                      .Header(_header => _header.Setup("merchantId", merchantId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Updates terminal configurations.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="locationId">Optional parameter: The locationId returned from POST /locations call..</param>
        /// <param name="merchantId">Optional parameter: The merchantId returned from POST /merchants call..</param>
        public void UpdateTerminal(
                Guid externalRefId,
                Models.EquipmentSetup body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                string locationId = null,
                string merchantId = null)
            => CoreHelper.RunVoidTask(UpdateTerminalAsync(externalRefId, body, vCorrelationId, contentType, locationId, merchantId));

        /// <summary>
        /// Updates terminal configurations.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="locationId">Optional parameter: The locationId returned from POST /locations call..</param>
        /// <param name="merchantId">Optional parameter: The merchantId returned from POST /merchants call..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task UpdateTerminalAsync(
                Guid externalRefId,
                Models.EquipmentSetup body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                string locationId = null,
                string merchantId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/equipment/terminal-var")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("externalRefId", externalRefId))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))
                      .Header(_header => _header.Setup("Content-Type", (contentType.HasValue) ? ApiHelper.JsonSerialize(contentType.Value).Trim('\"') : "application/json"))
                      .Header(_header => _header.Setup("locationId", locationId))
                      .Header(_header => _header.Setup("merchantId", merchantId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Sets up terminal configurations.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="locationId">Optional parameter: The locationId returned from POST /locations call..</param>
        /// <param name="merchantId">Optional parameter: The merchantId returned from POST /merchants call..</param>
        public void ConfigStandaloneTerminal(
                Guid externalRefId,
                Models.EquipmentSetup body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                string locationId = null,
                string merchantId = null)
            => CoreHelper.RunVoidTask(ConfigStandaloneTerminalAsync(externalRefId, body, vCorrelationId, contentType, locationId, merchantId));

        /// <summary>
        /// Sets up terminal configurations.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="contentType">Optional parameter: Indicates the media type of the request-body. Accepts application/json..</param>
        /// <param name="locationId">Optional parameter: The locationId returned from POST /locations call..</param>
        /// <param name="merchantId">Optional parameter: The merchantId returned from POST /merchants call..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ConfigStandaloneTerminalAsync(
                Guid externalRefId,
                Models.EquipmentSetup body,
                Guid? vCorrelationId = null,
                Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
                string locationId = null,
                string merchantId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/equipment/terminal-var")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("externalRefId", externalRefId))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))
                      .Header(_header => _header.Setup("Content-Type", (contentType.HasValue) ? ApiHelper.JsonSerialize(contentType.Value).Trim('\"') : "application/json"))
                      .Header(_header => _header.Setup("locationId", locationId))
                      .Header(_header => _header.Setup("merchantId", merchantId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}