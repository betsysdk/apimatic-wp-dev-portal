
# Lease Term Length Enum

Lease term for the peripheral

## Enumeration

`LeaseTermLengthEnum`

## Fields

| Name |
|  --- |
| `enum24` |
| `enum36` |
| `enum48` |
| `enum60` |

## Example

```
24
```

