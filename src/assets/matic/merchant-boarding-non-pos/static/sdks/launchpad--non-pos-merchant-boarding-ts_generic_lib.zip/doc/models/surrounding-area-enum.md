
# Surrounding Area Enum

Type of area surroundning the business.

## Enumeration

`SurroundingAreaEnum`

## Fields

| Name |
|  --- |
| `commercial` |
| `industrial` |
| `residential` |

## Example

```
Commercial
```

