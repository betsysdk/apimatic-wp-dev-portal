
# Guarantor 1

## Structure

`Guarantor1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type3Enum`](../../doc/models/type-3-enum.md) | Required | - |
| `title` | `string \| undefined` | Optional | Required for AMEX acquired merchants otherwise optional.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `30`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `firstName` | `string` | Required | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `middleInitial` | `string \| undefined` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `lastName` | `string` | Required | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `phoneNumber` | `string` | Required | 10-digit phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `phoneNumberExt` | `string \| undefined` | Optional | Phone number extension. Up to 8 digits of the format 12345678.<br>**Constraints**: *Maximum Length*: `8`, *Pattern*: `^[0-9]{1,8}$` |
| `phoneType` | [`PhoneTypeEnum \| undefined`](../../doc/models/phone-type-enum.md) | Optional | Phone type. |
| `alternatePhone` | `string \| undefined` | Optional | 10-digit alternate phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `alternatePhoneType` | [`AlternatePhoneTypeEnum \| undefined`](../../doc/models/alternate-phone-type-enum.md) | Optional | Alternate phone type. |
| `faxNumber` | `string \| undefined` | Optional | 10-digit fax number of the format 5131234567<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `email` | `string` | Required | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` |
| `ownershipPercentage` | `number \| undefined` | Optional | Ownership stake percentage.<br>**Constraints**: `>= 0`, `<= 100` |
| `ssn` | `string \| undefined` | Optional | Social security number. Do not include dashes.The full list of restricted SSN is- “000000001” “000000002” “000000003” “000000004” “000000005” “000000006” “000000007” “000000008” “000000009" "111111110" “111111111” "111111112" "111111113" "111111114" "111111115" "111111116" "111111117" "111111118" "111111119" "222222220" "222222221" “222222222” "222222223" "222222224" "222222225" "222222226" "222222227" "222222228" "222222229" "333333330" "333333331" "333333332" “333333333” "333333334" "333333335" "333333336" "333333337" "333333338" "333333339"  "444444440" "444444441" "444444442" "444444443" “444444444” "444444445" "444444446" "444444447" "444444448" "444444449" "555555550" "555555551" "555555552" "555555553" "555555554" “555555555” "555555556" "555555557" "555555558" "555555559"  "666666660" "666666661" "666666662" "666666663" "666666664" "666666665" “666666666" "666666667" "666666668" "666666669" "777777770" "777777771” "777777772" "777777773" "777777774" "777777775" "777777776" “777777777” "777777778" "777777779" "888888880" "888888881" "888888882" "888888883" "888888884" "888888885" "888888886" "888888887" “888888888” "888888889"  "999999990" "999999991" "999999992" "999999993" "999999994" "999999995" "99999996"   "999999997" "999999998" “999999999”  "123456780" to "123456789" "123123123"<br>**Constraints**: *Pattern*: `^[0-9]{9}$` |
| `dob` | `string \| undefined` | Optional | Date of Birth (CCYY-MM-DD). Must be at least 18 years old. |
| `addressLine1` | `string` | Required | Address Line 1. Field for house number, street and direction.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `addressLine2` | `string \| undefined` | Optional | Address Line 2. Field for apartment or suite numbers, etc.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `city` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `28`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `state` | [`State1Enum`](../../doc/models/state-1-enum.md) | Required | Valid US state, commonwealth, and territory codes are allowed. |
| `country` | `string` | Required, Constant | Only United States is allowed.<br>**Default**: `'United States'` |
| `postalCode` | `string` | Required | Postal code / zip code. The postal code must be valid for the address' country code.<br>**Constraints**: *Minimum Length*: `5`, *Maximum Length*: `5`, *Pattern*: `^[0-9]{5}$` |
| `postalCodeExtension` | `string \| undefined` | Optional | Postal code / zip code extension.  The postal code extension must be valid for the address' country code.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `4`, *Pattern*: `^[0-9]{4}$` |
| `identification` | [`Identification[] \| undefined`](../../doc/models/identification.md) | Optional | Optional. If any attribute in the identification object is populated then at least idNumber and idType are required. |

## Example (as JSON)

```json
{
  "type": "Guarantor 1 Contact",
  "title": "President",
  "firstName": "Todd",
  "middleInitial": "M",
  "lastName": "Davis",
  "phoneNumber": "5131234567",
  "phoneNumberExt": "1234",
  "phoneType": "mobile",
  "alternatePhone": "5131234567",
  "alternatePhoneType": "home",
  "faxNumber": "5131234567",
  "email": "test@gmail.com",
  "ssn": "123456789",
  "dob": "2000-03-23",
  "addressLine1": "4355 N Coalwhipe St.",
  "addressLine2": "suite 104",
  "city": "Denver",
  "state": "CO",
  "country": "United States",
  "postalCode": "12345",
  "postalCodeExtension": "1234"
}
```

