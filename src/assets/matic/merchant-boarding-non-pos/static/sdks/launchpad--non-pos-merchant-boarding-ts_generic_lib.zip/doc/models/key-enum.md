
# Key Enum

## Enumeration

`KeyEnum`

## Fields

| Name |
|  --- |
| `partnerEmployeeId` |
| `partnerEmployeeName` |
| `partnerEmployeePhoneNumber` |
| `partnerEmployeeEmail` |
| `partnerEmployeeType` |
| `partnerEmployeeBranch` |
| `partnerEmployeeCostCentre` |
| `partnerEmployeeRegion` |
| `partnerEmployeeOfficerCode` |
| `partnerEmployeeCompany` |
| `partnerEmployeeId2` |
| `partnerEmployeeName2` |
| `partnerEmployeePhoneNumber2` |
| `partnerEmployeeEmail2` |
| `partnerEmployeeType2` |
| `partnerEmployeeBranch2` |
| `partnerEmployeeCostCentre2` |
| `partnerEmployeeRegion2` |
| `partnerEmployeeOfficerCode2` |
| `partnerEmployeeCompany2` |
| `partnerEmployeeIndustry` |
| `partnerLeadSource` |
| `partnerEmployeeRef` |
| `partnerMethod` |
| `partnerVipIndicator` |
| `partnerMarketRegion` |
| `partnerPromotionCampaign` |
| `partnerLeadType` |
| `partnerCustom1` |
| `partnerCustom2` |
| `partnerCustom3` |
| `partnerCustom4` |
| `partnerCustom5` |
| `leadInitiatedBy` |

## Example

```
partnerEmployeeId
```

