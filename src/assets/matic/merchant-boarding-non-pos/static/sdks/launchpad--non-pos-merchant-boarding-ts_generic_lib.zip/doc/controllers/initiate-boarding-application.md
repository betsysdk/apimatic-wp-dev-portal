# Initiate Boarding Application

```ts
const initiateBoardingApplicationController = new InitiateBoardingApplicationController(client);
```

## Class Name

`InitiateBoardingApplicationController`

## Methods

* [Exisiting Application](../../doc/controllers/initiate-boarding-application.md#exisiting-application)
* [New Application](../../doc/controllers/initiate-boarding-application.md#new-application)
* [Fetch Application](../../doc/controllers/initiate-boarding-application.md#fetch-application)


# Exisiting Application

This endpoint allows merchants to update an existing application with new information.

```ts
async exisitingApplication(
  body: ExistingApplication1,
  vCorrelationId?: string,
  contentType?: ContentTypeEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ExistingApplication1`](../../doc/models/existing-application-1.md) | Body, Required | - |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum \| undefined`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const body: ExistingApplication1 = {
  externalRefId: 'df8a6d82-3bb4-4f3b-ba18-57a5981ede8e',
  businessInfo: {
    dbaName: 'The DBA Name',
    legalName: 'legalName8',
    ownershipType: OwnershipTypeEnum.LLC,
    mccCode: '5812',
    businessEstablishedDate: '2000-03-23',
    websiteUrl: 'www.thefoodplace.com',
    numberOfLocation: 2,
    federalTaxId: '123456781',
    paymentAcceptanceMethod: [
      PaymentAcceptanceMethodEnum.InPerson,
      PaymentAcceptanceMethodEnum.OnlineSite
    ],
    pciadc: PciadcEnum.No,
    pcidssValidated: PcidssValidatedEnum.No,
    surroundingArea: SurroundingAreaEnum.Commercial,
    productServiceSold: 'Food',
    ownAddYears: 2,
    seasonal: SeasonalEnum.Yes,
    activeMonths: [
      ActiveMonthEnum.Jan,
      ActiveMonthEnum.Feb,
      ActiveMonthEnum.Mar
    ],
    warranty: WarrantyEnum.Enum1YEAR,
    returnPolicy: ReturnPolicyEnum.Enum30Day,
    govOwnedMerchantCountry: 'US',
  },
  transactionInfo: {
    annualSalesVolume: 20000.12,
    percentRetailSwipedTransactions: 82,
    averageTicket: 2.3,
    highestTicket: 32.41,
    currentProcessor: 'Global Payments',
    acceptChargebacks: AcceptChargebacksEnum.No,
    chargebackPercent: 0,
    returnPercent: 10,
    cardNotPresentPercent: 20,
    businessToBusinessPercent: 20,
    internetTransactionPercent: 10,
    inPersonTransactionPercent: 10,
    motoTransactionPercent: 10,
    annualCreditSalesVolume: 123.32,
    annualDebitSalesVolume: 32.23,
    annualAmexVolume: 10000,
    amexAverageTicket: 2.3,
    averageNumberofDays: 10,
    needsProcessingBy: '2022-11-01',
  },
  leadSource: 'Activate',
  addresses: [
    {
      type: AddressTypeEnum.EnumMailingAddress,
      addressLine1: '1234 W Tester Ave.',
      city: 'City Town',
      state: State1Enum.CO,
      country: 'United States',
      postalCode: '80123',
      postalCodeExtension: '1234',
    },
    {
      type: AddressTypeEnum.EnumPhysicalAddress,
      addressLine1: '1234 W Tester Ave.',
      city: 'City Town',
      state: State1Enum.CO,
      country: 'United States',
      postalCode: '80123',
      postalCodeExtension: '1234',
    }
  ],
  routeToSalesRep: false,
};

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const contentType = ContentTypeEnum.EnumApplicationjson;

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await initiateBoardingApplicationController.exisitingApplication(
  body,
  vCorrelationId,
  contentType
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# New Application

Use this endpoint to collect the merchant information needed to initiate a new contract.

```ts
async newApplication(
  body: Application,
  vCorrelationId?: string,
  contentType?: ContentTypeEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ApplicationResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum \| undefined`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`ApplicationResponse`](../../doc/models/application-response.md)

## Example Usage

```ts
const body: Application = {
  businessInfo: {
    dbaName: 'The DBA Name',
    legalName: 'legalName8',
    ownershipType: OwnershipTypeEnum.LLC,
    mccCode: '5812',
    businessEstablishedDate: '2000-03-23',
    websiteUrl: 'www.thefoodplace.com',
    numberOfLocation: 2,
    federalTaxId: '123456781',
    paymentAcceptanceMethod: [
      PaymentAcceptanceMethodEnum.InPerson,
      PaymentAcceptanceMethodEnum.OnlineSite
    ],
    pciadc: PciadcEnum.No,
    pcidssValidated: PcidssValidatedEnum.No,
    surroundingArea: SurroundingAreaEnum.Commercial,
    productServiceSold: 'Food',
    ownAddYears: 2,
    seasonal: SeasonalEnum.Yes,
    activeMonths: [
      ActiveMonthEnum.Jan,
      ActiveMonthEnum.Feb,
      ActiveMonthEnum.Mar
    ],
    warranty: WarrantyEnum.Enum1YEAR,
    returnPolicy: ReturnPolicyEnum.Enum30Day,
    govOwnedMerchantCountry: 'US',
  },
  transactionInfo: {
    annualSalesVolume: 20000.12,
    percentRetailSwipedTransactions: 82,
    averageTicket: 2.3,
    highestTicket: 32.41,
    currentProcessor: 'Global Payments',
    acceptChargebacks: AcceptChargebacksEnum.No,
    chargebackPercent: 0,
    returnPercent: 10,
    cardNotPresentPercent: 20,
    businessToBusinessPercent: 20,
    internetTransactionPercent: 10,
    inPersonTransactionPercent: 10,
    motoTransactionPercent: 10,
    annualCreditSalesVolume: 123.32,
    annualDebitSalesVolume: 32.23,
    annualAmexVolume: 10000,
    amexAverageTicket: 2.3,
    averageNumberofDays: 10,
    needsProcessingBy: '2022-11-01',
  },
  authorizedSigners: [
    {
      roleName: RoleName1Enum.Merchant,
      signingExperience: SigningExperienceEnum.Email,
      signingOrder: '2',
      firstName: 'Todd',
      lastName: 'Davis',
      phoneNumber: '5131234567',
      email: 'test@gmail.com',
      ssn: '123456789',
      dob: '2000-03-23',
      addressLine1: '4355 N Coalwhipe St.',
      city: 'Denver',
      state: State1Enum.CO,
      country: 'United States',
      postalCode: '12345',
      title: 'President',
      middleInitial: 'M',
      phoneNumberExt: '1234',
      phoneType: PhoneTypeEnum.Mobile,
      alternatePhone: '5131234567',
      alternatePhoneType: AlternatePhoneTypeEnum.Home,
      faxNumber: '5131234567',
      addressLine2: 'suite 104',
      postalCodeExtension: '1234',
    }
  ],
  contacts: [
    {
      type: Type4Enum.EnumPrimaryContact,
      firstName: 'Todd',
      lastName: 'Davis',
      phoneNumber: '5131234567',
      email: 'test@gmail.com',
      title: 'President',
      middleInitial: 'M',
      ssn: '123456789',
      birthDate: '2000-03-23',
      phoneNumberExt: '1234',
      phoneType: PhoneTypeEnum.Mobile,
      alternatePhone: '5131234567',
      alternatePhoneType: AlternatePhoneTypeEnum.Home,
      faxNumber: '5131234567',
    }
  ],
  addresses: [
    {
      type: AddressTypeEnum.EnumMailingAddress,
      addressLine1: '1234 W Tester Ave.',
      city: 'City Town',
      state: State1Enum.CO,
      country: 'United States',
      postalCode: '80123',
      postalCodeExtension: '1234',
    },
    {
      type: AddressTypeEnum.EnumPhysicalAddress,
      addressLine1: '1234 W Tester Ave.',
      city: 'City Town',
      state: State1Enum.CO,
      country: 'United States',
      postalCode: '80123',
      postalCodeExtension: '1234',
    },
    {
      type: AddressTypeEnum.EnumShippingAddress,
      addressLine1: '1234 W Tester Ave.',
      city: 'City Town',
      state: State1Enum.CO,
      country: 'United States',
      postalCode: '80123',
      postalCodeExtension: '1234',
    }
  ],
  clientTrackingId: '1341341234132412341',
  leadSource: 'LP Connect API',
};

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const contentType = ContentTypeEnum.EnumApplicationjson;

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await initiateBoardingApplicationController.newApplication(
  body,
  vCorrelationId,
  contentType
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Fetch Application

Retrieves existing application data.

```ts
async fetchApplication(
  externalRefId: string,
  vCorrelationId?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ExistingApplication>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`ExistingApplication`](../../doc/models/existing-application.md)

## Example Usage

```ts
const externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await initiateBoardingApplicationController.fetchApplication(
  externalRefId,
  vCorrelationId
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

