# Equipment Lookup

```ts
const equipmentLookupController = new EquipmentLookupController(client);
```

## Class Name

`EquipmentLookupController`

## Methods

* [Get Additional Configurations](../../doc/controllers/equipment-lookup.md#get-additional-configurations)
* [Get Equipment Supported](../../doc/controllers/equipment-lookup.md#get-equipment-supported)


# Get Additional Configurations

Fetches a list of valid terminal customizations and peripherals, such as electing to password protect a void.

```ts
async getAdditionalConfigurations(
  externalRefId: string,
  vCorrelationId?: string,
  logicalApplicationId?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<AdditionalConfigurationsResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `logicalApplicationId` | `string \| undefined` | Header, Optional | Logical App ID of the terminal. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`AdditionalConfigurationsResponse`](../../doc/models/additional-configurations-response.md)

## Example Usage

```ts
const externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const logicalApplicationId = '1073';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await equipmentLookupController.getAdditionalConfigurations(
  externalRefId,
  vCorrelationId,
  logicalApplicationId
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Get Equipment Supported

Retrieve applicable equipment for an existing application.

```ts
async getEquipmentSupported(
  externalRefId: string,
  vCorrelationId?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<InlineResponse200>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`InlineResponse200`](../../doc/models/inline-response-200.md)

## Example Usage

```ts
const externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await equipmentLookupController.getEquipmentSupported(
  externalRefId,
  vCorrelationId
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

