
# M Schema

## Structure

`MSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "id": 82
}
```

