
# Payment Method 1 Enum

Payment method for the selected peripheral.

## Enumeration

`PaymentMethod1Enum`

## Fields

| Name |
|  --- |
| `enumPURCHASESALE` |
| `enumREPROGRAMOWN` |
| `enumMONTHTOMONTHRENTAL` |
| `lEASE` |

## Example

```
PURCHASE / SALE
```

