
# Payment Acceptance Method Enum

## Enumeration

`PaymentAcceptanceMethodEnum`

## Fields

| Name |
|  --- |
| `inPerson` |
| `onlineSite` |
| `phoneOrMailOrder` |

