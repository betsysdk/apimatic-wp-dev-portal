
# Sales Agent

The agent who is submitting the deal.

## Structure

`SalesAgent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string \| undefined` | Optional | Id for the Sales Contact.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15` |
| `firstName` | `string` | Required | Sales agent's first name.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15` |
| `lastName` | `string` | Required | Sales agent's last name.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25` |
| `mobilePhoneNumber` | `string \| undefined` | Optional | Sales agent's 10-digit phone number of the format 5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `email` | `string` | Required | Sales agent's email address.  Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `(\\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\\.)+[A-Za-z0-9]{2,}\\b{0,64})` |

## Example (as JSON)

```json
{
  "id": "U15315",
  "firstName": "John",
  "lastName": "Doe",
  "mobilePhoneNumber": "1234567890",
  "email": "email6"
}
```

