
# Additional Configuration Peripheral

## Structure

`AdditionalConfigurationPeripheral`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `peripheralId` | `string \| undefined` | Optional | Peripheral IDs are internally populated. |
| `model` | `string \| undefined` | Optional | Peripheral Name |
| `shortDescription` | `string \| undefined` | Optional | Description of the peripheral |
| `longDescription` | `string \| undefined` | Optional | Verbose description of the peripheral |
| `isEMVCertified` | `boolean \| undefined` | Optional | Whether peripheral is EMV certified |
| `isEMVCapable` | `boolean \| undefined` | Optional | Whether peripheral is EMV Capable |
| `activePeripheralFlag` | `string \| undefined` | Optional | - |
| `purchasePrice` | `string \| undefined` | Optional | purchase price of the peripheral |
| `leasePrice` | `string \| undefined` | Optional | lease price of the peripheral |
| `rentalPrice` | `string \| undefined` | Optional | rental price of the peripheral |
| `hardwareCost` | `string \| undefined` | Optional | hardware cost of the terminal |

## Example (as JSON)

```json
{
  "peripheralId": "35",
  "model": "Pin Pad 1000 SE",
  "shortDescription": "PP1S",
  "longDescription": "PPAD",
  "isEMVCertified": true,
  "isEMVCapable": true,
  "activePeripheralFlag": "Y",
  "purchasePrice": "168.12",
  "leasePrice": "100.12",
  "rentalPrice": "90",
  "hardwareCost": "50.75"
}
```

