
# Owner

A Control Owner is required for the following ownership types > LLC, PARTNERSHIP, PRIVATE CORPORATION, ASSOCIATION/ESTATE/TRUST, NON-PROFIT

## Structure

`Owner`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`TypeEnum`](../../doc/models/type-enum.md) | Required | The Owner Type. Please note the above Ownership Types where a Control Owner is required. |
| `title` | `string \| undefined` | Optional | Required for AMEX acquired merchants otherwise optional.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `30`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `firstName` | `string` | Required | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `middleInitial` | `string \| undefined` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `lastName` | `string` | Required | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `phoneNumber` | `string` | Required | 10-digit phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `phoneNumberExt` | `string \| undefined` | Optional | Phone number extension. Up to 8 digits of the format 12345678.<br>**Constraints**: *Maximum Length*: `8`, *Pattern*: `^[0-9]{1,8}$` |
| `phoneType` | [`PhoneTypeEnum \| undefined`](../../doc/models/phone-type-enum.md) | Optional | Phone type. |
| `alternatePhone` | `string \| undefined` | Optional | 10-digit alternate phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `alternatePhoneType` | [`AlternatePhoneTypeEnum \| undefined`](../../doc/models/alternate-phone-type-enum.md) | Optional | Alternate phone type. |
| `faxNumber` | `string \| undefined` | Optional | 10-digit fax number of the format 5131234567<br>**Constraints**: *Pattern*: `^[0-9]{10}$` |
| `email` | `string` | Required | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` |
| `ownershipPercentage` | `number \| undefined` | Optional | Ownership stake percentage.<br>**Constraints**: `>= 0`, `<= 100` |
| `ssn` | `string \| undefined` | Optional | Social security number. Do not include dashes.<br>**Constraints**: *Pattern*: `^[0-9]{9}$` |
| `dob` | `string \| undefined` | Optional | Date of Birth (CCYY-MM-DD). Must be at least 18 years old. |
| `addressLine1` | `string` | Required | Address Line 1. Field for house number, street and direction.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `addressLine2` | `string \| undefined` | Optional | Address Line 2. Field for apartment or suite numbers, etc.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `city` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `28`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `state` | [`StateEnum`](../../doc/models/state-enum.md) | Required | Valid US state, commonwealth, and territory codes are allowed. |
| `country` | `string` | Required, Constant | Only United States is allowed.<br>**Default**: `'United States'` |
| `postalCode` | `string` | Required | Postal code / zip code. The postal code must be valid for the address' country code.<br>**Constraints**: *Minimum Length*: `5`, *Maximum Length*: `5`, *Pattern*: `^[0-9]{5}$` |
| `postalCodeExtension` | `string \| undefined` | Optional | Postal code / zip code extension.  The postal code extension must be valid for the address' country code.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `4`, *Pattern*: `^[0-9]{4}$` |
| `identification` | [`Identification[] \| undefined`](../../doc/models/identification.md) | Optional | Optional. If any attribute in the identification object is populated then at least idNumber and idType are required. |

## Example (as JSON)

```json
{
  "type": "Control Owner Contact",
  "title": "Owner",
  "firstName": "Timothy",
  "middleInitial": "M",
  "lastName": "Jones",
  "phoneNumber": "1234567890",
  "phoneNumberExt": "1234",
  "faxNumber": "1234567890",
  "email": "test@test.com",
  "ownershipPercentage": 23,
  "ssn": "123456789",
  "dob": "2000-03-23",
  "addressLine1": "4355 N Coalwhipe St.",
  "city": "City Town",
  "state": "OH",
  "country": "United States",
  "postalCode": "80123",
  "postalCodeExtension": "1234",
  "phoneType": "mobile",
  "alternatePhone": "alternatePhone8"
}
```

