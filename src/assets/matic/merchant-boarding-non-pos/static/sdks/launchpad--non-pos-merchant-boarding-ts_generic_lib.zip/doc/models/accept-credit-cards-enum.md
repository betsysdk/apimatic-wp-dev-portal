
# Accept Credit Cards Enum

Does the business accept credit cards?

## Enumeration

`AcceptCreditCardsEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

