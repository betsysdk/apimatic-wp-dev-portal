
# Active Month Enum

## Enumeration

`ActiveMonthEnum`

## Fields

| Name |
|  --- |
| `jan` |
| `feb` |
| `mar` |
| `apr` |
| `may` |
| `jun` |
| `jul` |
| `aug` |
| `sep` |
| `oct` |
| `nov` |
| `dec` |

