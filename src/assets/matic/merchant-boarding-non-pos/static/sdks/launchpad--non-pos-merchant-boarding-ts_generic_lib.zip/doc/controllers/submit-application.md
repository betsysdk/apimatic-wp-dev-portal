# Submit Application

```ts
const submitApplicationController = new SubmitApplicationController(client);
```

## Class Name

`SubmitApplicationController`

## Methods

* [Validate Board](../../doc/controllers/submit-application.md#validate-board)
* [Inititate Board](../../doc/controllers/submit-application.md#inititate-board)


# Validate Board

Begins the merchant validation process before boarding after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```ts
async validateBoard(
  externalRefId: string,
  vCorrelationId?: string,
  contentType?: ContentTypeEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum \| undefined`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const contentType = ContentTypeEnum.EnumApplicationjson;

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await submitApplicationController.validateBoard(
  externalRefId,
  vCorrelationId,
  contentType
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Inititate Board

Begins the merchant boarding process after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```ts
async inititateBoard(
  externalRefId: string,
  vCorrelationId?: string,
  contentType?: ContentTypeEnum,
  threatmetrixId?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum \| undefined`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `threatmetrixId` | `string \| undefined` | Header, Optional | A unique session id |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const contentType = ContentTypeEnum.EnumApplicationjson;

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await submitApplicationController.inititateBoard(
  externalRefId,
  vCorrelationId,
  contentType
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

