
# Payment Method Enum

Payment method for the selected terminal.

## Enumeration

`PaymentMethodEnum`

## Fields

| Name |
|  --- |
| `enumPURCHASESALE` |
| `enumREPROGRAMOWN` |
| `enumMONTHTOMONTHRENTAL` |
| `lEASE` |

## Example

```
PURCHASE / SALE
```

