# Choose Equipment

```ts
const chooseEquipmentController = new ChooseEquipmentController(client);
```

## Class Name

`ChooseEquipmentController`

## Methods

* [Get Terminal Info](../../doc/controllers/choose-equipment.md#get-terminal-info)
* [Update Terminal](../../doc/controllers/choose-equipment.md#update-terminal)
* [Config Standalone Terminal](../../doc/controllers/choose-equipment.md#config-standalone-terminal)


# Get Terminal Info

Gets the terminal configuration information for a specific partner.

```ts
async getTerminalInfo(
  externalRefId: string,
  vCorrelationId?: string,
  contentType?: ContentTypeEnum,
  locationId?: string,
  merchantId?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<EquipmentSetup>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum \| undefined`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `string \| undefined` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `string \| undefined` | Header, Optional | The merchantId returned from POST /merchants call. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`EquipmentSetup`](../../doc/models/equipment-setup.md)

## Example Usage

```ts
const externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const contentType = ContentTypeEnum.EnumApplicationjson;

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await chooseEquipmentController.getTerminalInfo(
  externalRefId,
  vCorrelationId,
  contentType
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Update Terminal

Updates terminal configurations.

```ts
async updateTerminal(
  externalRefId: string,
  body: EquipmentSetup,
  vCorrelationId?: string,
  contentType?: ContentTypeEnum,
  locationId?: string,
  merchantId?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum \| undefined`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `string \| undefined` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `string \| undefined` | Header, Optional | The merchantId returned from POST /merchants call. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const body: EquipmentSetup = {
  shippingOption: ShippingOptionEnum.EnumNextDay,
  terminals: [
    {
      terminalConfigs: {
        terminalId: '67',
        price: 187.99,
        quantity: 1,
        logicalApplicationId: '194',
        accessMethod: 'SSL',
        paymentMethod: PaymentMethodEnum.EnumPURCHASESALE,
        environmentName: 'Restaurant',
        requestId: '41231',
        terminalModel: 'VAR - Xpient Solutions',
      },
      products: [
        {
          productId: '1',
          productName: 'Credit',
        }
      ],
    }
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await chooseEquipmentController.updateTerminal(
  externalRefId,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Config Standalone Terminal

Sets up terminal configurations.

```ts
async configStandaloneTerminal(
  externalRefId: string,
  body: EquipmentSetup,
  vCorrelationId?: string,
  contentType?: ContentTypeEnum,
  locationId?: string,
  merchantId?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum \| undefined`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `string \| undefined` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `string \| undefined` | Header, Optional | The merchantId returned from POST /merchants call. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const body: EquipmentSetup = {
  shippingOption: ShippingOptionEnum.EnumNextDay,
  terminals: [
    {
      terminalConfigs: {
        terminalId: '67',
        price: 187.99,
        quantity: 1,
        logicalApplicationId: '194',
        accessMethod: 'SSL',
        paymentMethod: PaymentMethodEnum.EnumPURCHASESALE,
        environmentName: 'Restaurant',
        requestId: '41231',
        terminalModel: 'VAR - Xpient Solutions',
      },
      products: [
        {
          productId: '1',
          productName: 'Credit',
        }
      ],
    }
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await chooseEquipmentController.configStandaloneTerminal(
  externalRefId,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

