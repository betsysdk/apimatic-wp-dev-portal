
# Signing Experience Enum

Signing ceremony type

## Enumeration

`SigningExperienceEnum`

## Fields

| Name |
|  --- |
| `embed` |
| `email` |
| `wet` |

## Example

```
email
```

