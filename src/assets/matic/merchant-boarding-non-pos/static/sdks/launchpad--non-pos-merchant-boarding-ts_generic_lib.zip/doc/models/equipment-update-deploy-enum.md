
# Equipment Update Deploy Enum

## Enumeration

`EquipmentUpdateDeployEnum`

## Fields

| Name |
|  --- |
| `m` |
| `d` |
| `n` |

## Example

```
M
```

