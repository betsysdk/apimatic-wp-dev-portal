
# Business Info

## Structure

`BusinessInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dbaName` | `string` | Required | The merchant name they do business as.  Generally with what their customers know the business.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `legalName` | `string` | Required | Business Legal Name as filed with the IRS.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `ownershipType` | [`OwnershipTypeEnum`](../../doc/models/ownership-type-enum.md) | Required | Required. OwnershipType defines the type of the Merchant Organization, and drives the requirements for data collections of beneficial and control owners under U.S. Financial Crimes Enforcement Network (FinCEN). |
| `mccCode` | `string` | Required | SIC Code / MCC Code (Merchant Category Code) is the code use to describe what the merchant is selling. Use MCC look up call to search valid codes, with sort and long description to find the MCC that most closely matches what the merchant is selling.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `4` |
| `businessEstablishedDate` | `string \| undefined` | Optional | Date (CCYY-MM-DD) on which the merchant's business was established. |
| `websiteUrl` | `string \| undefined` | Optional | The URL of the merchant's website.<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `80` |
| `numberOfLocation` | `number \| undefined` | Optional | Number of current locations. |
| `federalTaxId` | `string \| undefined` | Optional | The Federal Tax ID is the business Tax Identification Number (TIN) or Employer Identification Number (EIN). If the business is a sole proprietor they may use the social security number of the sole proprietor.<br>**Constraints**: *Minimum Length*: `9`, *Maximum Length*: `9`, *Pattern*: `^[0-9]{9}$` |
| `paymentAcceptanceMethod` | [`PaymentAcceptanceMethodEnum[] \| undefined`](../../doc/models/payment-acceptance-method-enum.md) | Optional | The ways in which the business is accepting payments. Multiple options may be selected. 'In person', would be card present at a brick and mortar store, 'onlinesite' would be card not present use on an ecommerce website, and 'phoneormailorder' would be card not present used for mail and telephone orders. |
| `pciadc` | [`PciadcEnum \| undefined`](../../doc/models/pciadc-enum.md) | Optional | Indication if the merchant has had an account data compromise.<br>**Default**: `PciadcEnum.No` |
| `pcidssValidated` | [`PcidssValidatedEnum \| undefined`](../../doc/models/pcidss-validated-enum.md) | Optional | Indictor showing if the merchant is compliant or not with the Payment Card Industry Data Security Standards.<br>**Default**: `PcidssValidatedEnum.Yes` |
| `surroundingArea` | [`SurroundingAreaEnum \| undefined`](../../doc/models/surrounding-area-enum.md) | Optional | Type of area surroundning the business. |
| `productServiceSold` | `string \| undefined` | Optional | Type of goods or services sold.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `(^[-a-zA-Z0-9_ &()*+,./:;=_'‘]{1,40}$)` |
| `ownAddYears` | `number \| undefined` | Optional | Years the business has been operating in their current location.<br>**Constraints**: `>= 0`, `<= 99` |
| `lengthOfContract` | `string \| undefined` | Optional | Inital contract term in months.<br>**Constraints**: *Pattern*: `([0-9]{3})$` |
| `seasonal` | [`SeasonalEnum \| undefined`](../../doc/models/seasonal-enum.md) | Optional | Does the business operate seasonally? |
| `activeMonths` | [`ActiveMonthEnum[] \| undefined`](../../doc/models/active-month-enum.md) | Optional | The months during which the business is actively operating. |
| `warranty` | [`WarrantyEnum \| undefined`](../../doc/models/warranty-enum.md) | Optional | Does the business offer warranties, dues, subscriptions, memberships, or other extended services? |
| `returnPolicy` | [`ReturnPolicyEnum \| undefined`](../../doc/models/return-policy-enum.md) | Optional | The business's return policy. |
| `taxExempt` | [`TaxExemptEnum \| undefined`](../../doc/models/tax-exempt-enum.md) | Optional | - |
| `acceptCreditCards` | [`AcceptCreditCardsEnum \| undefined`](../../doc/models/accept-credit-cards-enum.md) | Optional | Does the business accept credit cards? |

## Example (as JSON)

```json
{
  "dbaName": "The DBA Name",
  "legalName": "Timothy Jones",
  "ownershipType": "LLC",
  "mccCode": "5812",
  "businessEstablishedDate": "2000-03-23",
  "websiteUrl": "www.thefoodplace.com",
  "numberOfLocation": 2,
  "federalTaxId": "123456789",
  "paymentAcceptanceMethod": [
    "inPerson",
    "onlineSite"
  ],
  "pciadc": "No",
  "pcidssValidated": "No",
  "surroundingArea": "Commercial",
  "productServiceSold": "Food",
  "ownAddYears": 2,
  "seasonal": "Yes",
  "activeMonths": [
    "Jan",
    "Feb",
    "Mar"
  ],
  "warranty": "1 YEAR",
  "returnPolicy": "30 Day"
}
```

