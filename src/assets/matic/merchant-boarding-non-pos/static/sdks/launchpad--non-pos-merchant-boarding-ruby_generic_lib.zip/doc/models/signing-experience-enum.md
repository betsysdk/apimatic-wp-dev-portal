
# Signing Experience Enum

Signing ceremony type

## Enumeration

`SigningExperienceEnum`

## Fields

| Name |
|  --- |
| `EMBED` |
| `EMAIL` |
| `WET` |

## Example

```
email
```

