
# Auth Signers

## Structure

`AuthSigners`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `String` | Optional | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `middle_initial` | `String` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `last_name` | `String` | Optional | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `email` | `String` | Optional | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` |
| `status` | `String` | Optional | Status of the signer |
| `last_updated` | `DateTime` | Optional | Date contract was last updated |
| `date_submitted` | `DateTime` | Optional | Date contract was last updated |
| `date_sent` | `DateTime` | Optional | Date contract was sent |
| `date_delivered` | `DateTime` | Optional | Date contract was delivered |
| `date_signed` | `DateTime` | Optional | Date contract was signed |
| `signer_role_name` | `String` | Optional | Role of the signer |
| `signer_experience` | `String` | Optional | Method of sign |

## Example (as JSON)

```json
{
  "firstName": "Todd",
  "middleInitial": "M",
  "lastName": "Davis",
  "email": "test@gmail.com",
  "status": "sent",
  "signerRoleName": "Merchant",
  "signerExperience": "wet"
}
```

