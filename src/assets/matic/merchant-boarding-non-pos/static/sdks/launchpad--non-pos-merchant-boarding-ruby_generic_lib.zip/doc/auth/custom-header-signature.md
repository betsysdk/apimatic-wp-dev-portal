
# Custom Header Signature



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| Authorization | `String` | `License format is WORLDPAY license='xxxx'` | `authorization` |



**Note:** Auth credentials can be set using named parameter for any of the above credentials (e.g. `authorization`) in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```ruby
client = LaunchpadNonPosMerchantBoarding::Client.new(
  custom_header_authentication_credentials: CustomHeaderAuthenticationCredentials.new(
    authorization: 'Authorization'
  )
)
```


