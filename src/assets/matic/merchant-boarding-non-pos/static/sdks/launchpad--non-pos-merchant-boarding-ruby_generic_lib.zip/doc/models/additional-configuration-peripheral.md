
# Additional Configuration Peripheral

## Structure

`AdditionalConfigurationPeripheral`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `peripheral_id` | `String` | Optional | Peripheral IDs are internally populated. |
| `model` | `String` | Optional | Peripheral Name |
| `short_description` | `String` | Optional | Description of the peripheral |
| `long_description` | `String` | Optional | Verbose description of the peripheral |
| `is_emv_certified` | `TrueClass \| FalseClass` | Optional | Whether peripheral is EMV certified |
| `is_emv_capable` | `TrueClass \| FalseClass` | Optional | Whether peripheral is EMV Capable |
| `active_peripheral_flag` | `String` | Optional | - |
| `purchase_price` | `String` | Optional | purchase price of the peripheral |
| `lease_price` | `String` | Optional | lease price of the peripheral |
| `rental_price` | `String` | Optional | rental price of the peripheral |
| `hardware_cost` | `String` | Optional | hardware cost of the terminal |

## Example (as JSON)

```json
{
  "peripheralId": "35",
  "model": "Pin Pad 1000 SE",
  "shortDescription": "PP1S",
  "longDescription": "PPAD",
  "isEMVCertified": true,
  "isEMVCapable": true,
  "activePeripheralFlag": "Y",
  "purchasePrice": "168.12",
  "leasePrice": "100.12",
  "rentalPrice": "90",
  "hardwareCost": "50.75"
}
```

