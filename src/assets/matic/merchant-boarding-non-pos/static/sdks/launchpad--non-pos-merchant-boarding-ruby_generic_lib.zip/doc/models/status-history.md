
# Status History

## Structure

`StatusHistory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status_seq_number` | `Integer` | Optional | - |
| `detail_status` | `String` | Optional | - |
| `summary_status` | `String` | Optional | - |
| `status_category` | `String` | Optional | - |
| `status_date_time` | `DateTime` | Optional | - |

## Example (as JSON)

```json
{
  "statusSeqNumber": 2200,
  "detailStatus": "Contract Signed",
  "summaryStatus": "App Submitted",
  "statusCategory": "Contract",
  "statusDateTime": "2016-03-13T12:52:32.123Z"
}
```

