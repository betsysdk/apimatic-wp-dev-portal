# Choose Equipment

```ruby
choose_equipment_controller = client.choose_equipment
```

## Class Name

`ChooseEquipmentController`

## Methods

* [Get Terminal Info](../../doc/controllers/choose-equipment.md#get-terminal-info)
* [Update Terminal](../../doc/controllers/choose-equipment.md#update-terminal)
* [Config Standalone Terminal](../../doc/controllers/choose-equipment.md#config-standalone-terminal)


# Get Terminal Info

Gets the terminal configuration information for a specific partner.

```ruby
def get_terminal_info(external_ref_id,
                      v_correlation_id: nil,
                      content_type: ContentTypeEnum::ENUM_APPLICATIONJSON,
                      location_id: nil,
                      merchant_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `UUID \| String` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `UUID \| String` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `location_id` | `String` | Header, Optional | The locationId returned from POST /locations call. |
| `merchant_id` | `String` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

[`EquipmentSetup`](../../doc/models/equipment-setup.md)

## Example Usage

```ruby
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum::ENUM_APPLICATIONJSON

result = choose_equipment_controller.get_terminal_info(
  external_ref_id,
  v_correlation_id: v_correlation_id,
  content_type: content_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Update Terminal

Updates terminal configurations.

```ruby
def update_terminal(external_ref_id,
                    body,
                    v_correlation_id: nil,
                    content_type: ContentTypeEnum::ENUM_APPLICATIONJSON,
                    location_id: nil,
                    merchant_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `UUID \| String` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `v_correlation_id` | `UUID \| String` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `location_id` | `String` | Header, Optional | The locationId returned from POST /locations call. |
| `merchant_id` | `String` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`void`

## Example Usage

```ruby
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

body = EquipmentSetup.new(
  ShippingOptionEnum::ENUM_NEXT_DAY,
  [
    Terminal.new(
      TerminalConfig.new(
        '67',
        187.99,
        1,
        '194',
        'SSL',
        PaymentMethodEnum::ENUM_PURCHASE_SALE,
        'Restaurant',
        '41231',
        'VAR - Xpient Solutions'
      ),
      [
        Product.new(
          '1',
          'Credit'
        )
      ]
    )
  ]
)

choose_equipment_controller.update_terminal(
  external_ref_id,
  body
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Config Standalone Terminal

Sets up terminal configurations.

```ruby
def config_standalone_terminal(external_ref_id,
                               body,
                               v_correlation_id: nil,
                               content_type: ContentTypeEnum::ENUM_APPLICATIONJSON,
                               location_id: nil,
                               merchant_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `UUID \| String` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `v_correlation_id` | `UUID \| String` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `location_id` | `String` | Header, Optional | The locationId returned from POST /locations call. |
| `merchant_id` | `String` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`void`

## Example Usage

```ruby
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

body = EquipmentSetup.new(
  ShippingOptionEnum::ENUM_NEXT_DAY,
  [
    Terminal.new(
      TerminalConfig.new(
        '67',
        187.99,
        1,
        '194',
        'SSL',
        PaymentMethodEnum::ENUM_PURCHASE_SALE,
        'Restaurant',
        '41231',
        'VAR - Xpient Solutions'
      ),
      [
        Product.new(
          '1',
          'Credit'
        )
      ]
    )
  ]
)

choose_equipment_controller.config_standalone_terminal(
  external_ref_id,
  body
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

