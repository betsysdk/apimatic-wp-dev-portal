
# Docu Sign Link

## Structure

`DocuSignLink`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `embedding_url` | `String` | Optional | UI embeded link of the Docusign contract for the externalRefId. |

## Example (as JSON)

```json
{
  "embeddingUrl": "https://docusign.com/Signing/StartInSession.aspx?t=7f0d21a4-2798-402f-8b26-b12dbb37ae40"
}
```

