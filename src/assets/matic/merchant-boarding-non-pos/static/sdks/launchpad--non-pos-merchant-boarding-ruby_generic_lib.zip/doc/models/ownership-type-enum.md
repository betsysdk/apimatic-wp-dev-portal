
# Ownership Type Enum

Required. OwnershipType defines the type of the Merchant Organization, and drives the requirements for data collections of beneficial and control owners under U.S. Financial Crimes Enforcement Network (FinCEN).

## Enumeration

`OwnershipTypeEnum`

## Fields

| Name |
|  --- |
| `GOVERNMENT` |
| `ENUM_SOLE_PROPRIETOR` |
| `LLC` |
| `PARTNERSHIP` |
| `ENUM_FIN_INSTITUTION` |
| `NONPROFIT` |
| `ENUM_ASSOCIATIONESTATETRUST` |
| `ENUM_PRIVATE_CORPORATION` |
| `ENUM_SEC_REGISTERED` |
| `ENUM_PUBLIC_CORPORATION` |
| `OTHER` |

## Example

```
LLC
```

