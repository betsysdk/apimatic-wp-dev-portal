
# Product

## Structure

`Product`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `String` | Optional | Product ID is populated internally. |
| `product_name` | `String` | Optional | Payment method associated with the internally-populated ID. |

## Example (as JSON)

```json
{
  "productId": "1",
  "productName": "Debit"
}
```

