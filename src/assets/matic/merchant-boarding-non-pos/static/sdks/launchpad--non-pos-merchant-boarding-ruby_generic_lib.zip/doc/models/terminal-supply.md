
# Terminal Supply

## Structure

`TerminalSupply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `supply_type` | `String` | Required | - |
| `name` | `String` | Optional | Supply name |
| `quantity` | `Integer` | Optional | Supply quantity |
| `total` | `String` | Optional | Total Supplies. Valid values are 0.00<br><br>- 9999999999.99."<br>**Constraints**: *Pattern*: `(^\d{1,10}([.]\d{1,2})?)$` |

## Example (as JSON)

```json
{
  "supplyType": "supplyType2",
  "quantity": 2,
  "total": "220.21",
  "name": "name6"
}
```

