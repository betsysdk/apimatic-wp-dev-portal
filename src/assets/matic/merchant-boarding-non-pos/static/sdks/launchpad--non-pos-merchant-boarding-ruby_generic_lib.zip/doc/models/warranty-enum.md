
# Warranty Enum

Does the business offer warranties, dues, subscriptions, memberships, or other extended services?

## Enumeration

`WarrantyEnum`

## Fields

| Name |
|  --- |
| `ENUM_1_YEAR` |
| `ENUM_30_DAY` |
| `ENUM_60_DAY` |
| `ENUM_90_DAY` |
| `LIFETIME` |
| `NO` |

## Example

```
1 YEAR
```

