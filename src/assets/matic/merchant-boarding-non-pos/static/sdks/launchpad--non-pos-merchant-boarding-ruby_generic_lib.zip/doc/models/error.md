
# Error

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_code` | `String` | Optional | - |
| `error_message` | `String` | Optional | - |
| `target` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "errorCode": "ERROR_CODE",
  "errorMessage": "Error message here.",
  "target": "Target"
}
```

