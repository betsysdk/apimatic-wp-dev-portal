
# Shipping Option Enum

The speed you would like the equipment to be shipped.

## Enumeration

`ShippingOptionEnum`

## Fields

| Name |
|  --- |
| `GROUND` |
| `ENUM_NEXT_DAY` |
| `ENUM_2ND_DAY` |

## Example

```
next day
```

