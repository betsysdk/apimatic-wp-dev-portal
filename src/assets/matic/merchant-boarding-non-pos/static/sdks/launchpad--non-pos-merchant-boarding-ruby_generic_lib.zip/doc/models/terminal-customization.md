
# Terminal Customization

## Structure

`TerminalCustomization`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customization_id` | `String` | Optional | Customization ID is internally populated from a master list. |
| `customization_name` | `String` | Optional | - |
| `customization_field_value` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "customizationId": "10",
  "customizationName": "Auto-Close Time",
  "customizationFieldValue": "N"
}
```

