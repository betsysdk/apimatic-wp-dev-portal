
# Customization Code Details

## Structure

`CustomizationCodeDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `value` | `String` | Optional | customization code |
| `short_description` | `String` | Optional | short description of the customization code |
| `long_description` | `String` | Optional | long description of the customization code |

## Example (as JSON)

```json
{
  "value": "H",
  "shortDescription": "Host Auto Close",
  "longDescription": "Host Auto Close"
}
```

