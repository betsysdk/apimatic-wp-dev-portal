# Initiate Boarding Application

```ruby
initiate_boarding_application_controller = client.initiate_boarding_application
```

## Class Name

`InitiateBoardingApplicationController`

## Methods

* [Exisiting Application](../../doc/controllers/initiate-boarding-application.md#exisiting-application)
* [New Application](../../doc/controllers/initiate-boarding-application.md#new-application)
* [Fetch Application](../../doc/controllers/initiate-boarding-application.md#fetch-application)


# Exisiting Application

This endpoint allows merchants to update an existing application with new information.

```ruby
def exisiting_application(body,
                          v_correlation_id: nil,
                          content_type: ContentTypeEnum::ENUM_APPLICATIONJSON)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ExistingApplication1`](../../doc/models/existing-application-1.md) | Body, Required | - |
| `v_correlation_id` | `UUID \| String` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

`void`

## Example Usage

```ruby
body = ExistingApplication1.new(
  'df8a6d82-3bb4-4f3b-ba18-57a5981ede8e',
  BusinessInfo1.new(
    'The DBA Name',
    'legalName8',
    OwnershipTypeEnum::LLC,
    '5812',
    Date.iso8601('2000-03-23'),
    'www.thefoodplace.com',
    2,
    '123456781',
    [
      PaymentAcceptanceMethodEnum::INPERSON,
      PaymentAcceptanceMethodEnum::ONLINESITE
    ],
    PciadcEnum::NO,
    PcidssValidatedEnum::NO,
    SurroundingAreaEnum::COMMERCIAL,
    'Food',
    2,
    nil,
    SeasonalEnum::YES,
    [
      ActiveMonthEnum::JAN,
      ActiveMonthEnum::FEB,
      ActiveMonthEnum::MAR
    ],
    WarrantyEnum::ENUM_1_YEAR,
    ReturnPolicyEnum::ENUM_30_DAY,
    nil,
    nil,
    'US'
  ),
  TransactionInfo1.new(
    20000.12,
    82,
    2.3,
    32.41,
    'Global Payments',
    AcceptChargebacksEnum::NO,
    0,
    10,
    20,
    20,
    10,
    10,
    10,
    123.32,
    32.23,
    10000,
    2.3,
    10,
    Date.iso8601('2022-11-01')
  ),
  'Activate',
  nil,
  nil,
  nil,
  nil,
  [
    Address1.new(
      AddressTypeEnum::ENUM_MAILING_ADDRESS,
      '1234 W Tester Ave.',
      'City Town',
      State1Enum::CO,
      'United States',
      '80123',
      nil,
      '1234'
    ),
    Address1.new(
      AddressTypeEnum::ENUM_PHYSICAL_ADDRESS,
      '1234 W Tester Ave.',
      'City Town',
      State1Enum::CO,
      'United States',
      '80123',
      nil,
      '1234'
    )
  ],
  nil,
  nil,
  nil,
  nil,
  false
)

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum::ENUM_APPLICATIONJSON

initiate_boarding_application_controller.exisiting_application(
  body,
  v_correlation_id: v_correlation_id,
  content_type: content_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# New Application

Use this endpoint to collect the merchant information needed to initiate a new contract.

```ruby
def new_application(body,
                    v_correlation_id: nil,
                    content_type: ContentTypeEnum::ENUM_APPLICATIONJSON)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |
| `v_correlation_id` | `UUID \| String` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`ApplicationResponse`](../../doc/models/application-response.md)

## Example Usage

```ruby
body = Application.new(
  BusinessInfo1.new(
    'The DBA Name',
    'legalName8',
    OwnershipTypeEnum::LLC,
    '5812',
    Date.iso8601('2000-03-23'),
    'www.thefoodplace.com',
    2,
    '123456781',
    [
      PaymentAcceptanceMethodEnum::INPERSON,
      PaymentAcceptanceMethodEnum::ONLINESITE
    ],
    PciadcEnum::NO,
    PcidssValidatedEnum::NO,
    SurroundingAreaEnum::COMMERCIAL,
    'Food',
    2,
    nil,
    SeasonalEnum::YES,
    [
      ActiveMonthEnum::JAN,
      ActiveMonthEnum::FEB,
      ActiveMonthEnum::MAR
    ],
    WarrantyEnum::ENUM_1_YEAR,
    ReturnPolicyEnum::ENUM_30_DAY,
    nil,
    nil,
    'US'
  ),
  TransactionInfo1.new(
    20000.12,
    82,
    2.3,
    32.41,
    'Global Payments',
    AcceptChargebacksEnum::NO,
    0,
    10,
    20,
    20,
    10,
    10,
    10,
    123.32,
    32.23,
    10000,
    2.3,
    10,
    Date.iso8601('2022-11-01')
  ),
  [
    AuthorizedSigner1.new(
      RoleName1Enum::MERCHANT,
      SigningExperienceEnum::EMAIL,
      '2',
      'Todd',
      'Davis',
      '5131234567',
      'test@gmail.com',
      '123456789',
      Date.iso8601('2000-03-23'),
      '4355 N Coalwhipe St.',
      'Denver',
      State1Enum::CO,
      'United States',
      '12345',
      'President',
      'M',
      '1234',
      PhoneTypeEnum::MOBILE,
      '5131234567',
      AlternatePhoneTypeEnum::HOME,
      '5131234567',
      'suite 104',
      '1234'
    )
  ],
  [
    Contact1.new(
      Type4Enum::ENUM_PRIMARY_CONTACT,
      'Todd',
      'Davis',
      '5131234567',
      'test@gmail.com',
      'President',
      'M',
      '123456789',
      Date.iso8601('2000-03-23'),
      '1234',
      PhoneTypeEnum::MOBILE,
      '5131234567',
      AlternatePhoneTypeEnum::HOME,
      '5131234567'
    )
  ],
  [
    Address1.new(
      AddressTypeEnum::ENUM_MAILING_ADDRESS,
      '1234 W Tester Ave.',
      'City Town',
      State1Enum::CO,
      'United States',
      '80123',
      nil,
      '1234'
    ),
    Address1.new(
      AddressTypeEnum::ENUM_PHYSICAL_ADDRESS,
      '1234 W Tester Ave.',
      'City Town',
      State1Enum::CO,
      'United States',
      '80123',
      nil,
      '1234'
    ),
    Address1.new(
      AddressTypeEnum::ENUM_SHIPPING_ADDRESS,
      '1234 W Tester Ave.',
      'City Town',
      State1Enum::CO,
      'United States',
      '80123',
      nil,
      '1234'
    )
  ],
  '1341341234132412341',
  nil,
  nil,
  nil,
  nil,
  nil,
  nil,
  nil,
  'LP Connect API'
)

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum::ENUM_APPLICATIONJSON

result = initiate_boarding_application_controller.new_application(
  body,
  v_correlation_id: v_correlation_id,
  content_type: content_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Application

Retrieves existing application data.

```ruby
def fetch_application(external_ref_id,
                      v_correlation_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `UUID \| String` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `UUID \| String` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`ExistingApplication`](../../doc/models/existing-application.md)

## Example Usage

```ruby
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

result = initiate_boarding_application_controller.fetch_application(
  external_ref_id,
  v_correlation_id: v_correlation_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

