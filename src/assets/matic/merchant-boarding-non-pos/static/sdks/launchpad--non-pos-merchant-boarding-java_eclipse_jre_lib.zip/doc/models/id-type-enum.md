
# Id Type Enum

Type of ID provided by the owner.

## Enumeration

`IdTypeEnum`

## Fields

| Name |
|  --- |
| `EnumALIENID` |
| `EnumCREDITBUREAU` |
| `EnumDRIVERSLICENSE` |
| `EnumSTATEID` |
| `EnumMEXICANCONSULATE` |
| `EnumMILITARYID` |
| `OTHER` |
| `PASSPORT` |

## Example

```
PASSPORT
```

