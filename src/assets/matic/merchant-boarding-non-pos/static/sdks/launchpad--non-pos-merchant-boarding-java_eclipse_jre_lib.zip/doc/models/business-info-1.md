
# Business Info 1

## Structure

`BusinessInfo1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DbaName` | `String` | Required | The merchant name they do business as.  Generally with what their customers know the business.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getDbaName() | setDbaName(String dbaName) |
| `LegalName` | `String` | Required | Business Legal Name as filed with the IRS.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^([a-z0-9& -]{1,40})$` | String getLegalName() | setLegalName(String legalName) |
| `OwnershipType` | [`OwnershipTypeEnum`](../../doc/models/ownership-type-enum.md) | Required | Required. OwnershipType defines the type of the Merchant Organization, and drives the requirements for data collections of beneficial and control owners under U.S. Financial Crimes Enforcement Network (FinCEN). | OwnershipTypeEnum getOwnershipType() | setOwnershipType(OwnershipTypeEnum ownershipType) |
| `MccCode` | `String` | Required | SIC Code / MCC Code (Merchant Category Code) is the code use to describe what the merchant is selling. Use MCC look up call to search valid codes, with sort and long description to find the MCC that most closely matches what the merchant is selling.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `4` | String getMccCode() | setMccCode(String mccCode) |
| `BusinessEstablishedDate` | `LocalDate` | Optional | Date (CCYY-MM-DD) on which the merchant's business was established. | LocalDate getBusinessEstablishedDate() | setBusinessEstablishedDate(LocalDate businessEstablishedDate) |
| `WebsiteUrl` | `String` | Optional | The URL of the merchant's website.<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `80` | String getWebsiteUrl() | setWebsiteUrl(String websiteUrl) |
| `NumberOfLocation` | `Integer` | Optional | Number of current locations. | Integer getNumberOfLocation() | setNumberOfLocation(Integer numberOfLocation) |
| `FederalTaxId` | `String` | Optional | The Federal Tax ID is the business Tax Identification Number (TIN) or Employer Identification Number (EIN). If the business is a sole proprietor they may use the social security number of the sole proprietor.The full list of restricted federal tax id-<br>“000000000” “000000001” “000000002” “000000003” “000000004” “000000005” “000000006” “000000007” “000000008” “000000009" "111111110" “111111111” "111111112" "111111113" "111111114" "111111115" "111111116" "111111117" "111111118" "111111119" "222222220" "222222221" “222222222” "222222223" "222222224" "222222225" "222222226" "222222227" "222222228" "222222229" "333333330" "333333331" "333333332" “333333333” "333333334" "333333335" "333333336" "333333337" "333333338" "333333339"  "444444440" "444444441" "444444442" "444444443" “444444444” "444444445" "444444446" "444444447" "444444448" "444444449" "555555550" "555555551" "555555552" "555555553" "555555554" “555555555” "555555556" "555555557" "555555558" "555555559"  "666666660" "666666661" "666666662" "666666663" "666666664" "666666665" “666666666” "666666667" "666666668" "666666669" "777777770" "777777771” "777777772" "777777773" "777777774" "777777775" "777777776" “777777777” "777777778" "777777779" "888888880" "888888881" "888888882" "888888883" "888888884" "888888885" "888888886" "888888887" “888888888” "888888889"  "999999990" "999999991" "999999992" "999999993" "999999994" "999999995" "99999996"   "999999997" "999999998" “999999999”  "123456780" to "123456789" "123123123"<br>**Constraints**: *Minimum Length*: `9`, *Maximum Length*: `9`, *Pattern*: `^([a-z0-9& -]{1,40})$` | String getFederalTaxId() | setFederalTaxId(String federalTaxId) |
| `PaymentAcceptanceMethod` | [`List<PaymentAcceptanceMethodEnum>`](../../doc/models/payment-acceptance-method-enum.md) | Optional | The ways in which the business is accepting payments. Multiple options may be selected. 'In person', would be card present at a brick and mortar store, 'onlinesite' would be card not present use on an ecommerce website, and 'phoneormailorder' would be card not present used for mail and telephone orders. | List<PaymentAcceptanceMethodEnum> getPaymentAcceptanceMethod() | setPaymentAcceptanceMethod(List<PaymentAcceptanceMethodEnum> paymentAcceptanceMethod) |
| `Pciadc` | [`PciadcEnum`](../../doc/models/pciadc-enum.md) | Optional | Indication if the merchant has had an account data compromise.<br>**Default**: `PciadcEnum.NO` | PciadcEnum getPciadc() | setPciadc(PciadcEnum pciadc) |
| `PcidssValidated` | [`PcidssValidatedEnum`](../../doc/models/pcidss-validated-enum.md) | Optional | Indictor showing if the merchant is compliant or not with the Payment Card Industry Data Security Standards.<br>**Default**: `PcidssValidatedEnum.YES` | PcidssValidatedEnum getPcidssValidated() | setPcidssValidated(PcidssValidatedEnum pcidssValidated) |
| `SurroundingArea` | [`SurroundingAreaEnum`](../../doc/models/surrounding-area-enum.md) | Optional | Type of area surroundning the business. | SurroundingAreaEnum getSurroundingArea() | setSurroundingArea(SurroundingAreaEnum surroundingArea) |
| `ProductServiceSold` | `String` | Optional | Type of goods or services sold.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `(^[-a-zA-Z0-9_ &()*+,./:;=_'‘]{1,40}$)` | String getProductServiceSold() | setProductServiceSold(String productServiceSold) |
| `OwnAddYears` | `Integer` | Optional | Years the business has been operating in their current location.<br>**Constraints**: `>= 0`, `<= 99` | Integer getOwnAddYears() | setOwnAddYears(Integer ownAddYears) |
| `LengthOfContract` | `String` | Optional | Inital contract term in months.<br>**Constraints**: *Pattern*: `([0-9]{3})$` | String getLengthOfContract() | setLengthOfContract(String lengthOfContract) |
| `Seasonal` | [`SeasonalEnum`](../../doc/models/seasonal-enum.md) | Optional | Does the business operate seasonally? | SeasonalEnum getSeasonal() | setSeasonal(SeasonalEnum seasonal) |
| `ActiveMonths` | [`List<ActiveMonthEnum>`](../../doc/models/active-month-enum.md) | Optional | The months during which the business is actively operating. | List<ActiveMonthEnum> getActiveMonths() | setActiveMonths(List<ActiveMonthEnum> activeMonths) |
| `Warranty` | [`WarrantyEnum`](../../doc/models/warranty-enum.md) | Optional | Does the business offer warranties, dues, subscriptions, memberships, or other extended services? | WarrantyEnum getWarranty() | setWarranty(WarrantyEnum warranty) |
| `ReturnPolicy` | [`ReturnPolicyEnum`](../../doc/models/return-policy-enum.md) | Optional | The business's return policy. | ReturnPolicyEnum getReturnPolicy() | setReturnPolicy(ReturnPolicyEnum returnPolicy) |
| `TaxExempt` | [`TaxExemptEnum`](../../doc/models/tax-exempt-enum.md) | Optional | - | TaxExemptEnum getTaxExempt() | setTaxExempt(TaxExemptEnum taxExempt) |
| `AcceptCreditCards` | [`AcceptCreditCardsEnum`](../../doc/models/accept-credit-cards-enum.md) | Optional | Does the business accept credit cards? | AcceptCreditCardsEnum getAcceptCreditCards() | setAcceptCreditCards(AcceptCreditCardsEnum acceptCreditCards) |
| `GovOwnedMerchantCountry` | `String` | Optional | If merchant is a government entity or an entity at least 50% owned or controlled by government entity than provide 2 digit country code which belongs to the country. | String getGovOwnedMerchantCountry() | setGovOwnedMerchantCountry(String govOwnedMerchantCountry) |

## Example (as JSON)

```json
{
  "dbaName": "The DBA Name",
  "legalName": "legalName4",
  "ownershipType": "LLC",
  "mccCode": "5812",
  "businessEstablishedDate": "2000-03-23",
  "websiteUrl": "www.thefoodplace.com",
  "numberOfLocation": 2,
  "federalTaxId": "123456781",
  "paymentAcceptanceMethod": [
    "inPerson",
    "onlineSite"
  ],
  "pciadc": "No",
  "pcidssValidated": "No",
  "surroundingArea": "Commercial",
  "productServiceSold": "Food",
  "ownAddYears": 2,
  "seasonal": "Yes",
  "activeMonths": [
    "Jan",
    "Feb",
    "Mar"
  ],
  "warranty": "1 YEAR",
  "returnPolicy": "30 Day",
  "govOwnedMerchantCountry": "US"
}
```

