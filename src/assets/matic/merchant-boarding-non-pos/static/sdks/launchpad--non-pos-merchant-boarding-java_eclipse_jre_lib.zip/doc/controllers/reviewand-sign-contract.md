# Reviewand Sign Contract

```java
ReviewandSignContractController reviewandSignContractController = client.getReviewandSignContractController();
```

## Class Name

`ReviewandSignContractController`

## Methods

* [Get Contract](../../doc/controllers/reviewand-sign-contract.md#get-contract)
* [Docusign Link](../../doc/controllers/reviewand-sign-contract.md#docusign-link)


# Get Contract

Returns a PDF contract to be signed.

```java
CompletableFuture<DynamicResponse> getContractAsync(
    final UUID externalRefId,
    final UUID vCorrelationId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

`DynamicResponse`

## Example Usage

```java
UUID externalRefId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");

reviewandSignContractController.getContractAsync(externalRefId, vCorrelationId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Docusign Link

Retrieves a Docusign link to view the contract.

```java
CompletableFuture<DocuSignLink> docusignLinkAsync(
    final DocumentLink body,
    final UUID vCorrelationId,
    final ContentTypeEnum contentType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`DocumentLink`](../../doc/models/document-link.md) | Body, Required | - |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`DocuSignLink`](../../doc/models/docu-sign-link.md)

## Example Usage

```java
DocumentLink body = new DocumentLink.Builder(
    "df8a6d82-3bb4-4f3b-ba18-57a5981ede8e"
)
.returnUrl("https://docusign.com")
.build();

UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum contentType = ContentTypeEnum.ENUM_APPLICATIONJSON;

reviewandSignContractController.docusignLinkAsync(body, vCorrelationId, contentType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

