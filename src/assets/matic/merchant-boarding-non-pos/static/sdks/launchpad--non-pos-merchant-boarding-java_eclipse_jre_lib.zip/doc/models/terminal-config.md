
# Terminal Config

## Structure

`TerminalConfig`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RequestId` | `String` | Optional | Partner assigned unique request ID for terminal setup. | String getRequestId() | setRequestId(String requestId) |
| `TerminalId` | `String` | Required | Terminal ID number. | String getTerminalId() | setTerminalId(String terminalId) |
| `TerminalModel` | `String` | Optional | The model name of the terminal in use. | String getTerminalModel() | setTerminalModel(String terminalModel) |
| `Price` | `double` | Required | Terminal price | double getPrice() | setPrice(double price) |
| `Quantity` | `int` | Required | - | int getQuantity() | setQuantity(int quantity) |
| `LogicalApplicationId` | `String` | Required | Logical application ID. | String getLogicalApplicationId() | setLogicalApplicationId(String logicalApplicationId) |
| `AccessMethod` | `String` | Required | Methods of terminal access. | String getAccessMethod() | setAccessMethod(String accessMethod) |
| `PaymentMethod` | [`PaymentMethodEnum`](../../doc/models/payment-method-enum.md) | Required | Payment method for the selected terminal. | PaymentMethodEnum getPaymentMethod() | setPaymentMethod(PaymentMethodEnum paymentMethod) |
| `EnvironmentName` | `String` | Required | Environment name | String getEnvironmentName() | setEnvironmentName(String environmentName) |
| `IsVar` | `Boolean` | Optional | The value added reseller. Default value is false.<br>**Default**: `false` | Boolean getIsVar() | setIsVar(Boolean isVar) |
| `EmvCapable` | `Boolean` | Optional | Is it EMV capabale?<br>**Default**: `false` | Boolean getEmvCapable() | setEmvCapable(Boolean emvCapable) |
| `LeaseId` | `String` | Optional | Lease ID. Required when PaymentMethod is selected as lease. | String getLeaseId() | setLeaseId(String leaseId) |
| `LeaseTermLength` | [`LeaseTermLengthEnum`](../../doc/models/lease-term-length-enum.md) | Optional | Lease term for the peripheral | LeaseTermLengthEnum getLeaseTermLength() | setLeaseTermLength(LeaseTermLengthEnum leaseTermLength) |
| `TerminalSequenceNumber` | `String` | Optional | Terminal sequence number. If not sent, the API will autogenerate a number.<br>**Constraints**: *Pattern*: `^[0-9]` | String getTerminalSequenceNumber() | setTerminalSequenceNumber(String terminalSequenceNumber) |
| `SpecialCustomizations` | `String` | Optional | Any customization request for a terminal configuration.<br>**Constraints**: *Maximum Length*: `255` | String getSpecialCustomizations() | setSpecialCustomizations(String specialCustomizations) |

## Example (as JSON)

```json
{
  "requestId": "41231",
  "terminalId": "iCT220",
  "terminalModel": "Ingenico iCT220 CTLS 3.X Dial",
  "price": 187.99,
  "quantity": 1,
  "logicalApplicationId": "MONE510",
  "accessMethod": "SSL",
  "paymentMethod": "PURCHASE / SALE",
  "environmentName": "Retail",
  "isVar": false,
  "emvCapable": true,
  "leaseId": "12",
  "leaseTermLength": "24",
  "terminalSequenceNumber": "14",
  "specialCustomizations": "Mulitple merchant setup is Yes"
}
```

