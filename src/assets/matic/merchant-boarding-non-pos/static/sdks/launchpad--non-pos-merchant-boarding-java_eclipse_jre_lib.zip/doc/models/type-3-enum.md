
# Type 3 Enum

## Enumeration

`Type3Enum`

## Fields

| Name |
|  --- |
| `EnumGuarantor1Contact` |
| `EnumGuarantor2Contact` |
| `EnumGuarantor3Contact` |
| `EnumGuarantor4Contact` |

## Example

```
Guarantor 1 Contact
```

