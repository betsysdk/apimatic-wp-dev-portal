
# Gateway

A gateway is a hosted payment processing application provided by a service provider and accessed through an internet connection.

## Structure

`Gateway`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `GatewayId` | `String` | Optional | Internally-generated gateway ID. | String getGatewayId() | setGatewayId(String gatewayId) |
| `GatewayName` | `String` | Optional | - | String getGatewayName() | setGatewayName(String gatewayName) |
| `Notes` | `String` | Optional | Add any custom notes here. | String getNotes() | setNotes(String notes) |

## Example (as JSON)

```json
{
  "gatewayId": "15",
  "gatewayName": "Paymetric Gateway",
  "notes": "Paymetric Gateway v3"
}
```

