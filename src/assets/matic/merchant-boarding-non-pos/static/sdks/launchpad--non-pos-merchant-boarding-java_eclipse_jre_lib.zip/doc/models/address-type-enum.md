
# Address Type Enum

Address Type

1) Physical address is mandatory.
2) If equipment needs to be sent to a different location than the physical address, then shipping address should be added.
3) For any address type, addressLine1, city, state, postalCode and country are mandatory.

## Enumeration

`AddressTypeEnum`

## Fields

| Name |
|  --- |
| `EnumMailingAddress` |
| `EnumPhysicalAddress` |
| `EnumShippingAddress` |

## Example

```
Physical Address
```

