
# Dda Type Enum

Direct deposit account type.

## Enumeration

`DdaTypeEnum`

## Fields

| Name |
|  --- |
| `Checking` |
| `Savings` |

## Example

```
Checking
```

