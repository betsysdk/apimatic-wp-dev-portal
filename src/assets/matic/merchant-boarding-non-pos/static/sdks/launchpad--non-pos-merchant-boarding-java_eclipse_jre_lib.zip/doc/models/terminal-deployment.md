
# Terminal Deployment

## Structure

`TerminalDeployment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EquipmentUpdateDeploy` | [`EquipmentUpdateDeployEnum`](../../doc/models/equipment-update-deploy-enum.md) | Required | - | EquipmentUpdateDeployEnum getEquipmentUpdateDeploy() | setEquipmentUpdateDeploy(EquipmentUpdateDeployEnum equipmentUpdateDeploy) |
| `TerminalBuildFlag` | `Boolean` | Optional | - | Boolean getTerminalBuildFlag() | setTerminalBuildFlag(Boolean terminalBuildFlag) |
| `FrontEndBuildFlag` | `Boolean` | Optional | - | Boolean getFrontEndBuildFlag() | setFrontEndBuildFlag(Boolean frontEndBuildFlag) |
| `SicMerchantFlag` | `Boolean` | Optional | - | Boolean getSicMerchantFlag() | setSicMerchantFlag(Boolean sicMerchantFlag) |
| `SpecialInstructions` | `String` | Optional | Special instructions for terminal deployment.<br>**Constraints**: *Maximum Length*: `255` | String getSpecialInstructions() | setSpecialInstructions(String specialInstructions) |

## Example (as JSON)

```json
{
  "equipmentUpdateDeploy": "M",
  "terminalBuildFlag": true,
  "frontEndBuildFlag": true,
  "sicMerchantFlag": false,
  "specialInstructions": "Retail - H52460A (SP)"
}
```

