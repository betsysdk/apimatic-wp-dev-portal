
# Additional Configuration Customization

## Structure

`AdditionalConfigurationCustomization`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CustomizationId` | `String` | Optional | Customization Id is internally populated from a master list. | String getCustomizationId() | setCustomizationId(String customizationId) |
| `CustomizationType` | `String` | Optional | type of customization | String getCustomizationType() | setCustomizationType(String customizationType) |
| `UseProductMatrix` | `String` | Optional | Whether or not used in product matrix | String getUseProductMatrix() | setUseProductMatrix(String useProductMatrix) |
| `ProductId` | `String` | Optional | unique ID for the product | String getProductId() | setProductId(String productId) |
| `Code` | `String` | Optional | product code | String getCode() | setCode(String code) |
| `CustomizationCodeDetails` | [`List<CustomizationCodeDetails>`](../../doc/models/customization-code-details.md) | Optional | - | List<CustomizationCodeDetails> getCustomizationCodeDetails() | setCustomizationCodeDetails(List<CustomizationCodeDetails> customizationCodeDetails) |
| `CustomizationValue` | `String` | Optional | Actual Customization Value | String getCustomizationValue() | setCustomizationValue(String customizationValue) |
| `CustomizationFieldLength` | `String` | Optional | Length of the customization value | String getCustomizationFieldLength() | setCustomizationFieldLength(String customizationFieldLength) |
| `CustomizationDecimalPlace` | `String` | Optional | Number of decimal places | String getCustomizationDecimalPlace() | setCustomizationDecimalPlace(String customizationDecimalPlace) |
| `CustomizationMinValue` | `String` | Optional | Minimum Value. Only applicable if the customization value is a number | String getCustomizationMinValue() | setCustomizationMinValue(String customizationMinValue) |
| `CustomizationMaxValue` | `String` | Optional | Maximum Value. Only applicable if the customization value is a number | String getCustomizationMaxValue() | setCustomizationMaxValue(String customizationMaxValue) |
| `CharactersAllowed` | `String` | Optional | All characters allowed for customization. Only applicable if the customization value is a string. | String getCharactersAllowed() | setCharactersAllowed(String charactersAllowed) |
| `Rule` | `String` | Optional | customization rule | String getRule() | setRule(String rule) |
| `Regex` | `String` | Optional | Regular expression to validate the customization value | String getRegex() | setRegex(String regex) |
| `MultiMerchantFlag` | `Boolean` | Optional | Applicable in a multiple merchant situation<br>**Default**: `false` | Boolean getMultiMerchantFlag() | setMultiMerchantFlag(Boolean multiMerchantFlag) |
| `ShortDescription` | `String` | Optional | Description of the customization | String getShortDescription() | setShortDescription(String shortDescription) |
| `LongDescription` | `String` | Optional | Verbose description of the customiztion | String getLongDescription() | setLongDescription(String longDescription) |

## Example (as JSON)

```json
{
  "customizationId": "1",
  "customizationType": "time",
  "useProductMatrix": "N",
  "productId": "12",
  "code": "CST01",
  "customizationValue": "H",
  "customizationFieldLength": "1",
  "customizationDecimalPlace": "0",
  "customizationMinValue": "0",
  "customizationMaxValue": "6",
  "charactersAllowed": "abcdefghijklmnopqrstuvwxyz",
  "regex": "^[a-z]{1}",
  "multiMerchantFlag": false,
  "shortDescription": "CVV_PROMPTING",
  "longDescription": "CVV_PROMPTING"
}
```

