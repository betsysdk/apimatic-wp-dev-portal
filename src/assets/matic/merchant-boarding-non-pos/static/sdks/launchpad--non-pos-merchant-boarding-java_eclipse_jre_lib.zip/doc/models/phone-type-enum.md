
# Phone Type Enum

Phone type.

## Enumeration

`PhoneTypeEnum`

## Fields

| Name |
|  --- |
| `Mobile` |
| `Home` |

## Example

```
mobile
```

