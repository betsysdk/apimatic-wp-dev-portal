
# Schema

## Structure

`Schema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `Long` | Optional | - | Long getId() | setId(Long id) |

## Example (as JSON)

```json
{
  "id": 82
}
```

