
# Product

## Structure

`Product`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `String` | Optional | Product ID is populated internally. | String getProductId() | setProductId(String productId) |
| `ProductName` | `String` | Optional | Payment method associated with the internally-populated ID. | String getProductName() | setProductName(String productName) |

## Example (as JSON)

```json
{
  "productId": "1",
  "productName": "Debit"
}
```

