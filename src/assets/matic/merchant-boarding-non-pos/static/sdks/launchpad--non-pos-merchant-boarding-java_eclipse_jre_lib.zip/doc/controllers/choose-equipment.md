# Choose Equipment

```java
ChooseEquipmentController chooseEquipmentController = client.getChooseEquipmentController();
```

## Class Name

`ChooseEquipmentController`

## Methods

* [Get Terminal Info](../../doc/controllers/choose-equipment.md#get-terminal-info)
* [Update Terminal](../../doc/controllers/choose-equipment.md#update-terminal)
* [Config Standalone Terminal](../../doc/controllers/choose-equipment.md#config-standalone-terminal)


# Get Terminal Info

Gets the terminal configuration information for a specific partner.

```java
CompletableFuture<EquipmentSetup> getTerminalInfoAsync(
    final UUID externalRefId,
    final UUID vCorrelationId,
    final ContentTypeEnum contentType,
    final String locationId,
    final String merchantId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `String` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `String` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

[`EquipmentSetup`](../../doc/models/equipment-setup.md)

## Example Usage

```java
UUID externalRefId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum contentType = ContentTypeEnum.ENUM_APPLICATIONJSON;

chooseEquipmentController.getTerminalInfoAsync(externalRefId, vCorrelationId, contentType, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Update Terminal

Updates terminal configurations.

```java
CompletableFuture<Void> updateTerminalAsync(
    final UUID externalRefId,
    final EquipmentSetup body,
    final UUID vCorrelationId,
    final ContentTypeEnum contentType,
    final String locationId,
    final String merchantId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `String` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `String` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`void`

## Example Usage

```java
UUID externalRefId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
EquipmentSetup body = new EquipmentSetup.Builder()
    .shippingOption(ShippingOptionEnum.ENUM_NEXT_DAY)
    .terminals(Arrays.asList(
        new Terminal.Builder(
            new TerminalConfig.Builder(
                "67",
                187.99D,
                1,
                "194",
                "SSL",
                PaymentMethodEnum.ENUM_PURCHASE_SALE,
                "Restaurant"
            )
            .requestId("41231")
            .terminalModel("VAR - Xpient Solutions")
            .build(),
            Arrays.asList(
                new Product.Builder()
                    .productId("1")
                    .productName("Credit")
                    .build()
            )
        )
        .build()
    ))
    .build();


chooseEquipmentController.updateTerminalAsync(externalRefId, body, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Config Standalone Terminal

Sets up terminal configurations.

```java
CompletableFuture<Void> configStandaloneTerminalAsync(
    final UUID externalRefId,
    final EquipmentSetup body,
    final UUID vCorrelationId,
    final ContentTypeEnum contentType,
    final String locationId,
    final String merchantId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `String` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `String` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`void`

## Example Usage

```java
UUID externalRefId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
EquipmentSetup body = new EquipmentSetup.Builder()
    .shippingOption(ShippingOptionEnum.ENUM_NEXT_DAY)
    .terminals(Arrays.asList(
        new Terminal.Builder(
            new TerminalConfig.Builder(
                "67",
                187.99D,
                1,
                "194",
                "SSL",
                PaymentMethodEnum.ENUM_PURCHASE_SALE,
                "Restaurant"
            )
            .requestId("41231")
            .terminalModel("VAR - Xpient Solutions")
            .build(),
            Arrays.asList(
                new Product.Builder()
                    .productId("1")
                    .productName("Credit")
                    .build()
            )
        )
        .build()
    ))
    .build();


chooseEquipmentController.configStandaloneTerminalAsync(externalRefId, body, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

