# Equipment Lookup

```java
EquipmentLookupController equipmentLookupController = client.getEquipmentLookupController();
```

## Class Name

`EquipmentLookupController`

## Methods

* [Get Additional Configurations](../../doc/controllers/equipment-lookup.md#get-additional-configurations)
* [Get Equipment Supported](../../doc/controllers/equipment-lookup.md#get-equipment-supported)


# Get Additional Configurations

Fetches a list of valid terminal customizations and peripherals, such as electing to password protect a void.

```java
CompletableFuture<AdditionalConfigurationsResponse> getAdditionalConfigurationsAsync(
    final UUID externalRefId,
    final UUID vCorrelationId,
    final String logicalApplicationId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `logicalApplicationId` | `String` | Header, Optional | Logical App ID of the terminal. |

## Response Type

[`AdditionalConfigurationsResponse`](../../doc/models/additional-configurations-response.md)

## Example Usage

```java
UUID externalRefId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
String logicalApplicationId = "1073";

equipmentLookupController.getAdditionalConfigurationsAsync(externalRefId, vCorrelationId, logicalApplicationId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Equipment Supported

Retrieve applicable equipment for an existing application.

```java
CompletableFuture<InlineResponse200> getEquipmentSupportedAsync(
    final UUID externalRefId,
    final UUID vCorrelationId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`InlineResponse200`](../../doc/models/inline-response-200.md)

## Example Usage

```java
UUID externalRefId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");

equipmentLookupController.getEquipmentSupportedAsync(externalRefId, vCorrelationId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

