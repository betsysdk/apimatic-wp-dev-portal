
# Accept Chargebacks Enum

Do you have more than 25 chargeback accepted in the last 12 months?

## Enumeration

`AcceptChargebacksEnum`

## Fields

| Name |
|  --- |
| `Yes` |
| `No` |

## Example

```
No
```

