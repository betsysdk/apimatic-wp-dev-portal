
# Business Info

## Structure

`BusinessInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DbaName` | `String` | Required | The merchant name they do business as.  Generally with what their customers know the business.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getDbaName() | setDbaName(String dbaName) |
| `LegalName` | `String` | Required | Business Legal Name as filed with the IRS.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getLegalName() | setLegalName(String legalName) |
| `OwnershipType` | [`OwnershipTypeEnum`](../../doc/models/ownership-type-enum.md) | Required | Required. OwnershipType defines the type of the Merchant Organization, and drives the requirements for data collections of beneficial and control owners under U.S. Financial Crimes Enforcement Network (FinCEN). | OwnershipTypeEnum getOwnershipType() | setOwnershipType(OwnershipTypeEnum ownershipType) |
| `MccCode` | `String` | Required | SIC Code / MCC Code (Merchant Category Code) is the code use to describe what the merchant is selling. Use MCC look up call to search valid codes, with sort and long description to find the MCC that most closely matches what the merchant is selling.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `4` | String getMccCode() | setMccCode(String mccCode) |
| `BusinessEstablishedDate` | `LocalDate` | Optional | Date (CCYY-MM-DD) on which the merchant's business was established. | LocalDate getBusinessEstablishedDate() | setBusinessEstablishedDate(LocalDate businessEstablishedDate) |
| `WebsiteUrl` | `String` | Optional | The URL of the merchant's website.<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `80` | String getWebsiteUrl() | setWebsiteUrl(String websiteUrl) |
| `NumberOfLocation` | `Integer` | Optional | Number of current locations. | Integer getNumberOfLocation() | setNumberOfLocation(Integer numberOfLocation) |
| `FederalTaxId` | `String` | Optional | The Federal Tax ID is the business Tax Identification Number (TIN) or Employer Identification Number (EIN). If the business is a sole proprietor they may use the social security number of the sole proprietor.<br>**Constraints**: *Minimum Length*: `9`, *Maximum Length*: `9`, *Pattern*: `^[0-9]{9}$` | String getFederalTaxId() | setFederalTaxId(String federalTaxId) |
| `PaymentAcceptanceMethod` | [`List<PaymentAcceptanceMethodEnum>`](../../doc/models/payment-acceptance-method-enum.md) | Optional | The ways in which the business is accepting payments. Multiple options may be selected. 'In person', would be card present at a brick and mortar store, 'onlinesite' would be card not present use on an ecommerce website, and 'phoneormailorder' would be card not present used for mail and telephone orders. | List<PaymentAcceptanceMethodEnum> getPaymentAcceptanceMethod() | setPaymentAcceptanceMethod(List<PaymentAcceptanceMethodEnum> paymentAcceptanceMethod) |
| `Pciadc` | [`PciadcEnum`](../../doc/models/pciadc-enum.md) | Optional | Indication if the merchant has had an account data compromise.<br>**Default**: `PciadcEnum.NO` | PciadcEnum getPciadc() | setPciadc(PciadcEnum pciadc) |
| `PcidssValidated` | [`PcidssValidatedEnum`](../../doc/models/pcidss-validated-enum.md) | Optional | Indictor showing if the merchant is compliant or not with the Payment Card Industry Data Security Standards.<br>**Default**: `PcidssValidatedEnum.YES` | PcidssValidatedEnum getPcidssValidated() | setPcidssValidated(PcidssValidatedEnum pcidssValidated) |
| `SurroundingArea` | [`SurroundingAreaEnum`](../../doc/models/surrounding-area-enum.md) | Optional | Type of area surroundning the business. | SurroundingAreaEnum getSurroundingArea() | setSurroundingArea(SurroundingAreaEnum surroundingArea) |
| `ProductServiceSold` | `String` | Optional | Type of goods or services sold.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `(^[-a-zA-Z0-9_ &()*+,./:;=_'‘]{1,40}$)` | String getProductServiceSold() | setProductServiceSold(String productServiceSold) |
| `OwnAddYears` | `Integer` | Optional | Years the business has been operating in their current location.<br>**Constraints**: `>= 0`, `<= 99` | Integer getOwnAddYears() | setOwnAddYears(Integer ownAddYears) |
| `LengthOfContract` | `String` | Optional | Inital contract term in months.<br>**Constraints**: *Pattern*: `([0-9]{3})$` | String getLengthOfContract() | setLengthOfContract(String lengthOfContract) |
| `Seasonal` | [`SeasonalEnum`](../../doc/models/seasonal-enum.md) | Optional | Does the business operate seasonally? | SeasonalEnum getSeasonal() | setSeasonal(SeasonalEnum seasonal) |
| `ActiveMonths` | [`List<ActiveMonthEnum>`](../../doc/models/active-month-enum.md) | Optional | The months during which the business is actively operating. | List<ActiveMonthEnum> getActiveMonths() | setActiveMonths(List<ActiveMonthEnum> activeMonths) |
| `Warranty` | [`WarrantyEnum`](../../doc/models/warranty-enum.md) | Optional | Does the business offer warranties, dues, subscriptions, memberships, or other extended services? | WarrantyEnum getWarranty() | setWarranty(WarrantyEnum warranty) |
| `ReturnPolicy` | [`ReturnPolicyEnum`](../../doc/models/return-policy-enum.md) | Optional | The business's return policy. | ReturnPolicyEnum getReturnPolicy() | setReturnPolicy(ReturnPolicyEnum returnPolicy) |
| `TaxExempt` | [`TaxExemptEnum`](../../doc/models/tax-exempt-enum.md) | Optional | - | TaxExemptEnum getTaxExempt() | setTaxExempt(TaxExemptEnum taxExempt) |
| `AcceptCreditCards` | [`AcceptCreditCardsEnum`](../../doc/models/accept-credit-cards-enum.md) | Optional | Does the business accept credit cards? | AcceptCreditCardsEnum getAcceptCreditCards() | setAcceptCreditCards(AcceptCreditCardsEnum acceptCreditCards) |

## Example (as JSON)

```json
{
  "dbaName": "The DBA Name",
  "legalName": "Timothy Jones",
  "ownershipType": "LLC",
  "mccCode": "5812",
  "businessEstablishedDate": "2000-03-23",
  "websiteUrl": "www.thefoodplace.com",
  "numberOfLocation": 2,
  "federalTaxId": "123456789",
  "paymentAcceptanceMethod": [
    "inPerson",
    "onlineSite"
  ],
  "pciadc": "No",
  "pcidssValidated": "No",
  "surroundingArea": "Commercial",
  "productServiceSold": "Food",
  "ownAddYears": 2,
  "seasonal": "Yes",
  "activeMonths": [
    "Jan",
    "Feb",
    "Mar"
  ],
  "warranty": "1 YEAR",
  "returnPolicy": "30 Day"
}
```

