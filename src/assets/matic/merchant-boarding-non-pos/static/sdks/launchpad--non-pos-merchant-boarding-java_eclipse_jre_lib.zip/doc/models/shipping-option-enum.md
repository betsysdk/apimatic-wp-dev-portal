
# Shipping Option Enum

The speed you would like the equipment to be shipped.

## Enumeration

`ShippingOptionEnum`

## Fields

| Name |
|  --- |
| `Ground` |
| `EnumNextDay` |
| `Enum2ndDay` |

## Example

```
next day
```

