
# Payment Acceptance Method Enum

## Enumeration

`PaymentAcceptanceMethodEnum`

## Fields

| Name |
|  --- |
| `InPerson` |
| `OnlineSite` |
| `PhoneOrMailOrder` |

