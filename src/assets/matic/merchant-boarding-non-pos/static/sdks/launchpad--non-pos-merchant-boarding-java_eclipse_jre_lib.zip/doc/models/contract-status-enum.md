
# Contract Status Enum

## Enumeration

`ContractStatusEnum`

## Fields

| Name |
|  --- |
| `Complete` |
| `EnumInProgress` |
| `Error` |
| `Pending` |

