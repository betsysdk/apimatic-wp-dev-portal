
# Error

## Structure

`Error`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `errorCode` | `?string` | Optional | - | getErrorCode(): ?string | setErrorCode(?string errorCode): void |
| `errorMessage` | `?string` | Optional | - | getErrorMessage(): ?string | setErrorMessage(?string errorMessage): void |
| `target` | `?string` | Optional | - | getTarget(): ?string | setTarget(?string target): void |

## Example (as JSON)

```json
{
  "errorCode": "ERROR_CODE",
  "errorMessage": "Error message here.",
  "target": "Target"
}
```

