
# Terminal Supply

## Structure

`TerminalSupply`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `supplyType` | `string` | Required | - | getSupplyType(): string | setSupplyType(string supplyType): void |
| `name` | `?string` | Optional | Supply name | getName(): ?string | setName(?string name): void |
| `quantity` | `?int` | Optional | Supply quantity | getQuantity(): ?int | setQuantity(?int quantity): void |
| `total` | `?string` | Optional | Total Supplies. Valid values are 0.00<br><br>- 9999999999.99."<br>**Constraints**: *Pattern*: `(^\d{1,10}([.]\d{1,2})?)$` | getTotal(): ?string | setTotal(?string total): void |

## Example (as JSON)

```json
{
  "supplyType": "supplyType2",
  "quantity": 2,
  "total": "220.21",
  "name": "name6"
}
```

