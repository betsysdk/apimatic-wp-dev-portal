
# Ach Type Enum

Check deposit type

## Enumeration

`AchTypeEnum`

## Fields

| Name |
|  --- |
| `ENUM_COMMERCIAL_CHECKING` |
| `ENUM_PRIVATE_CHECKING` |

## Example

```
Commercial Checking
```

