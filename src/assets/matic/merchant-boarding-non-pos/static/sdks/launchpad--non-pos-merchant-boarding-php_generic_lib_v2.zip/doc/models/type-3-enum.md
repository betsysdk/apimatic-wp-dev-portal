
# Type 3 Enum

## Enumeration

`Type3Enum`

## Fields

| Name |
|  --- |
| `ENUM_GUARANTOR_1_CONTACT` |
| `ENUM_GUARANTOR_2_CONTACT` |
| `ENUM_GUARANTOR_3_CONTACT` |
| `ENUM_GUARANTOR_4_CONTACT` |

## Example

```
Guarantor 1 Contact
```

