
# Product

## Structure

`Product`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `productId` | `?string` | Optional | Product ID is populated internally. | getProductId(): ?string | setProductId(?string productId): void |
| `productName` | `?string` | Optional | Payment method associated with the internally-populated ID. | getProductName(): ?string | setProductName(?string productName): void |

## Example (as JSON)

```json
{
  "productId": "1",
  "productName": "Debit"
}
```

