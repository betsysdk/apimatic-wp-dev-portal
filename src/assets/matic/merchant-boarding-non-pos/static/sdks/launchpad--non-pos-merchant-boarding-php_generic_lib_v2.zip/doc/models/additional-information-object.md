
# Additional Information Object

Required for some partners. Work with your Developer Integrations specialist for more information.

## Structure

`AdditionalInformationObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | [`?string(KeyEnum)`](../../doc/models/key-enum.md) | Optional | - | getKey(): ?string | setKey(?string key): void |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |

## Example (as JSON)

```json
{
  "key": "partnerEmployeeId",
  "value": "4656"
}
```

