
# Terminal Customization

## Structure

`TerminalCustomization`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `customizationId` | `?string` | Optional | Customization ID is internally populated from a master list. | getCustomizationId(): ?string | setCustomizationId(?string customizationId): void |
| `customizationName` | `?string` | Optional | - | getCustomizationName(): ?string | setCustomizationName(?string customizationName): void |
| `customizationFieldValue` | `?string` | Optional | - | getCustomizationFieldValue(): ?string | setCustomizationFieldValue(?string customizationFieldValue): void |

## Example (as JSON)

```json
{
  "customizationId": "10",
  "customizationName": "Auto-Close Time",
  "customizationFieldValue": "N"
}
```

