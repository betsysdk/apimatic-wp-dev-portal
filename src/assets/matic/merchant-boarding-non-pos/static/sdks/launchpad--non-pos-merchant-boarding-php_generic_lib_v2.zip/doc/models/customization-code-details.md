
# Customization Code Details

## Structure

`CustomizationCodeDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `value` | `?string` | Optional | customization code | getValue(): ?string | setValue(?string value): void |
| `shortDescription` | `?string` | Optional | short description of the customization code | getShortDescription(): ?string | setShortDescription(?string shortDescription): void |
| `longDescription` | `?string` | Optional | long description of the customization code | getLongDescription(): ?string | setLongDescription(?string longDescription): void |

## Example (as JSON)

```json
{
  "value": "H",
  "shortDescription": "Host Auto Close",
  "longDescription": "Host Auto Close"
}
```

