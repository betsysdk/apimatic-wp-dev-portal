
# Payment Method 1 Enum

Payment method for the selected peripheral.

## Enumeration

`PaymentMethod1Enum`

## Fields

| Name |
|  --- |
| `ENUM_PURCHASE_SALE` |
| `ENUM_REPROGRAM_OWN` |
| `ENUM_MONTHTOMONTH_RENTAL` |
| `LEASE` |

## Example

```
PURCHASE / SALE
```

