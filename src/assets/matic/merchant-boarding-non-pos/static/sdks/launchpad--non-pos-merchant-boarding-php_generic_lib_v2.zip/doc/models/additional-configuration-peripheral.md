
# Additional Configuration Peripheral

## Structure

`AdditionalConfigurationPeripheral`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `peripheralId` | `?string` | Optional | Peripheral IDs are internally populated. | getPeripheralId(): ?string | setPeripheralId(?string peripheralId): void |
| `model` | `?string` | Optional | Peripheral Name | getModel(): ?string | setModel(?string model): void |
| `shortDescription` | `?string` | Optional | Description of the peripheral | getShortDescription(): ?string | setShortDescription(?string shortDescription): void |
| `longDescription` | `?string` | Optional | Verbose description of the peripheral | getLongDescription(): ?string | setLongDescription(?string longDescription): void |
| `isEMVCertified` | `?bool` | Optional | Whether peripheral is EMV certified | getIsEMVCertified(): ?bool | setIsEMVCertified(?bool isEMVCertified): void |
| `isEMVCapable` | `?bool` | Optional | Whether peripheral is EMV Capable | getIsEMVCapable(): ?bool | setIsEMVCapable(?bool isEMVCapable): void |
| `activePeripheralFlag` | `?string` | Optional | - | getActivePeripheralFlag(): ?string | setActivePeripheralFlag(?string activePeripheralFlag): void |
| `purchasePrice` | `?string` | Optional | purchase price of the peripheral | getPurchasePrice(): ?string | setPurchasePrice(?string purchasePrice): void |
| `leasePrice` | `?string` | Optional | lease price of the peripheral | getLeasePrice(): ?string | setLeasePrice(?string leasePrice): void |
| `rentalPrice` | `?string` | Optional | rental price of the peripheral | getRentalPrice(): ?string | setRentalPrice(?string rentalPrice): void |
| `hardwareCost` | `?string` | Optional | hardware cost of the terminal | getHardwareCost(): ?string | setHardwareCost(?string hardwareCost): void |

## Example (as JSON)

```json
{
  "peripheralId": "35",
  "model": "Pin Pad 1000 SE",
  "shortDescription": "PP1S",
  "longDescription": "PPAD",
  "isEMVCertified": true,
  "isEMVCapable": true,
  "activePeripheralFlag": "Y",
  "purchasePrice": "168.12",
  "leasePrice": "100.12",
  "rentalPrice": "90",
  "hardwareCost": "50.75"
}
```

