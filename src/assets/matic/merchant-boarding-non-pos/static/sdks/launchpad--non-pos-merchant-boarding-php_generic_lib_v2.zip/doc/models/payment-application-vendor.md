
# Payment Application Vendor

A payment application is installed software developed for processing various payments types: Credit, Debit, Gift, Checks, etc. and can be integrated with a POS system or used in a standalone manner.

## Structure

`PaymentApplicationVendor`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paymentApplicationId` | `?string` | Optional | Payment application ID | getPaymentApplicationId(): ?string | setPaymentApplicationId(?string paymentApplicationId): void |
| `paymentApplicationName` | `?string` | Optional | - | getPaymentApplicationName(): ?string | setPaymentApplicationName(?string paymentApplicationName): void |
| `vendorId` | `?string` | Optional | Vendor ID for the payment application. | getVendorId(): ?string | setVendorId(?string vendorId): void |
| `version` | `?string` | Optional | Payment application version. | getVersion(): ?string | setVersion(?string version): void |
| `reseller` | `?string` | Optional | Reseller | getReseller(): ?string | setReseller(?string reseller): void |
| `lastUpgradeDate` | `?DateTime` | Optional | Last date payment application was upgraded. | getLastUpgradeDate(): ?\DateTime | setLastUpgradeDate(?\DateTime lastUpgradeDate): void |
| `notes` | `?string` | Optional | Custom notes can go here. | getNotes(): ?string | setNotes(?string notes): void |

## Example (as JSON)

```json
{
  "paymentApplicationId": "9",
  "paymentApplicationName": "PurchaseExpress",
  "vendorId": "4",
  "version": "1",
  "reseller": "Agilysys Inc",
  "lastUpgradeDate": "02/18/2012 00:00:00",
  "notes": "Paymetric Gateway v3"
}
```

