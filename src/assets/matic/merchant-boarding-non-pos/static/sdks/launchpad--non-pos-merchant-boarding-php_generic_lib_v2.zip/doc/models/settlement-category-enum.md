
# Settlement Category Enum

Settlement categories gives merhant an option to settle their account with different settlement categories. It is an optional field. However at time of boarding it becomes a required field.

## Enumeration

`SettlementCategoryEnum`

## Fields

| Name |
|  --- |
| `DEPOSITS` |
| `FEES` |
| `EXCEPTIONS` |

