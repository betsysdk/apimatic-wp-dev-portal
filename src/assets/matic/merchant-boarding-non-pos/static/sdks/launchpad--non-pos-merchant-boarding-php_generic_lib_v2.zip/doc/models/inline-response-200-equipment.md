
# Inline Response 200 Equipment

## Structure

`InlineResponse200Equipment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `logicalApplicationId` | `?string` | Optional | - | getLogicalApplicationId(): ?string | setLogicalApplicationId(?string logicalApplicationId): void |
| `environment` | `?string` | Optional | - | getEnvironment(): ?string | setEnvironment(?string environment): void |

## Example (as JSON)

```json
{
  "id": "1",
  "name": "Verifone LX570",
  "logicalApplicationId": "1073",
  "environment": "Retail"
}
```

