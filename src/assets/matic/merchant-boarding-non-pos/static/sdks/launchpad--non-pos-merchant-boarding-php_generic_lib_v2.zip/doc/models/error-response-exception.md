
# Error Response Exception

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `httpStatusCode` | `?int` | Optional | - | getHttpStatusCode(): ?int | setHttpStatusCode(?int httpStatusCode): void |
| `httpStatusMessage` | `?string` | Optional | - | getHttpStatusMessage(): ?string | setHttpStatusMessage(?string httpStatusMessage): void |
| `errors` | [`?(Error[])`](../../doc/models/error.md) | Optional | - | getErrors(): ?array | setErrors(?array errors): void |

## Example (as JSON)

```json
{
  "httpStatusCode": 404,
  "httpStatusMessage": "STATUS-MESSAGE",
  "errors": [
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    },
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    },
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    }
  ]
}
```

