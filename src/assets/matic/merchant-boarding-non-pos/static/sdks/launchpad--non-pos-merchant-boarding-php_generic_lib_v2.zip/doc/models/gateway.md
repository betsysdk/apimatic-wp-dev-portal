
# Gateway

A gateway is a hosted payment processing application provided by a service provider and accessed through an internet connection.

## Structure

`Gateway`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `gatewayId` | `?string` | Optional | Internally-generated gateway ID. | getGatewayId(): ?string | setGatewayId(?string gatewayId): void |
| `gatewayName` | `?string` | Optional | - | getGatewayName(): ?string | setGatewayName(?string gatewayName): void |
| `notes` | `?string` | Optional | Add any custom notes here. | getNotes(): ?string | setNotes(?string notes): void |

## Example (as JSON)

```json
{
  "gatewayId": "15",
  "gatewayName": "Paymetric Gateway",
  "notes": "Paymetric Gateway v3"
}
```

