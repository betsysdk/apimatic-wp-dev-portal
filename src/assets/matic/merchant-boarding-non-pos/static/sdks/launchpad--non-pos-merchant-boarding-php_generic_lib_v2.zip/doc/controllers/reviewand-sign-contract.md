# Reviewand Sign Contract

```php
$reviewandSignContractController = $client->getReviewandSignContractController();
```

## Class Name

`ReviewandSignContractController`

## Methods

* [Get Contract](../../doc/controllers/reviewand-sign-contract.md#get-contract)
* [Docusign Link](../../doc/controllers/reviewand-sign-contract.md#docusign-link)


# Get Contract

Returns a PDF contract to be signed.

```php
function getContract(string $externalRefId, ?string $vCorrelationId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

`mixed`

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$result = $reviewAndSignContractController->getContract(
    $externalRefId,
    $vCorrelationId
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Docusign Link

Retrieves a Docusign link to view the contract.

```php
function docusignLink(
    DocumentLink $body,
    ?string $vCorrelationId = null,
    ?string $contentType = ContentTypeEnum::ENUM_APPLICATIONJSON
): DocuSignLink
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`DocumentLink`](../../doc/models/document-link.md) | Body, Required | - |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`?string(ContentTypeEnum)`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`DocuSignLink`](../../doc/models/docu-sign-link.md)

## Example Usage

```php
$body = DocumentLinkBuilder::init(
    'df8a6d82-3bb4-4f3b-ba18-57a5981ede8e'
)
    ->returnUrl('https://docusign.com')
    ->build();

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$contentType = ContentTypeEnum::ENUM_APPLICATIONJSON;

$result = $reviewAndSignContractController->docusignLink(
    $body,
    $vCorrelationId,
    $contentType
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

