
# Alternate Phone Type Enum

Alternate phone type.

## Enumeration

`AlternatePhoneTypeEnum`

## Fields

| Name |
|  --- |
| `MOBILE` |
| `HOME` |

## Example

```
home
```

