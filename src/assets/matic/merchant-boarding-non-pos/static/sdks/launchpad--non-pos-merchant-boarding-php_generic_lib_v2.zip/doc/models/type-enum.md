
# Type Enum

The Owner Type. Please note the above Ownership Types where a Control Owner is required.

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `ENUM_CONTROL_OWNER_CONTACT` |
| `ENUM_OWNER_1_CONTACT` |
| `ENUM_OWNER_2_CONTACT` |
| `ENUM_OWNER_3_CONTACT` |
| `ENUM_OWNER_4_CONTACT` |

