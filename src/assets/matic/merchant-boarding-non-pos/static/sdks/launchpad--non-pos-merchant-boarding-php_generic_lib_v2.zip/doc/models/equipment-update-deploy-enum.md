
# Equipment Update Deploy Enum

## Enumeration

`EquipmentUpdateDeployEnum`

## Fields

| Name |
|  --- |
| `M` |
| `D` |
| `N` |

## Example

```
M
```

