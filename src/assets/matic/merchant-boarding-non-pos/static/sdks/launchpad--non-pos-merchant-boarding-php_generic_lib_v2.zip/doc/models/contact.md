
# Contact

## Structure

`Contact`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type1Enum)`](../../doc/models/type-1-enum.md) | Required | Type of merchant contact.<br><br>1) Only primary contact<br>   is mandatory. May be the same as any owner contact information.<br>2) For primary contact, firstName, lastName, phoneNumber and email are mandatory during POST.<br>3) For all other contact types, firstName and lastName are mandatory during POST. | getType(): string | setType(string type): void |
| `title` | `?string` | Optional | Required for AMEX acquired merchants otherwise optional.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `30`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | getTitle(): ?string | setTitle(?string title): void |
| `firstName` | `string` | Required | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | getFirstName(): string | setFirstName(string firstName): void |
| `middleInitial` | `?string` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | getMiddleInitial(): ?string | setMiddleInitial(?string middleInitial): void |
| `lastName` | `string` | Required | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | getLastName(): string | setLastName(string lastName): void |
| `ssn` | `?string` | Optional | Social security number. Do not include dashes.<br>**Constraints**: *Pattern*: `^[0-9]{9}$` | getSsn(): ?string | setSsn(?string ssn): void |
| `birthDate` | `?DateTime` | Optional | Date of Birth (CCYY-MM-DD). Must be at least 18 years old. | getBirthDate(): ?\DateTime | setBirthDate(?\DateTime birthDate): void |
| `phoneNumber` | `string` | Required | 10-digit phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` | getPhoneNumber(): string | setPhoneNumber(string phoneNumber): void |
| `phoneNumberExt` | `?string` | Optional | Phone number extension. Up to 8 digits of the format 12345678.<br>**Constraints**: *Maximum Length*: `8`, *Pattern*: `^[0-9]{1,8}$` | getPhoneNumberExt(): ?string | setPhoneNumberExt(?string phoneNumberExt): void |
| `phoneType` | [`?string(PhoneTypeEnum)`](../../doc/models/phone-type-enum.md) | Optional | Phone type. | getPhoneType(): ?string | setPhoneType(?string phoneType): void |
| `alternatePhone` | `?string` | Optional | 10-digit alternate phone number of the format  5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` | getAlternatePhone(): ?string | setAlternatePhone(?string alternatePhone): void |
| `alternatePhoneType` | [`?string(AlternatePhoneTypeEnum)`](../../doc/models/alternate-phone-type-enum.md) | Optional | Alternate phone type. | getAlternatePhoneType(): ?string | setAlternatePhoneType(?string alternatePhoneType): void |
| `email` | `string` | Required | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` | getEmail(): string | setEmail(string email): void |
| `faxNumber` | `?string` | Optional | 10-digit fax number of the format 5131234567<br>**Constraints**: *Pattern*: `^[0-9]{10}$` | getFaxNumber(): ?string | setFaxNumber(?string faxNumber): void |

## Example (as JSON)

```json
{
  "type": "Primary Contact",
  "title": "President",
  "firstName": "Todd",
  "middleInitial": "M",
  "lastName": "Davis",
  "ssn": "123456789",
  "birthDate": "2000-03-23",
  "phoneNumber": "5131234567",
  "phoneNumberExt": "1234",
  "phoneType": "mobile",
  "alternatePhone": "5131234567",
  "alternatePhoneType": "home",
  "email": "test@gmail.com",
  "faxNumber": "5131234567"
}
```

