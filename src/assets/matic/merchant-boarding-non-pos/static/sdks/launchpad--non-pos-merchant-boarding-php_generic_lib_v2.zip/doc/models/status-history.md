
# Status History

## Structure

`StatusHistory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `statusSeqNumber` | `?int` | Optional | - | getStatusSeqNumber(): ?int | setStatusSeqNumber(?int statusSeqNumber): void |
| `detailStatus` | `?string` | Optional | - | getDetailStatus(): ?string | setDetailStatus(?string detailStatus): void |
| `summaryStatus` | `?string` | Optional | - | getSummaryStatus(): ?string | setSummaryStatus(?string summaryStatus): void |
| `statusCategory` | `?string` | Optional | - | getStatusCategory(): ?string | setStatusCategory(?string statusCategory): void |
| `statusDateTime` | `?DateTime` | Optional | - | getStatusDateTime(): ?\DateTime | setStatusDateTime(?\DateTime statusDateTime): void |

## Example (as JSON)

```json
{
  "statusSeqNumber": 2200,
  "detailStatus": "Contract Signed",
  "summaryStatus": "App Submitted",
  "statusCategory": "Contract",
  "statusDateTime": "2016-03-13T12:52:32.123Z"
}
```

